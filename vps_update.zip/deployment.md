# ThunderCipher MailAI — Production Deployment Guide

Complete guide for deploying and updating the MailAI outreach CRM platform on a Linux VPS.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│  VPS (Ubuntu/Debian)                                    │
│                                                         │
│  ┌──────────────┐    ┌──────────────┐                   │
│  │   Nginx      │───▶│  Frontend    │ :777 → :80        │
│  │   (Host)     │    │  (Nginx)     │ Static React SPA  │
│  │   :80/:443   │    └──────────────┘                   │
│  │   SSL Term.  │    ┌──────────────┐                   │
│  │              │───▶│  Backend     │ :8000              │
│  └──────────────┘    │  (Uvicorn)   │ FastAPI + WS      │
│                      └──────┬───────┘                   │
│                             │                           │
│              ┌──────────────┼──────────────┐            │
│              │              │              │            │
│        ┌─────▼─────┐ ┌─────▼─────┐ ┌─────▼─────┐      │
│        │ PostgreSQL │ │   Redis   │ │ ARQ Worker│      │
│        │    :5432   │ │   :6379   │ │ (Async)   │      │
│        └───────────┘ └───────────┘ └───────────┘      │
└─────────────────────────────────────────────────────────┘
```

**5 containers:** PostgreSQL 16, Redis 7, Backend (FastAPI/Uvicorn), ARQ Worker (background jobs), Frontend (Nginx serving React)

---

## Prerequisites

- **VPS:** Ubuntu 22.04+ or Debian 12+ (minimum 2 GB RAM, 1 vCPU)
- **Domain:** DNS A-record pointing to VPS IP
- **Software:** Docker & Docker Compose installed

```bash
# Install Docker & Compose (if not already)
sudo apt update && sudo apt install -y docker.io docker-compose
sudo systemctl enable docker && sudo systemctl start docker
```

---

## Fresh Deployment (First Time)

### 1. Upload & Extract

```bash
# From local machine
scp vps_update.zip root@YOUR_VPS_IP:~/

# On VPS
ssh root@YOUR_VPS_IP
mkdir -p ~/MailAI && cd ~/MailAI
unzip -o ~/vps_update.zip
```

### 2. Configure Environment Variables

```bash
cp .env.production .env
nano .env
```

Fill in your production values:

```env
# PostgreSQL
POSTGRES_USER=mailai
POSTGRES_PASSWORD=CHANGE_TO_STRONG_PASSWORD
POSTGRES_DB=mailai

# Public backend URL (used for tracking pixels & unsubscribe links)
BACKEND_URL=https://your-domain.com

# JWT session encryption key (generate with: openssl rand -hex 32)
JWT_SECRET=CHANGE_TO_RANDOM_64_CHAR_HEX

# Encryption key for SMTP credentials at rest (generate with: openssl rand -hex 16)
ENCRYPTION_KEY=CHANGE_TO_RANDOM_32_CHAR_HEX

# Frontend API base (leave commented to auto-detect from browser URL)
# VITE_API_BASE_URL=https://your-domain.com
```

### 3. Build & Launch

```bash
docker-compose up -d --build
```

Verify all 5 containers are running:

```bash
docker-compose ps
```

Expected output:
```
mailai-postgres   running
mailai-redis      running
mailai-backend    running
mailai-worker     running
mailai-frontend   running
```

### 4. Configure Host Nginx & SSL

```bash
sudo apt install -y nginx certbot python3-certbot-nginx
```

Create `/etc/nginx/sites-available/mailai`:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend (React SPA)
    location / {
        proxy_pass http://127.0.0.1:777;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Backend API + WebSocket
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket support
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    # Tracking pixel & unsubscribe endpoints
    location /track/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /unsubscribe {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Increase upload limit for CSV imports
    client_max_body_size 25M;
}
```

Enable & activate:

```bash
sudo ln -sf /etc/nginx/sites-available/mailai /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl restart nginx
```

Install SSL certificate:

```bash
sudo certbot --nginx -d your-domain.com
```

### 5. Verify

Open `https://your-domain.com` in your browser. Default admin accounts: `apokrypth` and `anoop`.

---

## Update Deployment (Subsequent Updates)

### Quick Update (with vps_update.zip)

```bash
# 1. Upload zip from local machine
scp vps_update.zip root@YOUR_VPS_IP:~/MailAI/

# 2. On VPS — extract, rebuild
cd ~/MailAI
unzip -o vps_update.zip
docker-compose down && docker-compose up -d --build
```

### Selective Update (with hash diff)

```bash
# 1. Generate hashes on both sides
python3 sync_check.py hash > local_hashes.txt    # local
python3 sync_check.py hash > vps_hashes.txt      # VPS

# 2. Diff on local machine
python sync_check.py diff local_hashes.txt vps_hashes.txt

# 3. Sync only changed files
rsync -avz --files-from=sync_files.txt ./ root@YOUR_VPS_IP:~/MailAI/

# 4. Rebuild on VPS
ssh root@YOUR_VPS_IP "cd ~/MailAI && docker-compose down && docker-compose up -d --build"
```

---

## Common Operations

### View Logs

```bash
# All containers
docker-compose logs -f

# Specific container
docker-compose logs -f backend
docker-compose logs -f arq_worker
docker-compose logs -f frontend
```

### Restart a Single Service

```bash
docker-compose restart backend
docker-compose restart arq_worker
```

### Database Backup

```bash
docker exec mailai-postgres pg_dump -U mailai mailai > backup_$(date +%Y%m%d).sql
```

### Database Restore

```bash
cat backup_20260716.sql | docker exec -i mailai-postgres psql -U mailai mailai
```

### Full Reset (wipes all data)

```bash
docker-compose down -v    # -v removes volumes (database data!)
docker-compose up -d --build
```

---

## Port Mapping

| Service    | Internal Port | External Port | Notes                    |
|------------|---------------|---------------|--------------------------|
| Frontend   | 80            | 777           | Configurable via `PORT`  |
| Backend    | 8000          | 8000          | API + WebSocket          |
| PostgreSQL | 5432          | —             | Internal only            |
| Redis      | 6379          | —             | Internal only            |

---

## Environment Variables Reference

| Variable           | Required | Description                                      |
|--------------------|----------|--------------------------------------------------|
| `POSTGRES_USER`    | ✅       | PostgreSQL username                               |
| `POSTGRES_PASSWORD`| ✅       | PostgreSQL password                               |
| `POSTGRES_DB`      | ✅       | PostgreSQL database name                          |
| `BACKEND_URL`      | ✅       | Public URL for tracking pixels & unsubscribe      |
| `JWT_SECRET`       | ✅       | Session token encryption key                      |
| `ENCRYPTION_KEY`   | ✅       | AES key for SMTP credential encryption at rest    |
| `VITE_API_BASE_URL`| Optional | Frontend API endpoint (auto-detected if blank)    |
| `PORT`             | Optional | Frontend external port (default: 777)             |
| `GEMINI_API_KEY`   | Optional | Google Gemini API key for AI copilot              |

---

## Timezone

All campaigns, delivery schedules, warmup resets, and weekday constraints operate in **IST (UTC+5:30)**. Daily limits reset at local midnight IST.
