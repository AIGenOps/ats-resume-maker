# ThunderCipher Enterprise Email Outreach CRM (MailAI)

Welcome to the **ThunderCipher Enterprise Email Outreach CRM**, a production-grade, self-hosted outreach tool.

## Key Features
- **Contacts CRM**: Manage tags, companies, customized metadata, notes, and timelines.
- **Template Engine**: Rich text, plain text, and HTML template editor with live preview and variable auto-completion.
- **Email Sending & Campaigns**: Schedule campaigns, monitor sending queues, auto-detect duplicates, and set rate limits.
- **Unified Inbox & Reply Center**: Multi-threaded conversations, assigning conversations, and discord notification triggers.
- **Deliverability Monitoring**: Check SMTP status and track SPF, DKIM, and DMARC reputation status.
- **Dashboard Intelligence**: Overview of sending metrics, bounce rates, open rates, and activity feeds.

---

## Local Development Setup

The application is structured as a monorepo with a FastAPI backend and a React/TypeScript/Vite frontend. It includes fallbacks so you can run it locally without Docker or Redis.

### 1. Backend Setup (FastAPI)
1. Navigate to the backend directory:
   ```bash
   cd backend
   ```
2. Create a virtual environment and install dependencies:
   ```bash
   python -m venv venv
   .\venv\Scripts\activate
   pip install -r requirements.txt
   ```
3. Run the backend locally (uses SQLite fallback if no PostgreSQL URL is provided):
   ```bash
   uvicorn app.main:app --reload
   ```
   The backend API documentation is available at [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs).

### 2. Frontend Setup (React + Vite)
1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```
2. Install npm dependencies:
   ```bash
   npm install
   ```
3. Run the development server:
   ```bash
   npm run dev
   ```
   The application will be accessible at [http://localhost:5173/](http://localhost:5173/).

---

## Production Deployment (Docker)

To deploy the production-ready stack (FastAPI, React, PostgreSQL, Redis, Celery):
```bash
docker-compose up --build
```
