import React, { useState, useEffect } from 'react';
import { API_BASE } from '../config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faShieldHalved as Shield, faRotate as RefreshCw, faMagnifyingGlass as Search, 
  faCaretDown as CaretDown, faCaretRight as CaretRight, faCalendarDays as Calendar, faUser as User, faFilter as Funnel, faCircleInfo as Info, faDownload as Export
} from '@fortawesome/free-solid-svg-icons';
import { useToast } from '../contexts/ToastContext';

interface LogsProps {
  token: string;
}

export default function Logs({ token }: LogsProps) {
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Search and Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAction, setFilterAction] = useState('all');
  const [filterActor, setFilterActor] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  
  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 15;

  // Expand state
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const { addToast } = useToast();

  useEffect(() => {
    fetchLogs();
  }, []);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/dashboard/audit-logs`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setLogs(data);
      } else {
        setLogs([]);
        if (data && data.detail) {
          addToast(data.detail, 'error');
        }
      }
    } catch (e) {
      console.error(e);
      setLogs([]);
    } finally {
      setLoading(false);
    }
  };

  // Helper to extract Target out of log text details representation
  const parseLog = (log: any) => {
    const action = log.action || 'Unknown';
    let target = 'System';
    const details = log.details || '';

    const lowerAction = action.toLowerCase();
    const lowerDetails = details.toLowerCase();

    // Determine Target Scope
    if (lowerAction.includes('smtp') || lowerDetails.includes('smtp')) {
      target = 'SMTP Settings';
      const hostMatch = details.match(/(?:host=|account:\s*)([a-zA-Z0-9.-]+)/);
      if (hostMatch) target = `SMTP: ${hostMatch[1]}`;
    } else if (lowerAction.includes('contact') || lowerAction.includes('import') || lowerDetails.includes('contact')) {
      target = 'Directory';
      const fileMatch = details.match(/(?:file:\s*|filename=\s*)([a-zA-Z0-9._-]+)/);
      if (fileMatch) target = `Directory (${fileMatch[1]})`;
    } else if (lowerAction.includes('campaign') || lowerDetails.includes('campaign')) {
      target = 'Campaign';
      const nameMatch = details.match(/(?:name=\s*|campaign:\s*|id=\s*)([a-zA-Z0-9._-\s]+)/);
      if (nameMatch) target = `Campaign: ${nameMatch[1].trim()}`;
    } else if (lowerAction.includes('template') || lowerDetails.includes('template')) {
      target = 'Templates';
      const tplMatch = details.match(/(?:name=\s*|template:\s*)([a-zA-Z0-9._-\s]+)/);
      if (tplMatch) target = `Template: ${tplMatch[1].trim()}`;
    } else if (lowerAction.includes('label') || lowerAction.includes('tag') || lowerDetails.includes('tag')) {
      target = 'Labels';
    }

    // Shorten action names for display badges
    let displayAction = action;
    const actionMap: Record<string, string> = {
      'SMTP Configuration Added': 'SMTP Config Added',
      'SMTP Configuration Deleted': 'SMTP Config Deleted',
      'SMTP Connection Tested': 'SMTP Test Connect',
      'SMTP Configuration Tested': 'SMTP Test Connect',
      'SMTP Configuration Saved': 'SMTP Config Saved',
      'Campaign Started': 'Campaign Started',
      'Campaign Paused': 'Campaign Paused',
      'Campaign Created': 'Campaign Created',
      'Contact Created': 'Contact Created',
      'Contact Imported': 'Contact Imported',
      'Template Created': 'Template Created',
      'Template Edited': 'Template Edited',
      'Template Deleted': 'Template Deleted',
    };
    if (actionMap[action]) {
      displayAction = actionMap[action];
    }

    return { action, target, details, displayAction };
  };

  const getActionBadgeClass = (action: string, details: string) => {
    const act = action.toLowerCase();
    const det = details.toLowerCase();

    if (act.includes('login') || act.includes('auth') || det.includes('logged in')) {
      return 'text-blue-500 bg-blue-500/10 border border-blue-500/20';
    }
    if (act.includes('delete') || act.includes('remove') || act.includes('trash') || det.includes('delete')) {
      return 'text-red-500 bg-red-500/10 border border-red-500/20';
    }
    if (act.includes('create') || act.includes('add') || act.includes('import') || det.includes('create')) {
      return 'text-emerald-500 bg-emerald-500/10 border border-emerald-500/20';
    }
    if (act.includes('update') || act.includes('edit') || act.includes('modify') || act.includes('config') || det.includes('update')) {
      return 'text-amber-500 bg-amber-500/10 border border-amber-500/20';
    }
    if (act.includes('campaign') || act.includes('start') || act.includes('pause') || det.includes('campaign')) {
      return 'text-purple-500 bg-purple-500/10 border border-purple-500/20';
    }
    return 'text-slate-400 bg-slate-400/10 border border-slate-500/20';
  };

  const filteredLogs = logs.filter(log => {
    const parsed = parseLog(log);
    const actorEmail = log.actor_email || 'System';
    const actorName = log.actor_name || 'System';
    const ipAddress = log.ip_address || 'N/A';
    const userAgent = log.user_agent || 'N/A';
    
    // 1. Search Query
    const query = searchQuery.toLowerCase();
    const matchesSearch = searchQuery === '' || 
      log.action.toLowerCase().includes(query) ||
      actorEmail.toLowerCase().includes(query) ||
      actorName.toLowerCase().includes(query) ||
      ipAddress.toLowerCase().includes(query) ||
      userAgent.toLowerCase().includes(query) ||
      parsed.target.toLowerCase().includes(query) ||
      parsed.details.toLowerCase().includes(query);

    // 2. Action Category filter
    let matchesCategory = true;
    if (filterAction !== 'all') {
      const act = log.action.toLowerCase();
      const det = parsed.details.toLowerCase();
      if (filterAction === 'auth') {
        matchesCategory = act.includes('login') || act.includes('auth') || det.includes('logged in');
      } else if (filterAction === 'smtp') {
        matchesCategory = act.includes('smtp') || det.includes('smtp');
      } else if (filterAction === 'campaign') {
        matchesCategory = act.includes('campaign') || det.includes('campaign');
      } else if (filterAction === 'directory') {
        matchesCategory = act.includes('contact') || act.includes('import') || det.includes('contact');
      } else if (filterAction === 'system') {
        matchesCategory = act.includes('system') || act.includes('database') || det.includes('database');
      }
    }

    // 3. Actor input filter
    const matchesActor = filterActor === '' || 
      actorEmail.toLowerCase().includes(filterActor.toLowerCase()) ||
      actorName.toLowerCase().includes(filterActor.toLowerCase());

    // 4. Date Range filter
    let matchesDate = true;
    if (startDate || endDate) {
      const logDate = new Date(log.timestamp);
      logDate.setHours(0, 0, 0, 0);
      
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        if (logDate < start) matchesDate = false;
      }
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(0, 0, 0, 0);
        if (logDate > end) matchesDate = false;
      }
    }

    return matchesSearch && matchesCategory && matchesActor && matchesDate;
  });

  const getRelativeTime = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffDays < 7) return `${diffDays}d ago`;
      return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    } catch {
      return dateStr;
    }
  };

  const toggleRow = (id: string) => {
    setExpandedLogId(prev => (prev === id ? null : id));
  };

  // Reset pagination page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, filterAction, filterActor, startDate, endDate]);

  // Paginated Logs slice
  const paginatedLogs = filteredLogs.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredLogs.length / itemsPerPage) || 1;

  // CSV Export utility
  const handleExportCsv = () => {
    if (filteredLogs.length === 0) {
      addToast("No logs available to export.", "info");
      return;
    }

    const headers = ["Event ID", "Action", "Actor Name", "Actor Email", "Target Scope", "IP Address", "User Agent", "Timestamp", "Details"];
    const rows = filteredLogs.map(log => {
      const parsed = parseLog(log);
      return [
        log.id,
        log.action,
        log.actor_name || "System",
        log.actor_email || "System",
        parsed.target,
        log.ip_address || "N/A",
        `"${(log.user_agent || "N/A").replace(/"/g, '""')}"`,
        log.timestamp,
        `"${(log.details || "").replace(/"/g, '""')}"`
      ];
    });

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `security_audit_logs_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast("Audit logs exported to CSV successfully!", "success");
  };

  return (
    <div className="space-y-6 animate-slide-in text-theme-primary">
      {isMobile && (
        <div className="flex justify-between items-center pb-2 shrink-0 bg-transparent relative z-10 pt-4">
          <h1 className="text-3xl font-extrabold tracking-tight text-white capitalize font-heading" style={{ fontFamily: 'var(--font-heading)' }}>
            Audit Logs
          </h1>
          <div className="w-10 h-10 rounded-full bg-theme-accent text-theme-btnText flex items-center justify-center font-bold text-sm select-none border border-theme-border/20">
            {(() => {
              const name = localStorage.getItem('setting_sender_name') || 'JD';
              const parts = name.trim().split(/\s+/);
              if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
              return parts[0].slice(0, 2).toUpperCase();
            })()}
          </div>
        </div>
      )}
      {!isMobile && (
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-extrabold font-display tracking-tight text-theme-primary uppercase">Audit Logs</h1>
            <p className="text-theme-muted text-sm mt-1 font-sans">Audit trail tracking all critical system and user actions.</p>
          </div>
          <div className="flex items-center gap-2">
            {/* CSV Export Button next to Refresh */}
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-2 px-4 py-2 bg-theme-surface border border-theme-border rounded-none font-semibold hover:bg-theme-app text-xs transition-colors text-theme-secondary cursor-pointer"
              title="Export CSV Logs"
            >
              <FontAwesomeIcon icon={Export} className="h-4 w-4" />
              <span>Export CSV</span>
            </button>
            
            <button 
              onClick={fetchLogs}
              disabled={loading}
              className="p-2 bg-theme-surface border border-theme-border rounded-none hover:bg-theme-app transition-all cursor-pointer disabled:opacity-50 flex items-center justify-center shrink-0"
              title="Refresh Logs"
            >
              <FontAwesomeIcon icon={RefreshCw} className={`h-5 w-5 text-theme-muted ${loading ? 'fa-spin' : ''}`} />
            </button>
          </div>
        </div>
      )}

      {/* Filter Bar Controls */}
      <div className="bg-theme-surface border border-theme-border p-6 rounded-none shadow-sm space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Query search */}
          <div className="relative flex-grow min-w-[200px]">
            <FontAwesomeIcon icon={Search} className="absolute left-3.5 top-3 h-4 w-4 text-theme-muted" />
            <input
              type="text"
              placeholder="Search details..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-[#0A0A0D] border border-theme-input rounded-none text-theme-primary placeholder-theme-muted focus:outline-none focus:border-theme-accent transition-colors text-xs font-semibold"
            />
          </div>

          {/* Action category filter */}
          <div className="relative min-w-[150px]">
            <FontAwesomeIcon icon={Funnel} className="absolute left-3.5 top-3 h-4 w-4 text-theme-muted" />
            <select
              value={filterAction}
              onChange={(e) => setFilterAction(e.target.value)}
              className="w-full pl-10 pr-8 py-2 bg-[#0A0A0D] border border-theme-input rounded-none text-theme-primary focus:outline-none focus:border-theme-accent transition-colors text-xs font-bold cursor-pointer appearance-none"
            >
              <option value="all">All Event Types</option>
              <option value="auth">Authentication / Login</option>
              <option value="smtp">SMTP Settings</option>
              <option value="campaign">Outreach Campaigns</option>
              <option value="directory">Directory & Imports</option>
              <option value="system">System & Database</option>
            </select>
          </div>

          {/* Actor Filter */}
          <div className="relative min-w-[150px]">
            <FontAwesomeIcon icon={User} className="absolute left-3.5 top-3 h-4 w-4 text-theme-muted" />
            <input
              type="text"
              placeholder="Filter by actor (email)..."
              value={filterActor}
              onChange={(e) => setFilterActor(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-[#0A0A0D] border border-theme-input rounded-none text-theme-primary placeholder-theme-muted focus:outline-none focus:border-theme-accent transition-colors text-xs font-semibold"
            />
          </div>

          {/* Date range filters */}
          <div className="flex gap-2 items-center">
            <div className="relative flex-1">
              <FontAwesomeIcon icon={Calendar} className="absolute left-3 top-2.5 h-3.5 w-3.5 text-theme-muted" />
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                onClick={(e) => e.currentTarget.showPicker()}
                title="Start Date"
                className="w-full pl-9 pr-2 py-1.5 bg-[#0A0A0D] border border-theme-input rounded-none text-theme-primary focus:outline-none focus:border-theme-accent transition-colors text-[10px] font-bold cursor-pointer"
              />
            </div>
            <span className="text-theme-muted text-[10px] font-bold font-mono">TO</span>
            <div className="relative flex-1">
              <FontAwesomeIcon icon={Calendar} className="absolute left-3 top-2.5 h-3.5 w-3.5 text-theme-muted" />
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                onClick={(e) => e.currentTarget.showPicker()}
                title="End Date"
                className="w-full pl-9 pr-2 py-1.5 bg-[#0A0A0D] border border-theme-input rounded-none text-[#F3F4F6] focus:outline-none focus:border-theme-accent transition-colors text-[10px] font-bold cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Clear Filters Indicator */}
        {(searchQuery || filterAction !== 'all' || filterActor || startDate || endDate) && (
          <div className="flex justify-end pt-1">
            <button
              onClick={() => {
                setSearchQuery('');
                setFilterAction('all');
                setFilterActor('');
                setStartDate('');
                setEndDate('');
              }}
              className="text-[10px] font-bold text-[#60A5FA] hover:text-[#93C5FD] transition-colors cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        )}
      </div>

      {/* Structured Table */}
      <div className="bg-theme-surface border border-theme-border rounded-none overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          {isMobile ? (
            <div className="p-4 space-y-3">
              {loading ? (
                Array.from({ length: 3 }).map((_, idx) => (
                  <div key={idx} className="p-4 space-y-2 animate-pulse bg-theme-surface border border-theme-border">
                    <div className="h-4 bg-theme-border/50 rounded w-1/3" />
                    <div className="h-3 bg-theme-border/30 rounded w-1/2" />
                  </div>
                ))
              ) : filteredLogs.length === 0 ? (
                <div className="p-8 text-center text-xs text-theme-muted bg-theme-surface border border-theme-border">
                  No administrative events logged.
                </div>
              ) : (
                paginatedLogs.map((log) => {
                  const parsed = parseLog(log);
                  const isExpanded = expandedLogId === log.id;
                  const actorEmail = log.actor_email || 'System';
                  const actorName = log.actor_name || 'System';
                  const ipAddress = log.ip_address || 'N/A';
                  return (
                    <div 
                      key={log.id} 
                      className="p-4 flex flex-col gap-2 bg-[#121316] border border-[#202226]/50 rounded-xl mobile-card mb-3 hover:brightness-105 transition-all"
                    >
                      <div 
                        className="flex justify-between items-start cursor-pointer"
                        onClick={() => toggleRow(log.id)}
                      >
                        <div>
                          <span className={`px-2.5 py-1 rounded-none text-[9px] font-bold uppercase tracking-wider ${getActionBadgeClass(log.action, log.details)}`}>
                            {parsed.displayAction}
                          </span>
                          <div className="font-bold text-theme-primary text-xs mt-2">{actorEmail}</div>
                          <div className="text-[10px] text-theme-muted mt-0.5">{getRelativeTime(log.timestamp)}</div>
                        </div>
                        <span className="text-theme-muted p-2 -mr-2 cursor-pointer">
                          {isExpanded ? <FontAwesomeIcon icon={CaretDown} /> : <FontAwesomeIcon icon={CaretRight} />}
                        </span>
                      </div>
                      
                      {isExpanded && (
                        <div className="mt-2 pt-3 border-t border-theme-border space-y-3.5 text-[11px] font-sans text-theme-secondary">
                          <div>
                            <span className="text-[9px] font-bold uppercase tracking-wider text-theme-muted block mb-0.5">Target Scope</span>
                            <span className="text-theme-primary font-medium">{parsed.target}</span>
                          </div>
                          <div>
                            <span className="text-[9px] font-bold uppercase tracking-wider text-theme-muted block mb-1">Event Payload Details</span>
                            <p className="text-theme-secondary bg-[#0A0A0D] p-3 rounded-none border border-[#1D1D22] font-mono whitespace-pre-wrap text-[10px] leading-relaxed">
                              {parsed.details}
                            </p>
                          </div>
                          {actorName !== 'System' && (
                            <div>
                              <span className="text-[9px] font-bold uppercase tracking-wider text-theme-muted block mb-0.5">Actor Name</span>
                              <span className="font-mono text-theme-primary">{actorName}</span>
                            </div>
                          )}
                          <div>
                            <span className="text-[9px] font-bold uppercase tracking-wider text-theme-muted block mb-0.5">Client User Agent</span>
                            <span className="font-mono text-theme-primary block break-all">{log.user_agent || "N/A"}</span>
                          </div>
                          <div>
                            <span className="text-[9px] font-bold uppercase tracking-wider text-theme-muted block mb-0.5">IP Address</span>
                            <span className="font-mono text-[#60A5FA]">IP: {ipAddress}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          ) : (
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="bg-theme-app/50 border-b border-[#1D1D22] text-theme-muted font-bold uppercase text-[10px] tracking-wider font-sans">
                  <th className="px-6 py-5 w-[200px]">Action</th>
                  <th className="px-6 py-5 w-[240px]">Actor</th>
                  <th className="px-6 py-5">Target Scope</th>
                  <th className="px-6 py-5 w-[200px]">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1D1D22]">
                {loading ? (
                  Array.from({ length: 5 }).map((_, idx) => (
                    <tr key={idx} className="border-b border-[#1D1D22]/30">
                      <td className="px-6 py-5">
                        <div className="h-4.5 bg-theme-border/50 rounded-none animate-pulse w-32" />
                      </td>
                      <td className="px-6 py-5">
                        <div className="h-4.5 bg-theme-border/50 rounded-none animate-pulse w-28" />
                      </td>
                      <td className="px-6 py-4 mr-6">
                        <div className="h-4 bg-theme-border/30 rounded-none animate-pulse w-48" />
                      </td>
                      <td className="px-6 py-5">
                        <div className="h-4 bg-theme-border/40 rounded-none animate-pulse w-20" />
                      </td>
                    </tr>
                  ))
                ) : filteredLogs.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-6 py-16 text-center">
                      <div className="flex flex-col items-center justify-center space-y-3.5 max-w-md mx-auto">
                        <div className="flex flex-col items-center justify-center space-y-3">
                          <FontAwesomeIcon icon={Shield} className="h-9 w-9 text-theme-muted" />
                        </div>
                        <p className="text-sm font-semibold text-[#60A5FA] font-sans">No administrative events logged</p>
                        <p className="text-xs text-theme-muted leading-relaxed font-sans">
                          When you trigger actions like logging in, creating SMTP gateways, launching outreach campaigns, or importing contact lists, a secure record will be added to this audit trail.
                        </p>
                      </div>
                    </td>
                  </tr>
                ) : (
                  paginatedLogs.map((log) => {
                    const parsed = parseLog(log);
                    const isExpanded = expandedLogId === log.id;
                    const actorEmail = log.actor_email || 'System';
                    const actorName = log.actor_name || 'System';
                    const ipAddress = log.ip_address || 'N/A';
                    return (
                      <React.Fragment key={log.id}>
                        <tr 
                          className="hover:bg-theme-hover/40 transition-colors border-b border-[#1D1D22] cursor-pointer"
                          onClick={() => toggleRow(log.id)}
                        >
                          {/* 1. Category-colored action badges */}
                          <td className="px-6 py-5">
                            <div className="flex items-center gap-2.5">
                              <span className="text-theme-muted shrink-0">
                                {isExpanded ? <FontAwesomeIcon icon={CaretDown} /> : <FontAwesomeIcon icon={CaretRight} />}
                              </span>
                              <span 
                                className={`px-2.5 py-1 rounded-none text-[9px] font-bold uppercase tracking-wider whitespace-nowrap truncate max-w-[150px] inline-block ${getActionBadgeClass(log.action, log.details)}`}
                                title={log.action}
                              >
                                {parsed.displayAction}
                              </span>
                            </div>
                          </td>
                          
                          {/* 2. Actor and IP Column */}
                          <td className="px-6 py-5">
                            <div className="font-bold text-theme-primary text-xs truncate max-w-[220px]" title={actorEmail}>
                              {actorEmail}
                            </div>
                            {ipAddress !== 'N/A' && (
                              <div className="text-[10px] text-[#60A5FA] font-mono mt-0.5">IP: {ipAddress}</div>
                            )}
                          </td>
  
                          {/* 3. Target Scope column */}
                          <td className="px-6 py-5 text-theme-secondary font-sans text-xs font-semibold truncate max-w-xs" title={parsed.target}>
                            {parsed.target}
                          </td>
  
                          {/* 4. Absolute and relative timestamps */}
                          <td className="px-6 py-5 text-theme-muted text-xs font-semibold whitespace-nowrap">
                            <div className="text-theme-primary" title={new Date(log.timestamp).toLocaleString()}>
                              {getRelativeTime(log.timestamp)}
                            </div>
                            <div className="text-[10px] text-theme-muted mt-0.5 font-mono">
                              {new Date(log.timestamp).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' })}
                            </div>
                          </td>
                        </tr>
                        
                        {/* 5. Expandable detail view containing full client metadata */}
                        {isExpanded && (
                          <tr className="bg-[#0A0A0D]/60">
                            <td colSpan={4} className="px-6 py-5 border-b border-[#1D1D22]">
                              <div className="space-y-4 text-left text-xs font-sans">
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                  <div className="md:col-span-2">
                                    <div className="flex items-center gap-1.5 mb-1.5 text-theme-muted">
                                      <FontAwesomeIcon icon={Info} className="text-xs" />
                                      <h4 className="text-[10px] font-bold uppercase tracking-wider">Event Payload details</h4>
                                    </div>
                                    <p className="text-theme-secondary bg-[#0A0A0D] p-3.5 rounded-none border border-[#1D1D22] leading-relaxed font-mono whitespace-pre-wrap">
                                      {parsed.details}
                                    </p>
                                  </div>
                                  <div className="space-y-3.5 bg-[#0A0A0D]/20 p-4 border border-[#1D1D22] rounded-none">
                                    {actorName !== 'System' && (
                                      <div>
                                        <h4 className="text-[9px] font-bold uppercase tracking-wider text-theme-muted mb-0.5">Actor Name</h4>
                                        <span className="text-theme-secondary font-mono text-[11px] block">{actorName}</span>
                                      </div>
                                    )}
                                    <div>
                                      <h4 className="text-[9px] font-bold uppercase tracking-wider text-theme-muted mb-0.5">Record Identifier</h4>
                                      <span className="font-mono text-theme-secondary text-[11px] select-all block break-all">{log.id}</span>
                                    </div>
                                    <div>
                                      <h4 className="text-[9px] font-bold uppercase tracking-wider text-theme-muted mb-0.5">Client User Agent</h4>
                                      <span className="text-theme-secondary font-mono text-[10px] block break-all">{log.user_agent || "N/A"}</span>
                                    </div>
                                    <div>
                                      <h4 className="text-[9px] font-bold uppercase tracking-wider text-theme-muted mb-0.5">Client IP Address</h4>
                                      <span className="text-theme-secondary font-mono text-[11px] block">{log.ip_address || "N/A"}</span>
                                    </div>
                                    <div>
                                      <h4 className="text-[9px] font-bold uppercase tracking-wider text-theme-muted mb-0.5">Execution Timestamp</h4>
                                      <span className="text-theme-secondary font-mono text-[11px] block">
                                        {new Date(log.timestamp).toUTCString()}
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    );
                  })
                )}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination bar */}
        {totalPages > 1 && (
          <div className="px-6 py-4 bg-theme-app/30 border-t border-theme-border flex justify-between items-center shrink-0">
            <span className="text-[10px] text-theme-muted font-bold font-mono">
              Total {filteredLogs.length} events
            </span>
            <div className="flex gap-2 items-center">
              <button
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                disabled={currentPage === 1}
                className="px-3 py-1.5 border border-theme-border rounded-none bg-theme-surface hover:bg-theme-hover font-bold cursor-pointer transition-colors disabled:opacity-50 text-[10px] uppercase tracking-wider"
              >
                Previous
              </button>
              <span className="px-3 text-theme-muted font-bold font-mono">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                disabled={currentPage === totalPages}
                className="px-3 py-1.5 border border-theme-border rounded-none bg-theme-surface hover:bg-theme-hover font-bold cursor-pointer transition-colors disabled:opacity-50 text-[10px] uppercase tracking-wider"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
