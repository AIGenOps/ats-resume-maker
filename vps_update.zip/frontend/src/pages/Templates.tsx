import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { API_BASE } from '../config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faPlus as Plus, faFolder as Folder, faFileLines as FileText, faTrashCan as Trash, 
  faRotate as RefreshCw, faXmark as X, faEye as Eye, faPencil as Edit
} from '@fortawesome/free-solid-svg-icons';
import { useToast } from '../contexts/ToastContext';

interface TemplatesProps {
  token: string;
}

export default function Templates({ token }: TemplatesProps) {
  const { addToast } = useToast();
  const [templates, setTemplates] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<any>(null);
  const [previewTemplate, setPreviewTemplate] = useState<any>(null);

  // Form State
  const [name, setName] = useState('');
  const [folder, setFolder] = useState('General');
  const [subject, setSubject] = useState('');
  const [bodyHtml, setBodyHtml] = useState('');

  useEffect(() => {
    fetchTemplates();
  }, []);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowAddModal(false);
        setEditingTemplate(null);
        setPreviewTemplate(null);
      }
    };
    if (showAddModal || editingTemplate || previewTemplate) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => window.removeEventListener('keydown', handleEsc);
  }, [showAddModal, editingTemplate, previewTemplate]);

  const fetchTemplates = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/templates/`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setTemplates(data);
      } else {
        setTemplates([]);
        if (data && data.detail) {
          addToast(data.detail, 'error');
        }
      }
    } catch (e) {
      console.error(e);
      setTemplates([]);
    } finally {
      setLoading(false);
    }
  };

  const handleOpenEdit = (tpl: any) => {
    setEditingTemplate(tpl);
    setName(tpl.name);
    setFolder(tpl.folder);
    setSubject(tpl.subject);
    setBodyHtml(tpl.body_html);
  };

  const handleCloseModal = () => {
    setShowAddModal(false);
    setEditingTemplate(null);
    setName('');
    setFolder('General');
    setSubject('');
    setBodyHtml('');
  };

  const handleCreateTemplate = async (e: React.FormEvent) => {
    e.preventDefault();

    // Simple variable parser e.g. find all {{variable}}
    const varRegex = /\{\{([^}]+)\}\}/g;
    let match;
    const variables: string[] = [];
    while ((match = varRegex.exec(bodyHtml)) !== null) {
      const v = match[1].trim();
      if (!variables.includes(v)) {
        variables.push(v);
      }
    }

    try {
      const url = editingTemplate
        ? `${API_BASE}/api/v1/templates/${editingTemplate.id}`
        : `${API_BASE}/api/v1/templates/`;
      const method = editingTemplate ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          name,
          folder,
          subject,
          body_html: bodyHtml,
          variables,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        addToast(data.detail || `Failed to ${editingTemplate ? 'update' : 'create'} template.`, 'error');
        return;
      }

      handleCloseModal();
      fetchTemplates();
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteTemplate = async (id: string) => {
    if (!confirm('Are you sure you want to delete this template?')) return;

    try {
      await fetch(`${API_BASE}/api/v1/templates/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      fetchTemplates();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6 animate-slide-in">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-theme-primary font-display uppercase">Templates</h1>
          <p className="text-theme-muted text-sm mt-1 font-sans">Design reusable variables-compatible templates for campaigns.</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-sm transition-colors cursor-pointer uppercase tracking-wider"
        >
          <FontAwesomeIcon icon={Plus} className="h-4 w-4" />
          <span>New Template</span>
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-48">
          <FontAwesomeIcon icon={RefreshCw} className="h-8 w-8 text-theme-accent animate-spin" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.length === 0 ? (
            <div className="md:col-span-3 text-center py-16 text-theme-muted bg-theme-surface rounded-none border border-theme-border">
              <FontAwesomeIcon icon={FileText} className="h-10 w-10 mx-auto mb-3 text-theme-muted" />
              <p className="text-sm font-semibold text-[#60A5FA] font-sans">No templates saved</p>
              <p className="text-xs text-theme-muted mt-1 max-w-[280px] mx-auto font-sans">Design an email template to use in campaigns or drafts.</p>
            </div>
          ) : (
            templates.map((tpl) => (
              <div key={tpl.id} className="bg-theme-surface rounded-none p-6 border border-theme-border flex flex-col justify-between hover:shadow-none transition-shadow">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <span className="inline-flex items-center gap-1.5 text-xs px-2.5 py-1 bg-theme-app border border-theme-border rounded-none text-theme-secondary font-semibold">
                      <FontAwesomeIcon icon={Folder} className="h-3 w-3" />
                      <span>{tpl.folder}</span>
                    </span>
                    <div className="flex gap-1">
                      <button
                        onClick={() => setPreviewTemplate(tpl)}
                        className="p-1.5 text-theme-muted hover:text-theme-primary rounded-none hover:bg-theme-app transition-colors"
                        title="Preview"
                      >
                        <FontAwesomeIcon icon={Eye} className="h-4.5 w-4.5" />
                      </button>
                      <button
                        onClick={() => handleOpenEdit(tpl)}
                        className="p-1.5 text-theme-muted hover:text-theme-primary rounded-none hover:bg-theme-app transition-colors"
                        title="Edit Template"
                      >
                        <FontAwesomeIcon icon={Edit} className="h-4.5 w-4.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteTemplate(tpl.id)}
                        className="p-1.5 text-theme-muted hover:text-red-655 rounded-none hover:bg-red-500/10 transition-colors"
                        title="Delete"
                      >
                        <FontAwesomeIcon icon={Trash} className="h-4.5 w-4.5" />
                      </button>
                    </div>
                  </div>

                  <h3 className="font-bold text-lg text-theme-primary mb-1 font-sans">{tpl.name}</h3>
                  <p className="text-xs text-theme-muted mb-4 line-clamp-1">Subject: {tpl.subject}</p>
                  
                  <div className="bg-theme-app p-4 border border-theme-border rounded-none max-h-32 overflow-hidden text-xs text-theme-secondary leading-relaxed font-mono">
                    {tpl.body_html.replace(/<[^>]*>/g, '')}
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-theme-border flex justify-between items-center text-xs">
                  <div className="text-theme-muted">
                    Variables: {tpl.variables?.length > 0 ? tpl.variables.map((v: string) => `{{${v}}}`).join(', ') : 'None'}
                  </div>
                  <span className="text-theme-muted">{new Date(tpl.created_at).toLocaleDateString()}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Add / Edit Template Modal */}
      {(showAddModal || editingTemplate) && createPortal(
        <div className="modal-backdrop" onClick={handleCloseModal}>
          <div 
            className="modal-content bg-theme-surface border border-theme-border text-theme-primary rounded-none w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-6 py-4 border-b border-theme-border shrink-0">
              <h3 className="text-xl font-bold text-theme-primary font-sans">
                {editingTemplate ? 'Edit Email Template' : 'Create Email Template'}
              </h3>
              <button
                onClick={handleCloseModal}
                className="p-1.5 rounded-none hover:bg-theme-app transition-colors text-theme-muted"
              >
                <FontAwesomeIcon icon={X} className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTemplate} className="flex-1 flex flex-col min-h-0">
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Template Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Sponsorship Outreach V1"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Category Folder</label>
                    <select
                      value={folder}
                      onChange={(e) => setFolder(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    >
                      <option value="General">General</option>
                      <option value="Sponsorship">Sponsorship</option>
                      <option value="Recruitment">Recruitment</option>
                      <option value="Certificates">Certificates</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Email Subject Line</label>
                  <input
                    type="text"
                    required
                    placeholder="Partnership Opportunity with ThunderCipher Mailer - {{company}}"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-semibold uppercase text-theme-muted">Email Body (HTML/Text)</label>
                    <span className="text-xs text-theme-muted font-medium">Supported variables: &#123;&#123;name&#125;&#125;, &#123;&#123;company&#125;&#125;</span>
                  </div>
                  <textarea
                    required
                    rows={8}
                    placeholder="<p>Hi {{name}},</p><p>We love the work being done at {{company}}...</p>"
                    value={bodyHtml}
                    onChange={(e) => setBodyHtml(e.target.value)}
                    className="w-full p-3 bg-theme-surface border border-theme-input rounded-none text-sm font-mono placeholder-theme-muted focus:outline-none focus:border-theme-accent transition-colors resize-none text-theme-primary"
                  />
                </div>
              </div>

              <div className="px-6 py-4 border-t border-theme-border bg-theme-app/30 flex justify-end gap-3 shrink-0">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-4 py-2.5 bg-theme-surface border border-theme-border hover:bg-theme-hover rounded-none font-semibold text-sm transition-colors text-theme-primary"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-sm transition-colors uppercase tracking-wider"
                >
                  {editingTemplate ? 'Save Changes' : 'Create Template'}
                </button>
              </div>
            </form>
          </div>
        </div>,
        document.body
      )}

      {/* Preview Modal */}
      {previewTemplate && createPortal(
        <div className="modal-backdrop" onClick={() => setPreviewTemplate(null)}>
          <div 
            className="modal-content bg-theme-surface border border-theme-border text-theme-primary rounded-none w-full max-w-xl max-h-[90vh] flex flex-col overflow-hidden relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-6 py-4 border-b border-theme-border shrink-0">
              <div className="min-w-0">
                <h3 className="text-xl font-bold font-outfit text-theme-primary truncate">{previewTemplate.name}</h3>
                <p className="text-xs text-theme-muted truncate mt-0.5">Subject: {previewTemplate.subject}</p>
              </div>
              <button
                onClick={() => setPreviewTemplate(null)}
                className="p-1.5 rounded-none hover:bg-theme-hover transition-colors text-theme-muted shrink-0 ml-4"
              >
                <FontAwesomeIcon icon={X} className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 bg-theme-app/50">
              <div className="bg-theme-surface p-6 border border-theme-border rounded-none text-left shadow-none min-h-[200px]">
                <div 
                  className="text-sm prose prose-slate dark:prose-invert max-w-none text-theme-primary"
                  dangerouslySetInnerHTML={{ __html: previewTemplate.body_html }}
                />
              </div>
            </div>

            <div className="px-6 py-4 border-t border-theme-border bg-theme-app/30 flex justify-end shrink-0">
              <button
                onClick={() => setPreviewTemplate(null)}
                className="px-5 py-2.5 bg-theme-surface border border-theme-border hover:bg-theme-hover text-theme-primary rounded-none font-semibold text-sm transition-colors"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
