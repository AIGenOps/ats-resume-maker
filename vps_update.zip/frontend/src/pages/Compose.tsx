import React, { useState, useEffect, useRef } from 'react';
import { API_BASE } from '../config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faEnvelope as Mail, faShieldHalved as ShieldCheck, faPaperPlane as Send, faWandMagicSparkles as Sparkles, 
  faCalendarDays as Calendar, faXmark as X, faFileLines as FileText, faRotate as RefreshCw
} from '@fortawesome/free-solid-svg-icons';
import RichTextEditor from '../components/RichTextEditor';
import EmailChipsInput from '../components/EmailChipsInput';
import { useToast } from '../contexts/ToastContext';

interface ComposeProps {
  token: string;
}

export default function Compose({ token }: ComposeProps) {
  const { addToast } = useToast();
  const [templates, setTemplates] = useState<any[]>([]);
  const [smtpAccounts, setSmtpAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCc, setShowCc] = useState(false);
  const [showBcc, setShowBcc] = useState(false);

  // Form Fields
  const [smtpId, setSmtpId] = useState('');
  const [recipients, setRecipients] = useState<string[]>([]);
  const [cc, setCc] = useState<string[]>([]);
  const [bcc, setBcc] = useState<string[]>([]);
  const [subject, setSubject] = useState('');
  const [bodyHtml, setBodyHtml] = useState('');
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [attachments, setAttachments] = useState<any[]>([]);
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledTime, setScheduledTime] = useState('');
  const [isRippling, setIsRippling] = useState(false);
  const dateInputRef = useRef<HTMLInputElement>(null);

  // SMTP test status
  const [smtpStatus, setSmtpStatus] = useState<string | null>(null);
  const [testingSmtp, setTestingSmtp] = useState(false);

  // AI Copilot States
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiTone, setAiTone] = useState(localStorage.getItem('setting_default_tone') || 'professional');
  const [aiModel] = useState(localStorage.getItem('setting_ai_model') || 'gemini-2.5-flash');
  const [generatingAi, setGeneratingAi] = useState(false);
  const [aiError, setAiError] = useState('');

  useEffect(() => {
    fetchTemplates();
    fetchSmtpAccounts();

    // Check for pre-populated forward/reply data
    const prepopulated = sessionStorage.getItem('compose_prepopulated');
    if (prepopulated) {
      try {
        const parsed = JSON.parse(prepopulated);
        if (parsed.recipients) setRecipients(parsed.recipients);
        if (parsed.cc) {
          setCc(parsed.cc);
          setShowCc(true);
        }
        if (parsed.bcc) {
          setBcc(parsed.bcc);
          setShowBcc(true);
        }
        if (parsed.subject) setSubject(parsed.subject);
        if (parsed.body) setBodyHtml(parsed.body);
        if (parsed.smtpId) setSmtpId(parsed.smtpId);
        sessionStorage.removeItem('compose_prepopulated');
      } catch (e) {
        console.error(e);
      }
    }
  }, []);


  const fetchTemplates = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/templates/`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setTemplates(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchSmtpAccounts = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/smtp/`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      const list = Array.isArray(data) ? data : [];
      setSmtpAccounts(list);
      if (list.length > 0) {
        setSmtpId(list[0].id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleTemplateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const tplId = e.target.value;
    setSelectedTemplateId(tplId);
    if (!tplId) return;

    const tpl = templates.find((t) => t.id === tplId);
    if (tpl) {
      setSubject(tpl.subject || '');
      setBodyHtml(tpl.body_html || '');
    }
  };

  const testSmtp = async () => {
    if (!smtpId) {
      addToast("Please select an SMTP account first.", 'error');
      return;
    }
    setTestingSmtp(true);
    setSmtpStatus(null);
    try {
      const response = await fetch(`${API_BASE}/api/v1/smtp/${smtpId}/test`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        setSmtpStatus("Verified Connection");
      } else {
        const data = await response.json();
        setSmtpStatus(`Failed: ${data.detail}`);
      }
    } catch (err: any) {
      setSmtpStatus(`Error: ${err.message}`);
    } finally {
      setTestingSmtp(false);
    }
  };

  const handleAiGenerate = async () => {
    if (!aiPrompt.trim()) return;
    setGeneratingAi(true);
    setAiError('');
    try {
      const response = await fetch(`${API_BASE}/api/v1/mailbox/copilot/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          prompt: aiPrompt,
          tone: aiTone,
          model: aiModel
        })
      });
      if (!response.ok) {
        throw new Error('Failed to generate draft with AI');
      }
      const data = await response.json();
      if (data.draft) {
        setBodyHtml(data.draft);
        if (!subject) {
          const words = aiPrompt.split(' ').slice(0, 4).join(' ');
          setSubject(`Outreach regarding: ${words}...`);
        }
        addToast('AI Draft generated successfully!', 'success');
      }
    } catch (err: any) {
      setAiError(err.message || 'AI generation failed');
    } finally {
      setGeneratingAi(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files);
    
    files.forEach(file => {
      if (file.size > 2 * 1024 * 1024) {
        addToast(`File ${file.name} exceeds 2MB limit.`, 'error');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        setAttachments(prev => [...prev, {
          filename: file.name,
          mime_type: file.type,
          file_size: file.size,
          data: (reader.result as string).split(',')[1],
          formattedSize: (file.size / 1024).toFixed(1) + ' KB'
        }]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, idx) => idx !== index));
  };

  const handleDirectSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (recipients.length === 0) {
      addToast("Please specify at least one recipient.", 'error');
      return;
    }
    if (!subject.trim() || !bodyHtml.trim()) {
      addToast("Subject and Email Body are required.", 'error');
      return;
    }

    setIsRippling(true);
    await new Promise((resolve) => setTimeout(resolve, 600));
    setIsRippling(false);

    setLoading(true);
    try {
      const payload = {
        recipient_email: recipients.join(', '),
        cc: cc.length > 0 ? cc.join(', ') : null,
        bcc: bcc.length > 0 ? bcc.join(', ') : null,
        subject,
        body: bodyHtml,
        smtp_id: smtpId || null,
        attachments: attachments.map(a => ({
          filename: a.filename,
          content: a.data,
          mime_type: a.mime_type
        })),
        scheduled_time: isScheduled && scheduledTime ? new Date(scheduledTime).toISOString() : null
      };

      const response = await fetch(`${API_BASE}/api/v1/campaigns/send-direct`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      if (!response.ok) {
        let errorMessage = 'Failed to dispatch email.';
        if (data && data.detail) {
          if (typeof data.detail === 'string') {
            errorMessage = data.detail;
          } else if (Array.isArray(data.detail)) {
            errorMessage = data.detail.map((err: any) => `${err.loc.slice(1).join('.')}: ${err.msg}`).join(', ');
          } else {
            errorMessage = JSON.stringify(data.detail);
          }
        }
        throw new Error(errorMessage);
      }

      addToast(
        isScheduled 
          ? 'Outreach email scheduled successfully!' 
          : 'Outreach email dispatched successfully!', 
        'success'
      );
      
      // Clear Form fields
      setRecipients([]);
      setCc([]);
      setBcc([]);
      setSubject('');
      setBodyHtml('');
      setAttachments([]);
      setIsScheduled(false);
      setScheduledTime('');
    } catch (err: any) {
      addToast(`Outreach send failed: ${err.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  const triggerDatePicker = () => {
    setIsScheduled(true);
    setTimeout(() => {
      if (dateInputRef.current) {
        if (typeof dateInputRef.current.showPicker === 'function') {
          dateInputRef.current.showPicker();
        } else {
          dateInputRef.current.focus();
          dateInputRef.current.click();
        }
      }
    }, 50);
  };

  return (
    <div className="space-y-6 animate-slide-in text-theme-primary max-w-7xl mx-auto">
      <div>
        <h1 className="text-3xl font-extrabold tracking-tight text-theme-primary font-display uppercase flex items-center gap-3">
          <FontAwesomeIcon icon={Mail} className="h-8 w-8 text-theme-accent" />
          <span>Outreach Composer</span>
        </h1>
        <p className="text-theme-muted text-sm mt-1">Compose personalized outreach emails and test delivery live in a dedicated workspace.</p>
        <div className="m-stripe-divider mt-4" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Editor Form */}
        <div className="lg:col-span-2 bg-theme-surface border border-theme-border rounded-none p-6 relative overflow-hidden">
          <form onSubmit={handleDirectSend} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* SMTP Account */}
              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-xs font-semibold uppercase text-theme-muted">SMTP Account</label>
                  <button
                    type="button"
                    onClick={testSmtp}
                    disabled={testingSmtp}
                    className="text-xs font-bold text-theme-accent hover:text-theme-accentHover transition-colors flex items-center gap-1 cursor-pointer disabled:opacity-50"
                  >
                    <FontAwesomeIcon icon={ShieldCheck} className="h-3.5 w-3.5 text-role-signal" />
                    <span>{testingSmtp ? 'Checking...' : 'Test Connection'}</span>
                  </button>
                </div>
                <select
                  value={smtpId}
                  onChange={(e) => {
                    setSmtpId(e.target.value);
                    setSmtpStatus(null);
                  }}
                  className="w-full px-3 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:ring-0 transition-colors text-theme-primary cursor-pointer"
                >
                  {smtpAccounts.map((acc) => (
                    <option key={acc.id} value={acc.id} className="text-theme-primary bg-theme-surface">
                      {acc.name} ({acc.from_email})
                    </option>
                  ))}
                </select>
                {smtpStatus && (
                  <span className={`text-xs mt-1.5 block font-bold ${
                    smtpStatus.includes('Verified') ? 'text-role-signal' : 'text-role-danger'
                  }`}>{smtpStatus}</span>
                )}
              </div>

              {/* Template selection */}
              <div>
                <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Load Template</label>
                <select
                  value={selectedTemplateId}
                  onChange={handleTemplateChange}
                  className="w-full px-3 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:ring-0 transition-colors text-theme-primary cursor-pointer"
                >
                  <option value="">Choose a template...</option>
                  {templates.map((tpl) => (
                    <option key={tpl.id} value={tpl.id} className="text-theme-primary bg-theme-surface">
                      {tpl.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Recipient */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-xs font-semibold uppercase text-theme-muted">Recipient Email(s)</label>
                <div className="flex gap-2 text-xs font-semibold text-theme-muted">
                  <button
                    type="button"
                    onClick={() => setShowCc(!showCc)}
                    className={`hover:text-theme-accent transition-colors cursor-pointer ${showCc ? 'text-theme-accent font-bold' : ''}`}
                  >
                    {showCc ? 'Remove Cc' : '+ Cc'}
                  </button>
                  <span>|</span>
                  <button
                    type="button"
                    onClick={() => setShowBcc(!showBcc)}
                    className={`hover:text-theme-accent transition-colors cursor-pointer ${showBcc ? 'text-theme-accent font-bold' : ''}`}
                  >
                    {showBcc ? 'Remove Bcc' : '+ Bcc'}
                  </button>
                </div>
              </div>
              <EmailChipsInput
                emails={recipients}
                onChange={setRecipients}
                placeholder="name@company.com or comma separated list"
                icon={<FontAwesomeIcon icon={Mail} className="h-4 w-4" />}
                baseBgClass="bg-theme-surface border border-theme-input text-theme-primary focus-within:border-theme-accent focus-within:ring-2 focus-within:ring-theme-accent/20"
              />
            </div>

            {/* CC / BCC fields */}
            {(showCc || showBcc) && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-slide-in">
                {showCc ? (
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Cc</label>
                    <EmailChipsInput
                      emails={cc}
                      onChange={setCc}
                      placeholder="cc@company.com or list"
                      baseBgClass="bg-theme-surface border border-theme-input text-theme-primary focus-within:border-theme-accent focus-within:ring-2 focus-within:ring-theme-accent/20"
                    />
                  </div>
                ) : <div />}
                
                {showBcc ? (
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Bcc</label>
                    <EmailChipsInput
                      emails={bcc}
                      onChange={setBcc}
                      placeholder="bcc@company.com or list"
                      baseBgClass="bg-theme-surface border border-theme-input text-theme-primary focus-within:border-theme-accent focus-within:ring-2 focus-within:ring-theme-accent/20"
                    />
                  </div>
                ) : <div />}
              </div>
            )}

            {/* Subject */}
            <div>
              <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Subject Line</label>
              <input
                type="text"
                required
                placeholder="Partnership Proposal with ThunderCipher Mailer"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:ring-0 transition-colors text-theme-primary"
              />
            </div>

            {/* Editor */}
            <div>
              <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Email Body</label>
              <RichTextEditor value={bodyHtml} onChange={setBodyHtml} placeholder="Write your outreach text here..." />
            </div>

            {/* Attachments Section */}
            <div className="border border-theme-border bg-theme-app/50 p-4 rounded-none space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-semibold uppercase text-theme-muted">File Attachments (Max 2MB)</span>
                <label className="px-3 py-1.5 bg-theme-surface border border-theme-border hover:bg-theme-hover rounded-none text-xs font-bold cursor-pointer transition-colors text-theme-secondary">
                  <span>Add File</span>
                  <input
                    type="file"
                    multiple
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              </div>
              {attachments.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {attachments.map((file, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-2 rounded-none bg-theme-surface border border-theme-border text-xs text-theme-secondary animate-slide-in"
                    >
                      <div className="flex items-center gap-2 truncate">
                        <FontAwesomeIcon icon={FileText} className="h-4 w-4 text-role-creative shrink-0" />
                        <span className="text-xs truncate font-semibold">{file.filename}</span>
                        <span className="text-[10px] text-theme-muted">({file.formattedSize})</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeAttachment(idx)}
                        className="text-theme-muted hover:text-red-500 p-1 cursor-pointer"
                      >
                        <FontAwesomeIcon icon={X} className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Bottom Actions Row */}
            <div className="flex justify-between items-center border-t border-theme-border pt-4">
              {/* Left Side: Schedule */}
              <div>
                <button
                  type="button"
                  onClick={triggerDatePicker}
                  className="flex items-center gap-1.5 px-3 py-2 bg-theme-surface border border-theme-input hover:bg-theme-hover rounded-none text-xs font-semibold transition-all text-theme-secondary cursor-pointer"
                  title="Schedule email delivery for later"
                >
                  <FontAwesomeIcon icon={Calendar} className="h-4 w-4" />
                  <span>{isScheduled && scheduledTime ? 'Scheduled outreach' : 'Schedule Send'}</span>
                </button>

                {isScheduled && (
                  <div className="flex items-center gap-1.5 mt-2 animate-slide-in">
                    <input
                      ref={dateInputRef}
                      type="datetime-local"
                      required
                      value={scheduledTime}
                      onChange={(e) => setScheduledTime(e.target.value)}
                      className="px-2.5 py-1.5 bg-theme-surface border border-theme-input focus:border-theme-accent focus:ring-0 rounded-none text-xs font-semibold focus:outline-none text-theme-primary"
                    />
                    <span className="text-xs font-semibold text-theme-muted">{new Date(scheduledTime).toLocaleString()}</span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsScheduled(false);
                        setScheduledTime('');
                      }}
                      className="p-1 text-theme-muted hover:text-red-500 hover:bg-red-500/10 rounded-none cursor-pointer"
                      title="Remove schedule"
                    >
                      <FontAwesomeIcon icon={X} className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>

              {/* Right Side: Send Button */}
              <button
                type="submit"
                disabled={loading}
                className={`flex items-center justify-center gap-2 px-5 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-sm transition-all disabled:opacity-50 cursor-pointer shrink-0 relative uppercase tracking-wider ${isRippling ? 'animate-send-ripple' : ''}`}
              >
                <FontAwesomeIcon icon={Send} className="h-3.5 w-3.5" />
                <span>{loading ? 'Sending...' : 'Send Outreach'}</span>
              </button>
            </div>
          </form>
        </div>

        {/* AI Copilot Helper Sidebar */}
        <div className="bg-theme-surface border border-theme-border rounded-none p-6 space-y-4">
          <h2 className="text-base font-bold font-sans flex items-center gap-2 text-theme-primary">
            <FontAwesomeIcon icon={Sparkles} className="h-5 w-5 text-theme-accent" />
            <span>AI Drafting Copilot</span>
          </h2>
          <p className="text-xs text-theme-muted leading-relaxed">
            Write a prompt specifying your email goals. Our LLM parses and drafts the message body in real-time.
          </p>

          <div className="space-y-4 pt-2">
            <div>
              <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Drafting Instructions</label>
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="e.g. Write a friendly partnership email to Grace Harper about a collaboration opportunities with ThunderCipher Mailer..."
                rows={4}
                className="w-full p-3 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:ring-0 text-theme-primary resize-none placeholder-theme-muted"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Draft Tone</label>
              <select
                value={aiTone}
                onChange={(e) => setAiTone(e.target.value)}
                className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:ring-0 text-theme-primary cursor-pointer"
              >
                <option value="professional">Professional</option>
                <option value="friendly">Friendly</option>
                <option value="direct">Direct</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>

            {aiError && (
              <p className="text-xs text-red-500 font-semibold">{aiError}</p>
            )}

            <button
              type="button"
              disabled={generatingAi || !aiPrompt.trim()}
              onClick={handleAiGenerate}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-black border border-theme-border hover:bg-white hover:text-black text-white rounded-none text-xs font-bold transition-all disabled:opacity-40 cursor-pointer uppercase tracking-wider"
            >
              {generatingAi ? (
                <>
                  <FontAwesomeIcon icon={RefreshCw} className="h-4 w-4 animate-spin" />
                  <span>Drafting Output...</span>
                </>
              ) : (
                <>
                  <FontAwesomeIcon icon={Sparkles} className="h-4 w-4 text-theme-accent" />
                  <span>Generate AI Draft</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
