import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { API_BASE } from '../config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faPlay as Play, faPause as Pause, faTrashCan as Trash, faPlus as Plus, 
  faFileLines as FileText, faRotate as RefreshCw, faXmark as X, faChartSimple as BarChart, 
  faUpload as Upload, faBullhorn as Megaphone, faArrowLeft as ArrowLeft
} from '@fortawesome/free-solid-svg-icons';
import { useToast } from '../contexts/ToastContext';

interface CampaignsProps {
  token: string;
}

export default function Campaigns({ token }: CampaignsProps) {
  const { addToast } = useToast();
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [campaigns, setCampaigns] = useState<any[]>([]);
  const [templates, setTemplates] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedCampaign, setSelectedCampaign] = useState<any>(null);

  // Form State
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [sender, setSender] = useState('teams@thundercipher.in');
  const [targetTagId, setTargetTagId] = useState<string>('');
  
  // Advanced settings State
  const [sendDelay, setSendDelay] = useState(1);
  const [batchSize, setBatchSize] = useState(50);
  const [stopOnReply, setStopOnReply] = useState(true);
  const [maxRetries, setMaxRetries] = useState(3);
  const [trackOpens, setTrackOpens] = useState(false);
  const [weekdaysOnly, setWeekdaysOnly] = useState(true);
  const [sendWindowStart, setSendWindowStart] = useState('09:00');
  const [sendWindowEnd, setSendWindowEnd] = useState('17:00');
  const [warmupEnabled, setWarmupEnabled] = useState(false);
  const [warmupStartLimit, setWarmupStartLimit] = useState(10);
  const [warmupIncrement, setWarmupIncrement] = useState(5);
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  // Tag / Group upload inline helper
  const [showUploadSection, setShowUploadSection] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [uploadingGroup, setUploadingGroup] = useState(false);
  const [availableTags, setAvailableTags] = useState<any[]>([]);

  useEffect(() => {
    fetchCampaigns();
    fetchTemplates();
    fetchTags();
  }, []);

  useEffect(() => {
    // Set up auto-refresh interval for live campaign updates (15s)
    const interval = setInterval(() => {
      fetchCampaigns(true);
      if (selectedCampaign) {
        inspectCampaign(selectedCampaign.campaign.id);
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [selectedCampaign]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowAddModal(false);
      }
    };
    if (showAddModal) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => window.removeEventListener('keydown', handleEsc);
  }, [showAddModal]);

  const fetchCampaigns = async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/campaigns/`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setCampaigns(data);
      } else {
        setCampaigns([]);
        if (data && data.detail) {
          addToast(data.detail, 'error');
        }
      }
    } catch (e) {
      console.error(e);
      setCampaigns([]);
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const fetchTemplates = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/templates/`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setTemplates(data);
        if (data.length > 0) setTemplateId(data[0].id);
      } else {
        setTemplates([]);
      }
    } catch (e) {
      console.error(e);
      setTemplates([]);
    }
  };

  const fetchTags = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/tags`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setAvailableTags(data);
      }
    } catch (e) {
      console.error('Error fetching tags:', e);
    }
  };

  const handleCsvUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    if (!newGroupName.trim()) {
      addToast("Please enter a Group Name first.", 'error');
      e.target.value = '';
      return;
    }
    
    setUploadingGroup(true);
    const file = e.target.files[0];
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/import?default_tag=${encodeURIComponent(newGroupName.trim())}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData
      });
      
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || "Failed to upload group.");
      
      addToast(data.message || "Group uploaded and contacts tagged successfully!", 'success');
      await fetchTags();
      
      if (data.tag) {
        setTargetTagId(data.tag.id);
      }
      
      setNewGroupName('');
      setShowUploadSection(false);
    } catch (err: any) {
      addToast(err.message || "Failed to upload contacts.", 'error');
    } finally {
      setUploadingGroup(false);
      e.target.value = '';
    }
  };

  const handleCreateCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch(`${API_BASE}/api/v1/campaigns/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          name,
          description: description || null,
          template_id: templateId,
          sender,
          target_tag_id: targetTagId || null,
          send_delay_seconds: sendDelay,
          batch_size: batchSize,
          stop_on_reply: stopOnReply,
          max_retries: maxRetries,
          track_opens: trackOpens,
          weekdays_only: weekdaysOnly,
          send_window_start: sendWindowStart || null,
          send_window_end: sendWindowEnd || null,
          warmup_enabled: warmupEnabled,
          warmup_start_limit: warmupStartLimit,
          warmup_increment: warmupIncrement,
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        addToast(data.detail || 'Failed to create campaign.', 'error');
        return;
      }

      setName('');
      setDescription('');
      setTargetTagId('');
      setSendDelay(1);
      setBatchSize(50);
      setStopOnReply(true);
      setMaxRetries(3);
      setTrackOpens(false);
      setWeekdaysOnly(true);
      setSendWindowStart('09:00');
      setSendWindowEnd('17:00');
      setWarmupEnabled(false);
      setWarmupStartLimit(10);
      setWarmupIncrement(5);
      setShowAdvanced(false);
      setShowAddModal(false);
      fetchCampaigns();
    } catch (e) {
      console.error(e);
    }
  };

  const handleStartCampaign = async (campaignId: string) => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/campaigns/${campaignId}/start`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (!response.ok) {
        addToast(data.detail || 'Failed to start campaign.', 'error');
        return;
      }
      addToast(data.message, 'success');
      fetchCampaigns();
      if (selectedCampaign?.campaign.id === campaignId) {
        inspectCampaign(campaignId);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handlePauseCampaign = async (campaignId: string) => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/campaigns/${campaignId}/pause`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (!response.ok) {
        addToast(data.detail || 'Failed to pause campaign.', 'error');
        return;
      }
      addToast(data.message, 'success');
      fetchCampaigns();
      if (selectedCampaign?.campaign.id === campaignId) {
        inspectCampaign(campaignId);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteCampaign = async (campaignId: string) => {
    if (!confirm('Are you sure you want to delete this campaign and all its queued logs?')) return;
    try {
      await fetch(`${API_BASE}/api/v1/campaigns/${campaignId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      setSelectedCampaign(null);
      fetchCampaigns();
    } catch (e) {
      console.error(e);
    }
  };

  const inspectCampaign = async (campaignId: string) => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/campaigns/${campaignId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      setSelectedCampaign(data);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6 animate-slide-in text-theme-primary">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight font-display uppercase">Campaigns</h1>
          <p className="text-theme-muted text-sm mt-1 font-sans">Manage schedules, start sending buffers, and monitor delivery progress.</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-sm transition-colors cursor-pointer uppercase tracking-wider"
        >
          <FontAwesomeIcon icon={Plus} className="h-4 w-4" />
          <span>Create Campaign</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Campaign Lists */}
        <div className="bg-theme-surface rounded-none border border-theme-border lg:col-span-2 overflow-hidden">
          <div className="overflow-x-auto">
            {isMobile ? (
              <div className="divide-y divide-theme-border/50 bg-transparent">
                {campaigns.length === 0 ? (
                  <div className="p-8 text-center text-xs text-theme-muted">
                    No active outreach campaigns.
                  </div>
                ) : (
                  campaigns.map((camp) => (
                    <div
                      key={camp.id}
                      onClick={() => inspectCampaign(camp.id)}
                      className={`p-4 hover:bg-theme-hover/60 transition-colors flex flex-col gap-2 relative cursor-pointer ${
                        selectedCampaign?.campaign.id === camp.id ? 'bg-theme-accent/5' : ''
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-semibold text-theme-primary text-sm">{camp.name}</div>
                          <div className="text-theme-muted text-xs mt-0.5">Template ID: {camp.template_id.slice(0, 8)}...</div>
                        </div>
                        <span className={`text-[10px] px-2.5 py-0.5 rounded-none font-bold uppercase tracking-wider ${
                          camp.status === 'running' 
                            ? 'bg-role-signal/10 text-role-signal border border-role-signal/20'
                            : camp.status === 'completed'
                            ? 'bg-role-signal/15 text-role-signal border border-role-signal/20'
                            : 'bg-theme-app border border-theme-border text-theme-secondary'
                        }`}>
                          {camp.status}
                        </span>
                      </div>
                      <div className="text-xs text-theme-secondary">
                        Sender: <span className="text-theme-primary font-medium">{camp.sender}</span>
                      </div>
                      <div className="flex gap-2 justify-end mt-1" onClick={(e) => e.stopPropagation()}>
                        {camp.status !== 'running' && camp.status !== 'completed' ? (
                          <button
                            onClick={() => handleStartCampaign(camp.id)}
                            className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-emerald-600 transition-colors cursor-pointer"
                            title="Start Campaign"
                          >
                            <FontAwesomeIcon icon={Play} className="h-4 w-4" />
                          </button>
                        ) : camp.status === 'running' ? (
                          <button
                            onClick={() => handlePauseCampaign(camp.id)}
                            className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-amber-500 transition-colors cursor-pointer"
                            title="Pause Campaign"
                          >
                            <FontAwesomeIcon icon={Pause} className="h-4 w-4" />
                          </button>
                        ) : null}
                        <button
                          onClick={() => handleDeleteCampaign(camp.id)}
                          className="p-2 hover:bg-red-500/10 border border-theme-border hover:border-red-500/30 rounded-none text-theme-secondary hover:text-red-500 transition-colors cursor-pointer"
                          title="Delete Campaign"
                        >
                          <FontAwesomeIcon icon={Trash} className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            ) : (
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-theme-app/50 border-b border-theme-border text-theme-muted font-bold uppercase text-[10px] tracking-wider font-sans">
                    <th className="px-6 py-3">Campaign Name</th>
                    <th className="px-6 py-3">Sender Account</th>
                    <th className="px-6 py-3">Status</th>
                    <th className="px-6 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-theme-border/50">
                  {campaigns.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-16 text-center">
                        <div className="flex flex-col items-center justify-center space-y-3">
                          <FontAwesomeIcon icon={Megaphone} className="h-10 w-10 text-theme-muted" />
                          <p className="text-sm font-semibold text-[#60A5FA] font-sans">No active outreach campaigns</p>
                          <p className="text-xs text-theme-muted max-w-[280px] mx-auto font-sans">Create a campaign to start sending automated outreach sequences.</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    campaigns.map((camp) => (
                      <tr
                        key={camp.id}
                        onClick={() => inspectCampaign(camp.id)}
                        className={`cursor-pointer hover:bg-theme-hover/60 border-b border-theme-border/50 transition-colors ${
                          selectedCampaign?.campaign.id === camp.id ? 'bg-theme-accent/5 hover:bg-theme-accent/10' : ''
                        }`}
                      >
                        <td className="px-6 py-4">
                          <div className="font-semibold text-theme-primary text-sm">{camp.name}</div>
                          <div className="text-theme-muted text-xs mt-0.5">Template ID: {camp.template_id.slice(0, 8)}...</div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-theme-secondary text-sm">{camp.sender}</div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`text-xs px-2.5 py-0.5 rounded-none font-bold uppercase tracking-wider ${
                            camp.status === 'running' 
                              ? 'bg-role-signal/10 text-role-signal border border-role-signal/20'
                              : camp.status === 'completed'
                              ? 'bg-role-signal/15 text-role-signal border border-role-signal/20'
                              : 'bg-theme-app border border-theme-border text-theme-secondary'
                          }`}>
                            {camp.status}
                          </span>
                        </td>
                        <td className="px-6 py-4" onClick={(e) => e.stopPropagation()}>
                          <div className="flex gap-2 justify-end">
                            {camp.status !== 'running' && camp.status !== 'completed' ? (
                              <button
                                onClick={() => handleStartCampaign(camp.id)}
                                className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-emerald-600 transition-colors cursor-pointer"
                                title="Start Campaign"
                              >
                                <FontAwesomeIcon icon={Play} className="h-4 w-4" />
                              </button>
                            ) : camp.status === 'running' ? (
                              <button
                                onClick={() => handlePauseCampaign(camp.id)}
                                className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-amber-500 transition-colors cursor-pointer"
                                title="Pause Campaign"
                              >
                                <FontAwesomeIcon icon={Pause} className="h-4 w-4" />
                              </button>
                            ) : null}
                            <button
                              onClick={() => handleDeleteCampaign(camp.id)}
                              className="p-2 hover:bg-red-500/10 border border-theme-border hover:border-red-500/30 rounded-none text-theme-secondary hover:text-red-500 transition-colors cursor-pointer"
                              title="Delete Campaign"
                            >
                              <FontAwesomeIcon icon={Trash} className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Detailed Stats Panel */}
        {(!isMobile || selectedCampaign) && (
          <div className={isMobile 
            ? "fixed inset-0 z-[9999] overflow-y-auto bg-theme-app p-6 pb-28 flex flex-col space-y-6 animate-slide-up text-theme-primary" 
            : "bg-theme-surface rounded-none p-6 border border-theme-border"
          }>
            {isMobile && (
              <div className="flex items-center gap-3 pb-4 border-b border-theme-border shrink-0">
                <button
                  type="button"
                  onClick={() => setSelectedCampaign(null)}
                  className="p-2 -ml-2 text-theme-muted hover:text-theme-primary cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
                >
                  <FontAwesomeIcon icon={ArrowLeft} className="h-5 w-5" />
                </button>
                <h2 className="text-sm font-bold uppercase tracking-wider text-theme-accent">Campaign Performance</h2>
              </div>
            )}
            {selectedCampaign ? (
              <div className="space-y-6 animate-slide-in">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold font-outfit text-theme-primary">{selectedCampaign.campaign.name}</h3>
                    <p className="text-theme-muted text-xs font-semibold mt-1">Status: {selectedCampaign.campaign.status.toUpperCase()}</p>
                  </div>
                  <button
                    onClick={() => inspectCampaign(selectedCampaign.campaign.id)}
                    className="p-2 border border-theme-border rounded-none hover:bg-theme-app transition-colors"
                  >
                    <FontAwesomeIcon icon={RefreshCw} className="h-4 w-4 text-theme-muted" />
                  </button>
                </div>

                {selectedCampaign.campaign.description && (
                  <p className="text-sm text-theme-muted leading-relaxed">{selectedCampaign.campaign.description}</p>
                )}

                <hr className="border-theme-border" />

                {/* Statistics Grid */}
                <div className="space-y-4">
                  <h4 className="font-bold text-sm flex items-center gap-2">
                    <FontAwesomeIcon icon={BarChart} className="h-4 w-4 text-theme-accent" />
                    <span>Outreach Performance Statistics</span>
                  </h4>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                    <div className="p-3 bg-theme-app border border-theme-border rounded-none">
                      <div className="text-2xl font-bold font-outfit text-theme-primary">{selectedCampaign.stats.sent}</div>
                      <div className="text-xs text-theme-muted font-semibold uppercase mt-1">Sent</div>
                    </div>
                    <div className="p-3 bg-theme-app border border-theme-border rounded-none">
                      <div className="text-2xl font-bold font-outfit text-theme-accent">{selectedCampaign.stats.opened ?? 0}</div>
                      <div className="text-xs text-theme-muted font-semibold uppercase mt-1">Opened</div>
                    </div>
                    <div className="p-3 bg-theme-app border border-theme-border rounded-none">
                      <div className="text-2xl font-bold font-outfit text-amber-500">{selectedCampaign.stats.pending}</div>
                      <div className="text-xs text-theme-muted font-semibold uppercase mt-1">Queued</div>
                    </div>
                    <div className="p-3 bg-theme-app border border-theme-border rounded-none">
                      <div className="text-2xl font-bold font-outfit text-red-500">{selectedCampaign.stats.failed}</div>
                      <div className="text-xs text-theme-muted font-semibold uppercase mt-1">Failed</div>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div>
                    <div className="flex justify-between text-xs font-semibold mb-1.5">
                      <span>Campaign Delivery Progress</span>
                      <span>
                        {selectedCampaign.stats.total > 0
                          ? Math.round((selectedCampaign.stats.sent / selectedCampaign.stats.total) * 100)
                          : 0}
                        %
                      </span>
                    </div>
                    <div className="w-full bg-theme-app h-2.5 rounded-none overflow-hidden border border-theme-border/40">
                      <div
                        style={{
                          width: `${
                            selectedCampaign.stats.total > 0
                              ? (selectedCampaign.stats.sent / selectedCampaign.stats.total) * 100
                              : 0
                          }%`,
                        }}
                        className="bg-theme-accent h-full rounded-none transition-all duration-500"
                      />
                    </div>
                  </div>

                  <div className="pt-2 flex flex-col gap-1 text-xs text-theme-muted font-semibold">
                    <div className="flex justify-between">
                      <span>Targets Database: {selectedCampaign.stats.total} contacts</span>
                      <span>Estimated sending delay: {selectedCampaign.campaign.send_delay_seconds ?? 1}s/email</span>
                    </div>
                    <div>
                      <span>Target Group: <span className="text-theme-accent font-bold">{availableTags.find(t => t.id === selectedCampaign.campaign.target_tag_id)?.name || 'All Active Contacts (No Group)'}</span></span>
                    </div>
                  </div>

                  <hr className="border-theme-border" />

                  {/* Policy Settings */}
                  <div className="space-y-3 pt-2">
                    <h4 className="font-bold text-sm flex items-center gap-2">
                      <FontAwesomeIcon icon={FileText} className="h-4 w-4 text-theme-accent" />
                      <span>Campaign Policy Settings</span>
                    </h4>
                    <div className="grid grid-cols-2 gap-3 text-xs bg-theme-app p-3 rounded-none border border-theme-border text-theme-secondary">
                      <div>
                        <span className="text-theme-muted block font-semibold mb-0.5">Send Delay</span>
                        <span className="text-theme-primary font-medium">{selectedCampaign.campaign.send_delay_seconds ?? 1}s / email</span>
                      </div>
                      <div>
                        <span className="text-theme-muted block font-semibold mb-0.5">Batch Size</span>
                        <span className="text-theme-primary font-medium">{selectedCampaign.campaign.batch_size ?? 50} emails</span>
                      </div>
                      <div>
                        <span className="text-theme-muted block font-semibold mb-0.5">Max Retries</span>
                        <span className="text-theme-primary font-medium">{selectedCampaign.campaign.max_retries ?? 3} times</span>
                      </div>
                      <div>
                        <span className="text-theme-muted block font-semibold mb-0.5">Stop on Reply</span>
                        <span className="text-theme-primary font-medium">{(selectedCampaign.campaign.stop_on_reply ?? true) ? 'Enabled' : 'Disabled'}</span>
                      </div>
                      <div>
                        <span className="text-theme-muted block font-semibold mb-0.5">Weekdays Only</span>
                        <span className="text-theme-primary font-medium">{(selectedCampaign.campaign.weekdays_only ?? true) ? 'Yes' : 'No'}</span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-theme-muted block font-semibold mb-0.5">Sending Window (IST)</span>
                        <span className="text-theme-primary font-medium">
                          {selectedCampaign.campaign.send_window_start && selectedCampaign.campaign.send_window_end
                            ? `${selectedCampaign.campaign.send_window_start} - ${selectedCampaign.campaign.send_window_end}`
                            : 'Unlimited / All day'}
                        </span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-theme-muted block font-semibold mb-0.5">Warmup Mode</span>
                        <span className="text-theme-primary font-medium">
                          {(selectedCampaign.campaign.warmup_enabled ?? false)
                            ? `Active (Start: ${selectedCampaign.campaign.warmup_start_limit ?? 10}/day, +${selectedCampaign.campaign.warmup_increment ?? 5} daily)`
                            : 'Disabled'}
                        </span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-theme-muted block font-semibold mb-0.5">Open Tracking</span>
                        <span className="text-theme-primary font-medium">{(selectedCampaign.campaign.track_opens ?? false) ? 'Enabled (Pixel)' : 'Disabled'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-16 text-theme-muted flex flex-col justify-center items-center">
                <FontAwesomeIcon icon={BarChart} className="h-12 w-12 mb-3 text-theme-muted" />
                <p className="text-sm font-semibold">No Campaign Selected</p>
                <p className="text-xs text-theme-muted mt-1 max-w-[200px]">Select a campaign in the list to view live sending statistics, queue volumes, and progress metrics.</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add Campaign Modal */}
      {showAddModal && createPortal(
        <div className="modal-backdrop" onClick={() => setShowAddModal(false)}>
          <div 
            className="modal-content bg-theme-surface border border-theme-border text-theme-primary rounded-none w-full max-w-lg max-h-[90vh] flex flex-col overflow-hidden relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-6 py-4 border-b border-theme-border shrink-0">
              <h3 className="text-xl font-bold font-outfit text-theme-primary">Launch Outreach Campaign</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-none hover:bg-theme-app transition-colors text-theme-muted"
              >
                <FontAwesomeIcon icon={X} className="h-5 w-5" />
              </button>
            </div>

            {templates.length === 0 ? (
              <div className="flex-1 flex items-center justify-center p-6 text-center">
                <p className="text-sm text-theme-muted">You need to create at least one email template first.</p>
              </div>
            ) : (
              <form onSubmit={handleCreateCampaign} className="flex-1 flex flex-col min-h-0">
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Campaign Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Sponsorship outreach Summer 2026"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Email Template</label>
                    <select
                      value={templateId}
                      onChange={(e) => setTemplateId(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    >
                      <option value="">Select a template...</option>
                      {templates.map((t) => (
                        <option key={t.id} value={t.id}>{t.name} ({t.folder})</option>
                      ))}
                    </select>
                  </div>

                  {/* Target Tag Selector */}
                  <div>
                    <div className="flex justify-between items-center mb-1.5">
                      <label className="block text-xs font-semibold uppercase text-theme-muted">Target Group of Contacts</label>
                      <button
                        type="button"
                        onClick={() => setShowUploadSection(!showUploadSection)}
                        className="text-xs text-theme-accent font-bold hover:text-theme-accentHover transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <FontAwesomeIcon icon={Plus} className="h-3 w-3" />
                        <span>{showUploadSection ? 'Use Existing Group' : 'Upload New Group via CSV'}</span>
                      </button>
                    </div>

                    {!showUploadSection && (
                      <select
                        value={targetTagId}
                        onChange={(e) => setTargetTagId(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                      >
                        <option value="">All Contacts (No Group Filter)</option>
                        {availableTags.map((tag) => (
                          <option key={tag.id} value={tag.id}>{tag.name}</option>
                        ))}
                      </select>
                    )}
                  </div>

                  {showUploadSection && (
                    <div className="p-4 bg-theme-app/50 border border-theme-border rounded-none space-y-3.5">
                      <h4 className="text-xs font-bold text-theme-primary uppercase tracking-wider flex items-center gap-1.5">
                        <FontAwesomeIcon icon={Upload} className="h-3.5 w-3.5 text-theme-accent" />
                        <span>Create New Group from CSV</span>
                      </h4>
                      
                      <div>
                        <label className="block text-[10px] font-bold text-theme-muted uppercase mb-1">New Group Name</label>
                        <input
                          type="text"
                          placeholder="e.g. CTF Players 2026"
                          value={newGroupName}
                          onChange={(e) => setNewGroupName(e.target.value)}
                          disabled={uploadingGroup}
                          className="w-full px-3.5 py-2 bg-theme-surface border border-theme-input rounded-none text-xs focus:outline-none focus:border-theme-accent transition-colors text-theme-primary font-semibold disabled:opacity-50"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-theme-muted uppercase mb-1">Select CSV Sheet</label>
                        <input
                          type="file"
                          accept=".csv"
                          onChange={handleCsvUpload}
                          disabled={uploadingGroup}
                          className="w-full text-xs text-theme-muted file:mr-4 file:py-2 file:px-4 file:rounded-none file:border-0 file:text-xs file:font-semibold file:bg-theme-accent/20 file:text-theme-accent hover:file:bg-theme-accent/30 file:cursor-pointer disabled:opacity-50"
                        />
                      </div>
                      
                      {uploadingGroup && (
                        <span className="text-[10px] text-theme-accent font-semibold animate-pulse block">Uploading contacts and tagging group...</span>
                      )}
                    </div>
                  )}

                  {/* Collapsible Advanced Settings Accordion */}
                  <div className="border-t border-theme-border pt-4 mt-2">
                    <button
                      type="button"
                      onClick={() => setShowAdvanced(!showAdvanced)}
                      className="flex items-center justify-between w-full text-left text-xs font-semibold uppercase text-theme-muted hover:text-theme-primary transition-colors"
                    >
                      <span>Advanced Campaign Settings</span>
                      <span className="text-xs text-theme-muted font-bold px-2 py-0.5 bg-theme-app rounded-none">
                        {showAdvanced ? 'Hide Options' : 'Show Options'}
                      </span>
                    </button>
                    
                    {showAdvanced && (
                      <div className="mt-4 space-y-4 animate-slide-in">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">
                              Send Delay (seconds)
                            </label>
                            <input
                              type="number"
                              min="0"
                              value={sendDelay}
                              onChange={(e) => setSendDelay(parseInt(e.target.value) || 0)}
                              className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">
                              Batch Size
                            </label>
                            <input
                              type="number"
                              min="1"
                              value={batchSize}
                              onChange={(e) => setBatchSize(parseInt(e.target.value) || 1)}
                              className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">
                              Max Retries
                            </label>
                            <input
                              type="number"
                              min="0"
                              value={maxRetries}
                              onChange={(e) => setMaxRetries(parseInt(e.target.value) || 0)}
                              className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                            />
                          </div>
                          <div className="flex flex-col justify-end">
                            {/* empty spacer */}
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">
                              Send Window Start (IST)
                            </label>
                            <input
                              type="time"
                              value={sendWindowStart}
                              onChange={(e) => setSendWindowStart(e.target.value)}
                              className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">
                              Send Window End (IST)
                            </label>
                            <input
                              type="time"
                              value={sendWindowEnd}
                              onChange={(e) => setSendWindowEnd(e.target.value)}
                              className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                            />
                          </div>
                        </div>

                        <div className="flex flex-col gap-3 pt-2">
                          <label className="flex items-center gap-3 cursor-pointer select-none">
                            <input
                              type="checkbox"
                              checked={stopOnReply}
                              onChange={(e) => setStopOnReply(e.target.checked)}
                              className="custom-checkbox"
                            />
                            <span className="text-xs text-theme-secondary">Stop on Reply (Pause sending if recipient replies)</span>
                          </label>

                          <label className="flex items-center gap-3 cursor-pointer select-none">
                            <input
                              type="checkbox"
                              checked={trackOpens}
                              onChange={(e) => setTrackOpens(e.target.checked)}
                              className="custom-checkbox"
                            />
                            <span className="text-xs text-theme-secondary">Track Opens (Insert tracking pixel)</span>
                          </label>

                          <label className="flex items-center gap-3 cursor-pointer select-none">
                            <input
                              type="checkbox"
                              checked={weekdaysOnly}
                              onChange={(e) => setWeekdaysOnly(e.target.checked)}
                              className="custom-checkbox"
                            />
                            <span className="text-xs text-theme-secondary">Weekdays Only (Only send Monday to Friday)</span>
                          </label>

                          <label className="flex items-center gap-3 cursor-pointer select-none">
                            <input
                              type="checkbox"
                              checked={warmupEnabled}
                              onChange={(e) => setWarmupEnabled(e.target.checked)}
                              className="custom-checkbox"
                            />
                            <span className="text-xs text-theme-secondary">Enable Email Warmup Mode (Daily Volume Ramp-up)</span>
                          </label>
                        </div>

                        {warmupEnabled && (
                          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-theme-border">
                            <div>
                              <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">
                                Warmup Start Volume
                              </label>
                              <input
                                type="number"
                                min="1"
                                value={warmupStartLimit}
                                onChange={(e) => setWarmupStartLimit(parseInt(e.target.value) || 1)}
                                className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                              />
                            </div>
                            <div>
                              <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">
                                Daily Volume Increment
                              </label>
                              <input
                                type="number"
                                min="1"
                                value={warmupIncrement}
                                onChange={(e) => setWarmupIncrement(parseInt(e.target.value) || 1)}
                                className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                <div className="px-6 py-4 border-t border-theme-border bg-theme-app/30 flex justify-end gap-3 shrink-0">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2.5 bg-theme-surface hover:bg-theme-hover border border-theme-border rounded-none font-semibold text-sm transition-colors text-theme-secondary"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-sm transition-colors uppercase tracking-wider"
                  >
                    Create Campaign
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
