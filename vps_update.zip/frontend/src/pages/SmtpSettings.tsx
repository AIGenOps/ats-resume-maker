import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { API_BASE } from '../config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faPlus as Plus, faServer as Server, faTrashCan as Trash, 
  faRotate as RefreshCw, faXmark as X, faShieldHalved as ShieldCheck 
} from '@fortawesome/free-solid-svg-icons';
import { useToast } from '../contexts/ToastContext';

interface SmtpProps {
  token: string;
}

export default function SmtpSettings({ token }: SmtpProps) {
  const { addToast } = useToast();
  const [accounts, setAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [host, setHost] = useState('');
  const [port, setPort] = useState(587);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [fromEmail, setFromEmail] = useState('');
  const [dailyLimit, setDailyLimit] = useState(500);
  const [hourlyLimit, setHourlyLimit] = useState(50);
  const [testingId, setTestingId] = useState<string | null>(null);

  useEffect(() => {
    fetchSmtpAccounts();
  }, []);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowAddModal(false);
      }
    };
    if (showAddModal) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => window.removeEventListener('keydown', handleEsc);
  }, [showAddModal]);

  const fetchSmtpAccounts = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/smtp/`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setAccounts(data);
      } else {
        setAccounts([]);
        if (data && data.detail) {
          addToast(data.detail, 'error');
        }
      }
    } catch (e) {
      console.error(e);
      setAccounts([]);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSmtp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch(`${API_BASE}/api/v1/smtp/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          name,
          host,
          port: Number(port),
          username,
          password_encrypted: password, // Raw input simulated
          from_email: fromEmail,
          rate_limit_daily: Number(dailyLimit),
          rate_limit_hourly: Number(hourlyLimit),
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        addToast(data.detail || 'Failed to configure SMTP account.', 'error');
        return;
      }

      // Reset
      setName('');
      setHost('');
      setPort(587);
      setUsername('');
      setPassword('');
      setFromEmail('');
      setDailyLimit(500);
      setHourlyLimit(50);
      setShowAddModal(false);
      fetchSmtpAccounts();
    } catch (err) {
      console.error(err);
    }
  };

  const handleTestConnection = async (id: string) => {
    setTestingId(id);
    try {
      const response = await fetch(`${API_BASE}/api/v1/smtp/${id}/test`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (response.ok) {
        addToast('SMTP Connection verification successful! Authentication was completed.', 'success');
      } else {
        addToast(`SMTP Connection failed: ${data.detail}`, 'error');
      }
    } catch (err: any) {
      addToast(`SMTP Connection error: ${err.message}`, 'error');
    } finally {
      setTestingId(null);
    }
  };

  const handleDeleteSmtp = async (id: string) => {
    if (!confirm('Are you sure you want to delete this SMTP server?')) return;
    try {
      await fetch(`${API_BASE}/api/v1/smtp/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      fetchSmtpAccounts();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6 animate-slide-in text-theme-primary">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-theme-primary font-display uppercase">SMTP Gateways</h1>
          <p className="text-theme-muted text-sm mt-1 font-sans">Configure sender SMTP gateways, set rates, and test connections.</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-sm transition-colors cursor-pointer uppercase tracking-wider"
        >
          <FontAwesomeIcon icon={Plus} className="h-4 w-4" />
          <span>Add SMTP Server</span>
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {Array.from({ length: 2 }).map((_, idx) => (
            <div key={idx} className="bg-theme-surface rounded-none p-6 border border-theme-border/50 space-y-4">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <div className="h-5 bg-theme-border/50 rounded-none animate-pulse w-32" />
                  <div className="h-3.5 bg-theme-border/30 rounded-none animate-pulse w-48" />
                </div>
                <div className="flex gap-2">
                  <div className="h-8 bg-theme-border/40 rounded-none animate-pulse w-24" />
                  <div className="h-8 bg-theme-border/40 rounded-none animate-pulse w-8" />
                </div>
              </div>
              <hr className="border-theme-border/40" />
              <div className="grid grid-cols-2 gap-4">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="space-y-2">
                    <div className="h-3.5 bg-theme-border/40 rounded-none animate-pulse w-20" />
                    <div className="h-4 bg-theme-border/30 rounded-none animate-pulse w-28" />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {accounts.length === 0 ? (
            <div className="bg-theme-surface border border-theme-border rounded-none p-12 text-center md:col-span-2">
              <FontAwesomeIcon icon={Server} className="h-10 w-10 mx-auto mb-3 text-theme-muted" />
              <h3 className="text-sm font-bold text-theme-primary uppercase tracking-wider font-sans">No SMTP Configurations</h3>
              <p className="text-xs text-theme-muted mt-1 max-w-[280px] mx-auto font-sans">Configure an SMTP gateway to enable campaign dispatch and mailbox delivery services.</p>
            </div>
          ) : (
            accounts.map((acct) => (
              <div key={acct.id} className="bg-theme-surface rounded-none p-6 border border-theme-border space-y-4 hover:shadow-none hover:border-theme-accent transition-all duration-300">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-lg text-theme-primary font-sans">{acct.name}</h3>
                    <p className="text-xs text-theme-muted mt-0.5 font-sans">Host: {acct.host}:{acct.port}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleTestConnection(acct.id)}
                      disabled={testingId === acct.id}
                      className="px-3.5 py-2 bg-theme-surface hover:bg-theme-hover border border-theme-border rounded-none text-xs font-bold transition-all text-theme-secondary shrink-0 cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {testingId === acct.id ? <FontAwesomeIcon icon={RefreshCw} className="h-3.5 w-3.5 animate-spin" /> : <FontAwesomeIcon icon={ShieldCheck} className="h-4 w-4 text-theme-accent" />}
                      <span>{testingId === acct.id ? 'Checking...' : 'Test Connection'}</span>
                    </button>
                    <button
                      onClick={() => handleDeleteSmtp(acct.id)}
                      className="p-2.5 bg-red-500/10 hover:bg-red-500/20 text-red-655 border border-transparent rounded-none hover:border-red-500/20 transition-all cursor-pointer flex items-center justify-center shrink-0"
                      title="Delete Gateway"
                    >
                      <FontAwesomeIcon icon={Trash} className="h-4 w-4" />
                    </button>
                  </div>
                </div>

                <hr className="border-theme-border" />

                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-theme-muted font-semibold block uppercase text-[10px] tracking-wider">Username</span>
                    <span className="text-theme-secondary font-mono mt-1 block truncate" title={acct.username}>{acct.username}</span>
                  </div>
                  <div>
                    <span className="text-theme-muted font-semibold block uppercase text-[10px] tracking-wider">From Email Address</span>
                    <span className="text-theme-secondary font-mono mt-1 block truncate" title={acct.from_email}>{acct.from_email}</span>
                  </div>
                  <div>
                    <span className="text-theme-muted font-semibold block uppercase text-[10px] tracking-wider">Daily Send Limit</span>
                    <span className="text-theme-secondary mt-1 block font-bold text-sm">{acct.rate_limit_daily} emails</span>
                  </div>
                  <div>
                    <span className="text-theme-muted font-semibold block uppercase text-[10px] tracking-wider">Hourly Send Limit</span>
                    <span className="text-theme-secondary mt-1 block font-bold text-sm">{acct.rate_limit_hourly} emails</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Add SMTP Modal */}
      {showAddModal && createPortal(
        <div className="modal-backdrop" onClick={() => setShowAddModal(false)}>
          <div 
            className="modal-content bg-theme-surface border border-theme-border text-theme-primary rounded-none w-full max-w-lg max-h-[90vh] flex flex-col overflow-hidden relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-6 py-4 border-b border-theme-border shrink-0">
              <h3 className="text-xl font-bold font-outfit text-theme-primary">Register SMTP Mail Server</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-none hover:bg-theme-app transition-colors text-theme-muted"
              >
                <FontAwesomeIcon icon={X} className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSmtp} className="flex-1 flex flex-col min-h-0">
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Gateway Name</label>
                    <input
                      type="text"
                      required
                      placeholder="ThunderCipher Mailer primary SMTP"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Sender Email</label>
                    <input
                      type="email"
                      required
                      placeholder="teams@thundercipher.in"
                      value={fromEmail}
                      onChange={(e) => setFromEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">SMTP Host</label>
                    <input
                      type="text"
                      required
                      placeholder="smtp.gmail.com"
                      value={host}
                      onChange={(e) => setHost(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Port</label>
                    <input
                      type="number"
                      required
                      placeholder="587"
                      value={port}
                      onChange={(e) => setPort(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">SMTP Username</label>
                    <input
                      type="text"
                      required
                      placeholder="smtp_user"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">SMTP Password</label>
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Daily Quota (Emails)</label>
                    <input
                      type="number"
                      required
                      value={dailyLimit}
                      onChange={(e) => setDailyLimit(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Hourly Quota (Emails)</label>
                    <input
                      type="number"
                      required
                      value={hourlyLimit}
                      onChange={(e) => setHourlyLimit(Number(e.target.value))}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                    />
                  </div>
                </div>
              </div>

              <div className="px-6 py-4 border-t border-theme-border bg-theme-app/30 flex justify-end gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 bg-theme-surface border border-theme-border hover:bg-theme-hover rounded-none font-semibold text-sm transition-colors text-theme-primary"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-sm transition-colors uppercase tracking-wider"
                >
                  Save Configuration
                </button>
              </div>
            </form>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
