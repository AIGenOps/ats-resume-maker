import { useState, useEffect } from 'react';
import { API_BASE } from '../config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faUsers as Users, faPaperPlane as PaperPlaneTilt, faTriangleExclamation as Warning, faChartLine as Activity, 
  faRotate as ArrowsClockwise, faArrowTrendUp as ArrowUpRight, faArrowTrendDown as ArrowDownRight, 
  faCaretDown as CaretDown, faComments as MessageSquare, faShieldHalved as ShieldCheck, faChartSimple as ChartBar, faEnvelopeOpen as EnvelopeOpen
} from '@fortawesome/free-solid-svg-icons';

interface DashboardProps {
  token: string;
  onNavigate: (page: string) => void;
}

interface DashboardMetrics {
  total_contacts: number;
  active_campaigns: number;
  emails_sent_today: number;
  emails_queued: number;
  bounce_rate: string;
  emails_failed: number;
  smtp_health: string;
  domain_health: string;
  reply_rate?: string;
  open_rate?: string;
}

interface ActivityItem {
  id: string | number;
  action: string;
  details: string;
  timestamp: string;
}

interface RecentReplyItem {
  id: string | number;
  contact_name: string;
  contact_email: string;
  subject: string;
  snippet: string;
  received_at: string;
}

interface ChartPoint {
  index: number;
  x: number;
  y: number;
  value: number;
  label: string;
}

export default function Dashboard({ token, onNavigate }: DashboardProps) {
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);
  const [activeChartIndex, setActiveChartIndex] = useState(0);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [activity, setActivity] = useState<ActivityItem[]>([]);
  const [recentReplies, setRecentReplies] = useState<RecentReplyItem[]>([]);
  const [dailyTrend, setDailyTrend] = useState<{ label: string; value: number }[]>([]);
  const [monthlyPerformance, setMonthlyPerformance] = useState<{ label: string; value: number }[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activePoint, setActivePoint] = useState<ChartPoint | null>(null);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    setError('');
    try {
      const response = await fetch(`${API_BASE}/api/v1/dashboard/metrics`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || 'Failed to fetch dashboard metrics.');
      }
      setMetrics(data.metrics);
      setActivity(data.recent_activity || []);
      setDailyTrend(data.daily_trend || []);
      setMonthlyPerformance(data.monthly_performance || []);

      // Fetch recent replies from IMAP
      const repliesRes = await fetch(`${API_BASE}/api/v1/dashboard/recent-replies`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (repliesRes.ok) {
        const repliesData = await repliesRes.json();
        setRecentReplies(repliesData || []);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-96">
        <FontAwesomeIcon icon={ArrowsClockwise} className="h-8 w-8 text-theme-accent animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 bg-red-500/10 border border-red-500/20 text-red-500 rounded-none mb-6">
        Error loading dashboard data: {error}
      </div>
    );
  }

  // Calculate real delivery rate dynamically
  const emailsSentToday = metrics?.emails_sent_today || 0;
  const emailsFailed = metrics?.emails_failed || 0;
  const deliveryRate = emailsSentToday > 0 
    ? (((emailsSentToday - emailsFailed) / emailsSentToday) * 100).toFixed(1) + '%'
    : '0.0%';

  const deliveryVal = emailsSentToday > 0 
    ? ((emailsSentToday - emailsFailed) / emailsSentToday) * 100 
    : 100;
  const bounceVal = parseFloat(metrics?.bounce_rate || '0.0');

  const renderProgressIcon = (icon: React.ReactNode, value: number, colorClass: string, bgClass: string) => {
    const radius = 18;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (Math.min(100, Math.max(0, value)) / 100) * circumference;
    
    return (
      <div className="relative w-12 h-12 flex items-center justify-center shrink-0 select-none">
        <svg className="absolute inset-0 w-full h-full transform -rotate-90">
          <circle
            cx="24"
            cy="24"
            r={radius}
            className="stroke-[#202226]/30"
            strokeWidth="2"
            fill="transparent"
          />
          <circle
            cx="24"
            cy="24"
            r={radius}
            className={colorClass}
            strokeWidth="2"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            fill="transparent"
          />
        </svg>
        <div className={`w-8.5 h-8.5 rounded-lg flex items-center justify-center text-white ${bgClass} relative z-10 shadow-sm`}>
          {icon}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6 animate-slide-in relative select-none text-left">
      {/* Hero Visual Bleed Banner (Solid black + dark gradient background) */}
      <div className="absolute top-[-16px] left-[-16px] right-[-16px] h-32 pointer-events-none select-none z-0 bg-gradient-to-b from-[#121316] to-black" />

      {isMobile ? (
        <div className="flex justify-between items-center pb-2 shrink-0 bg-transparent relative z-10 pt-4">
          <h1 className="text-3xl font-extrabold tracking-tight text-white capitalize font-heading" style={{ fontFamily: 'var(--font-heading)' }}>
            Dashboard
          </h1>
          <div className="w-10 h-10 rounded-full bg-theme-accent text-theme-btnText flex items-center justify-center font-bold text-sm select-none border border-theme-border/20">
            {(() => {
              const name = localStorage.getItem('setting_sender_name') || 'JD';
              const parts = name.trim().split(/\s+/);
              if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
              return parts[0].slice(0, 2).toUpperCase();
            })()}
          </div>
        </div>
      ) : (
        <div className="flex justify-between items-center relative z-10 pt-4 pb-2">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-theme-primary font-heading uppercase" style={{ fontFamily: 'var(--font-heading)' }}>Dashboard</h1>
            <p className="text-theme-muted text-xs font-semibold mt-1 font-sans">Real-time mail dispatch intelligence and relay metrics.</p>
          </div>
          
          <div className="flex items-center gap-3 relative z-10">
            <button
              onClick={fetchDashboardData}
              className="p-2 bg-theme-surface border border-theme-border rounded-none hover:bg-theme-hover text-theme-muted hover:text-theme-primary transition-all cursor-pointer"
              title="Refresh Dashboard"
            >
              <FontAwesomeIcon icon={ArrowsClockwise} className="h-4.5 w-4.5" />
            </button>
          </div>
        </div>
      )}

      {/* Live animated gradient signature moment */}
      <div className="live-gradient-line relative z-10 mb-6 h-[4px] w-full" />

      {/* Top metrics row cards: varied card visual weight (bolder borders + blue glow elevation) */}
      {isMobile ? (
        <div className="space-y-4 relative z-10">
          {/* Featured Hero Stat Card: Outreach Sent */}
          <div 
            style={{ animationDelay: '0ms', animationFillMode: 'both' }}
            className="p-5 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in mobile-card bg-theme-surface/50 w-full"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 flex items-center justify-center bg-[#0FA336] rounded-2xl text-white shrink-0 shadow-[0_4px_12px_rgba(15,163,54,0.3)]">
                  <FontAwesomeIcon icon={PaperPlaneTilt} className="text-3xl" />
                </div>
                <div className="flex flex-col">
                  <span className="text-theme-muted text-[10px] font-bold uppercase tracking-wider font-sans">Outreach Sent</span>
                  <h3 className="text-2xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums mt-0.5">
                    {metrics?.emails_sent_today || 0}
                  </h3>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs font-bold text-theme-accent font-sans">{metrics?.emails_queued || 0} queued</span>
                <p className="text-[10px] text-theme-muted mt-0.5">in buffer</p>
              </div>
            </div>
          </div>

          {/* 2-Column Grid for remaining metrics */}
          <div className="grid grid-cols-2 gap-4">
            {/* Total Directory */}
            <div 
              style={{ animationDelay: '30ms', animationFillMode: 'both' }}
              className="p-4 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in mobile-card bg-theme-surface/50"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 flex items-center justify-center bg-[#374151] rounded-xl text-white shrink-0">
                  <FontAwesomeIcon icon={Users} />
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="text-theme-muted text-[9px] font-bold uppercase tracking-wider font-sans truncate">Directory</span>
                  <h3 className="text-xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums mt-0.5">{metrics?.total_contacts || 0}</h3>
                </div>
              </div>
            </div>

            {/* Active Campaigns */}
            <div 
              style={{ animationDelay: '60ms', animationFillMode: 'both' }}
              className="p-4 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in mobile-card bg-theme-surface/50"
            >
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 flex items-center justify-center bg-[#1C69D4] rounded-xl text-white shrink-0">
                  <FontAwesomeIcon icon={Activity} />
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="text-theme-muted text-[9px] font-bold uppercase tracking-wider font-sans truncate">Campaigns</span>
                  <h3 className="text-xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums mt-0.5">{metrics?.active_campaigns || 0}</h3>
                </div>
              </div>
            </div>

            {/* Delivery Success */}
            <div 
              style={{ animationDelay: '90ms', animationFillMode: 'both' }}
              className="p-4 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in mobile-card bg-theme-surface/50"
            >
              <div className="flex items-center gap-3">
                {renderProgressIcon(<FontAwesomeIcon icon={ShieldCheck} />, deliveryVal, 'stroke-[#0FA336]', 'bg-[#0FA336]')}
                <div className="flex flex-col min-w-0">
                  <span className="text-theme-muted text-[9px] font-bold uppercase tracking-wider font-sans truncate">Delivery</span>
                  <h3 className="text-xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums mt-0.5">{deliveryRate}</h3>
                </div>
              </div>
            </div>

            {/* Bounce Rate */}
            <div 
              style={{ animationDelay: '120ms', animationFillMode: 'both' }}
              className="p-4 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in mobile-card bg-theme-surface/50"
            >
              <div className="flex items-center gap-3">
                {renderProgressIcon(<FontAwesomeIcon icon={Warning} />, bounceVal, 'stroke-[#E22718]', 'bg-[#E22718]')}
                <div className="flex flex-col min-w-0">
                  <span className="text-theme-muted text-[9px] font-bold uppercase tracking-wider font-sans truncate">Bounce Rate</span>
                  <h3 className="text-xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums mt-0.5">{metrics?.bounce_rate || '0.0%'}</h3>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 relative z-10">
          {/* Card 1: Total Directory */}
          <div 
            style={{ animationDelay: '0ms', animationFillMode: 'both' }}
            className="p-6 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in bg-theme-surface rounded-none"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center bg-[#374151] rounded-xl text-white shrink-0">
                <FontAwesomeIcon icon={Users} />
              </div>
              <span className="text-theme-muted text-[10px] font-bold uppercase tracking-wider font-sans">Total Directory</span>
            </div>
            <div className="mt-4">
              <h3 className="text-2xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums">{metrics?.total_contacts || 0}</h3>
            </div>
          </div>

          {/* Card 2: Active Campaigns */}
          <div 
            style={{ animationDelay: '35ms', animationFillMode: 'both' }}
            className="p-6 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in bg-theme-surface rounded-none"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center bg-[#1C69D4] rounded-xl text-white shrink-0">
                <FontAwesomeIcon icon={Activity} />
              </div>
              <span className="text-theme-muted text-[10px] font-bold uppercase tracking-wider font-sans">Active Campaigns</span>
            </div>
            <div className="mt-4">
              <h3 className="text-2xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums">{metrics?.active_campaigns || 0}</h3>
            </div>
          </div>

          {/* Card 3: Outreach Sent */}
          <div 
            style={{ animationDelay: '70ms', animationFillMode: 'both' }}
            className="p-6 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in bg-theme-surface rounded-none"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center bg-[#0FA336] rounded-xl text-white shrink-0">
                <FontAwesomeIcon icon={PaperPlaneTilt} />
              </div>
              <span className="text-theme-muted text-[10px] font-bold uppercase tracking-wider font-sans">Outreach Sent</span>
            </div>
            <div className="mt-4">
              <h3 className="text-2xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums">
                {metrics?.emails_sent_today || 0}
              </h3>
              <div className="mt-1 flex items-center gap-1 text-[10px] font-medium text-theme-muted font-sans tabular-nums">
                <span>{metrics?.emails_queued || 0} queued in buffer</span>
              </div>
            </div>
          </div>

          {/* Card 4: Delivery Success */}
          <div 
            style={{ animationDelay: '105ms', animationFillMode: 'both' }}
            className="p-6 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in bg-theme-surface rounded-none"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center bg-[#0FA336] rounded-xl text-white shrink-0">
                <FontAwesomeIcon icon={ShieldCheck} />
              </div>
              <span className="text-theme-muted text-[10px] font-bold uppercase tracking-wider font-sans">Delivery Success</span>
            </div>
            <div className="mt-4">
              <h3 className="text-2xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums">
                {deliveryRate}
              </h3>
            </div>
          </div>

          {/* Card 5: Bounce Rate */}
          <div 
            style={{ animationDelay: '140ms', animationFillMode: 'both' }}
            className="p-6 border border-theme-border flex flex-col justify-between transition-all duration-300 animate-fade-in bg-theme-surface rounded-none"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 flex items-center justify-center bg-[#E22718] rounded-xl text-white shrink-0">
                <FontAwesomeIcon icon={Warning} />
              </div>
              <span className="text-theme-muted text-[10px] font-bold uppercase tracking-wider font-sans">Bounce Rate</span>
            </div>
            <div className="mt-4">
              <h3 className="text-2xl font-extrabold tracking-tight text-theme-primary font-sans tabular-nums">
                {metrics?.bounce_rate || '0.0%'}
              </h3>
              <div className="mt-1 flex items-center gap-1 text-[10px] font-bold text-role-danger font-sans">
                <FontAwesomeIcon icon={ArrowDownRight} className="w-3 h-3" />
                <span>Failed: {metrics?.emails_failed || 0}</span>
              </div>
            </div>
          </div>
        </div>
      )}
      {isMobile ? (
        <div className="space-y-4 relative z-10">
          {/* Swiper wrapper card */}
          {activeChartIndex === 0 ? (
            <div className={`p-5 border border-theme-border bg-theme-surface ${isMobile ? 'mobile-card' : 'rounded-none'} space-y-4 relative overflow-hidden transition-all duration-300 animate-slide-in`}>
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-xs font-bold uppercase tracking-wider text-theme-secondary font-sans">Send Volume Trend</h2>
                  <p className="text-[10px] text-theme-muted font-sans">Daily dispatched outreach volume trend lines.</p>
                </div>
                <div className="relative">
                  <select className="bg-theme-app border border-theme-border rounded-none px-3 py-1.5 text-[10px] font-bold text-theme-secondary hover:text-theme-primary appearance-none cursor-pointer pr-8 focus:outline-none transition-colors">
                    <option>Last 7 Days</option>
                  </select>
                  <FontAwesomeIcon icon={CaretDown} className="absolute right-3 top-2.5 pointer-events-none text-theme-muted w-3 h-3" />
                </div>
              </div>

              <div className="relative h-56 w-full flex items-center justify-center pt-2">
                {dailyTrend.length === 0 ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#121216]/95 z-20 p-6 text-center select-none">
                    <FontAwesomeIcon icon={ChartBar} className="text-theme-muted mb-2 text-3xl" />
                    <h3 className="text-xs font-bold text-theme-primary uppercase tracking-wider font-sans">No Outreach Logged</h3>
                    <p className="text-[10px] text-theme-muted mt-1 max-w-[240px] leading-relaxed font-sans">
                      Daily email volume will be mapped here once outreach is active.
                    </p>
                  </div>
                ) : null}

                {dailyTrend.length > 0 && (() => {
                  const maxVolumeVal = Math.max(...dailyTrend.map(d => d.value), 10);
                  const trendPoints = dailyTrend.map((d, idx) => {
                    const x = 30 + (idx * 440 / (dailyTrend.length - 1 || 1));
                    const y = 170 - (d.value * 140 / maxVolumeVal);
                    return { x, y, value: d.value, label: d.label };
                  });
                  const linePath = trendPoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x},${p.y}`).join(' ');
                  const areaPath = `M 30,170 ${trendPoints.map(p => `L ${p.x},${p.y}`).join(' ')} L 470,170 Z`;

                  return (
                    <svg viewBox="0 0 500 200" className="w-full h-full overflow-visible">
                      <defs>
                        <linearGradient id="smoothAreaGradMobile" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#1C69D4" stopOpacity="0.25" />
                          <stop offset="100%" stopColor="#1C69D4" stopOpacity="0.0" />
                        </linearGradient>
                      </defs>
                      <line x1="30" y1="30" x2="470" y2="30" className="stroke-theme-border/30 stroke-1" strokeDasharray="3 3" />
                      <line x1="30" y1="100" x2="470" y2="100" className="stroke-theme-border/30 stroke-1" strokeDasharray="3 3" />
                      <line x1="30" y1="170" x2="470" y2="170" className="stroke-theme-border/60 stroke-1" />

                      {dailyTrend.map((d, idx) => (
                        <text key={idx} x={30 + (idx * 440 / (dailyTrend.length - 1 || 1))} y="188" className="fill-theme-muted text-[10px] font-bold font-sans" textAnchor="middle">
                          {d.label}
                        </text>
                      ))}

                      <text x="18" y="34" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">{maxVolumeVal}</text>
                      <text x="18" y="104" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">{Math.round(maxVolumeVal / 2)}</text>
                      <text x="18" y="174" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">0</text>

                      <path d={areaPath} fill="url(#smoothAreaGradMobile)" />
                      <path d={linePath} fill="none" stroke="#1C69D4" strokeWidth="2.5" />

                      {trendPoints.map((p, idx) => {
                        const isHovered = activePoint?.index === idx;
                        return (
                          <circle
                            key={idx}
                            cx={p.x}
                            cy={p.y}
                            r={isHovered ? 6.5 : 4}
                            className="fill-[#1C69D4] stroke-theme-surface stroke-2 cursor-pointer transition-all"
                            onMouseEnter={() => setActivePoint({ index: idx, x: p.x, y: p.y, value: p.value, label: p.label })}
                            onMouseLeave={() => setActivePoint(null)}
                          />
                        );
                      })}

                      {activePoint && (
                        <g>
                          <rect
                            x={activePoint.x - 45}
                            y={activePoint.y - 32}
                            width="90"
                            height="22"
                            rx="0"
                            className="fill-slate-950 border border-theme-border"
                          />
                          <text
                            x={activePoint.x}
                            y={activePoint.y - 18}
                            className="fill-white text-[9px] font-bold font-sans"
                            textAnchor="middle"
                          >
                            {activePoint.label}: {activePoint.value}
                          </text>
                        </g>
                      )}
                    </svg>
                  );
                })()}
              </div>
            </div>
          ) : (
            <div className={`p-5 border border-theme-border bg-theme-surface ${isMobile ? 'mobile-card' : 'rounded-none'} space-y-4 relative overflow-hidden transition-all duration-300 animate-slide-in`}>
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-xs font-bold uppercase tracking-wider text-theme-secondary font-sans">Campaign Performance</h2>
                  <p className="text-[10px] text-theme-muted font-sans">Average recipient email open-rate metrics per month.</p>
                </div>
                <div className="relative">
                  <select className="bg-theme-app border border-theme-border rounded-none px-3 py-1.5 text-[10px] font-bold text-theme-secondary hover:text-theme-primary appearance-none cursor-pointer pr-8 focus:outline-none transition-colors">
                    <option>Last 6 Months</option>
                  </select>
                  <FontAwesomeIcon icon={CaretDown} className="absolute right-3 top-2.5 pointer-events-none text-theme-muted w-3 h-3" />
                </div>
              </div>

              <div className="relative h-56 w-full flex items-center justify-center pt-2">
                {monthlyPerformance.length === 0 ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#121216]/95 z-20 p-6 text-center select-none">
                    <FontAwesomeIcon icon={Activity} className="text-theme-muted mb-2 text-3xl" />
                    <h3 className="text-xs font-bold text-theme-primary uppercase tracking-wider font-sans">No Campaign Activity</h3>
                    <p className="text-[10px] text-theme-muted mt-1 max-w-[240px] leading-relaxed font-sans">
                      Monthly open rates and click analytics will register here.
                    </p>
                  </div>
                ) : null}

                {monthlyPerformance.length > 0 && (
                  <svg viewBox="0 0 500 200" className="w-full h-full overflow-visible">
                    <line x1="30" y1="30" x2="470" y2="30" className="stroke-theme-border/30 stroke-1" strokeDasharray="3 3" />
                    <line x1="30" y1="100" x2="470" y2="100" className="stroke-theme-border/30 stroke-1" strokeDasharray="3 3" />
                    <line x1="30" y1="170" x2="470" y2="170" className="stroke-theme-border/60 stroke-1" />

                    <text x="18" y="34" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">100%</text>
                    <text x="18" y="104" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">50%</text>
                    <text x="18" y="174" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">0%</text>

                    {monthlyPerformance.map((d, idx) => {
                      const barWidth = 28;
                      const totalBars = monthlyPerformance.length;
                      const space = (440 - (totalBars * barWidth)) / (totalBars + 1);
                      const xOffset = 30 + space + (idx * (barWidth + space));
                      const barHeight = d.value * 140 / 100;
                      const yOffset = 170 - barHeight;
                      const colors = ['#0066b1', '#0FA336', '#E22718', '#1C69D4', '#0653b6', '#7E7E7E'];
                      const barColor = colors[idx % colors.length];

                      return (
                        <g key={idx}>
                          <rect x={xOffset} y={yOffset} width={barWidth} height={barHeight} rx="0" fill={barColor} />
                          <text x={xOffset + barWidth / 2} y={yOffset - 6} className="fill-theme-secondary text-[9px] font-bold font-sans" textAnchor="middle">
                            {d.value}%
                          </text>
                          <text x={xOffset + barWidth / 2} y="188" className="fill-theme-muted text-[10px] font-bold font-sans" textAnchor="middle">
                            {d.label}
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                )}
              </div>
            </div>
          )}

          {/* Dots indicators */}
          <div className="flex justify-center items-center gap-2 pt-1">
            {[0, 1].map((idx) => (
              <button
                key={idx}
                onClick={() => setActiveChartIndex(idx)}
                className={`h-2.5 w-2.5 rounded-full transition-colors cursor-pointer ${
                  activeChartIndex === idx ? 'bg-theme-accent' : 'bg-theme-border'
                }`}
                title={`Chart ${idx + 1}`}
              />
            ))}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 relative z-10">
          
          {/* Chart 1: Send Volume Over Time */}
          <div className="bg-theme-surface border border-theme-border p-7 rounded-none space-y-4 relative overflow-hidden transition-all duration-300 animate-slide-in">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xs font-bold uppercase tracking-wider text-theme-secondary font-sans">Send Volume Trend</h2>
                <p className="text-[10px] text-theme-muted font-sans">Daily dispatched outreach volume trend lines.</p>
              </div>
              
              <div className="relative">
                <select className="bg-theme-app border border-theme-border rounded-none px-3 py-1.5 text-[10px] font-bold text-theme-secondary hover:text-theme-primary appearance-none cursor-pointer pr-8 focus:outline-none transition-colors">
                  <option>Last 7 Days</option>
                </select>
                <FontAwesomeIcon icon={CaretDown} className="absolute right-3 top-2.5 pointer-events-none text-theme-muted w-3 h-3" />
              </div>
            </div>

            <div className="relative h-56 w-full flex items-center justify-center pt-2">
              {dailyTrend.length === 0 ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#121216]/95 z-20 p-6 text-center select-none">
                  <FontAwesomeIcon icon={ChartBar} className="text-theme-muted mb-2 text-3xl" />
                  <h3 className="text-xs font-bold text-theme-primary uppercase tracking-wider font-sans">No Outreach Logged</h3>
                  <p className="text-[10px] text-theme-muted mt-1 max-w-[240px] leading-relaxed font-sans">
                    Daily dispatched email volume will be mapped here once automated campaigns or manual outreach mails are dispatched.
                  </p>
                </div>
              ) : null}

              {dailyTrend.length > 0 && (() => {
                const maxVolumeVal = Math.max(...dailyTrend.map(d => d.value), 10);
                const trendPoints = dailyTrend.map((d, idx) => {
                  const x = 30 + (idx * 440 / (dailyTrend.length - 1 || 1));
                  const y = 170 - (d.value * 140 / maxVolumeVal);
                  return { x, y, value: d.value, label: d.label };
                });
                const linePath = trendPoints.map((p, idx) => `${idx === 0 ? 'M' : 'L'} ${p.x},${p.y}`).join(' ');
                const areaPath = `M 30,170 ${trendPoints.map(p => `L ${p.x},${p.y}`).join(' ')} L 470,170 Z`;

                return (
                  <svg viewBox="0 0 500 200" className="w-full h-full overflow-visible">
                    <defs>
                      <linearGradient id="smoothAreaGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#1C69D4" stopOpacity="0.25" />
                        <stop offset="100%" stopColor="#1C69D4" stopOpacity="0.0" />
                      </linearGradient>
                    </defs>

                    <line x1="30" y1="30" x2="470" y2="30" className="stroke-theme-border/30 stroke-1" strokeDasharray="3 3" />
                    <line x1="30" y1="100" x2="470" y2="100" className="stroke-theme-border/30 stroke-1" strokeDasharray="3 3" />
                    <line x1="30" y1="170" x2="470" y2="170" className="stroke-theme-border/60 stroke-1" />

                    {dailyTrend.map((d, idx) => (
                      <text key={idx} x={30 + (idx * 440 / (dailyTrend.length - 1 || 1))} y="188" className="fill-theme-muted text-[10px] font-bold font-sans" textAnchor="middle">
                        {d.label}
                      </text>
                    ))}

                    <text x="18" y="34" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">{maxVolumeVal}</text>
                    <text x="18" y="104" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">{Math.round(maxVolumeVal / 2)}</text>
                    <text x="18" y="174" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">0</text>

                    <path d={areaPath} fill="url(#smoothAreaGrad)" />
                    <path d={linePath} fill="none" stroke="#1C69D4" strokeWidth="2.5" />

                    {trendPoints.map((p, idx) => {
                      const isHovered = activePoint?.index === idx;
                      return (
                        <circle
                          key={idx}
                          cx={p.x}
                          cy={p.y}
                          r={isHovered ? 6.5 : 4}
                          className="fill-[#1C69D4] stroke-theme-surface stroke-2 cursor-pointer transition-all"
                          onMouseEnter={() => setActivePoint({ index: idx, x: p.x, y: p.y, value: p.value, label: p.label })}
                          onMouseLeave={() => setActivePoint(null)}
                        />
                      );
                    })}

                    {activePoint && (
                      <g>
                        <rect
                          x={activePoint.x - 45}
                          y={activePoint.y - 32}
                          width="90"
                          height="22"
                          rx="0"
                          className="fill-slate-950 border border-theme-border"
                        />
                        <text
                          x={activePoint.x}
                          y={activePoint.y - 18}
                          className="fill-white text-[9px] font-bold font-sans"
                          textAnchor="middle"
                        >
                          {activePoint.label}: {activePoint.value} sent
                        </text>
                      </g>
                    )}
                  </svg>
                );
              })()}
            </div>
          </div>

          {/* Chart 2: Campaign Performance */}
          <div className="bg-theme-surface border border-theme-border p-7 rounded-none space-y-4 relative overflow-hidden transition-all duration-300 animate-slide-in">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-xs font-bold uppercase tracking-wider text-theme-secondary font-sans">Campaign Performance</h2>
                <p className="text-[10px] text-theme-muted font-sans">Average recipient email open-rate metrics per month.</p>
              </div>

              <div className="relative">
                <select className="bg-theme-app border border-theme-border rounded-none px-3 py-1.5 text-[10px] font-bold text-theme-secondary hover:text-theme-primary appearance-none cursor-pointer pr-8 focus:outline-none transition-colors">
                  <option>Last 6 Months</option>
                </select>
                <FontAwesomeIcon icon={CaretDown} className="absolute right-3 top-2.5 pointer-events-none text-theme-muted w-3 h-3" />
              </div>
            </div>

            <div className="relative h-56 w-full flex items-center justify-center pt-2">
              {monthlyPerformance.length === 0 ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#121216]/95 z-20 p-6 text-center select-none">
                  <FontAwesomeIcon icon={Activity} className="text-theme-muted mb-2 text-3xl" />
                  <h3 className="text-xs font-bold text-theme-primary uppercase tracking-wider font-sans">No Campaign Activity</h3>
                  <p className="text-[10px] text-theme-muted mt-1 max-w-[240px] leading-relaxed font-sans">
                    Monthly open rates and click analytics will register here once automated outreach campaigns are actively executing.
                  </p>
                </div>
              ) : null}

              {monthlyPerformance.length > 0 && (
                <svg viewBox="0 0 500 200" className="w-full h-full overflow-visible">
                  <line x1="30" y1="30" x2="470" y2="30" className="stroke-theme-border/30 stroke-1" strokeDasharray="3 3" />
                  <line x1="30" y1="100" x2="470" y2="100" className="stroke-theme-border/30 stroke-1" strokeDasharray="3 3" />
                  <line x1="30" y1="170" x2="470" y2="170" className="stroke-theme-border/60 stroke-1" />

                  <text x="18" y="34" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">100%</text>
                  <text x="18" y="104" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">50%</text>
                  <text x="18" y="174" className="fill-theme-muted text-[9px] font-bold font-sans" textAnchor="end">0%</text>

                  {monthlyPerformance.map((d, idx) => {
                    const barWidth = 28;
                    const totalBars = monthlyPerformance.length;
                    const space = (440 - (totalBars * barWidth)) / (totalBars + 1);
                    const xOffset = 30 + space + (idx * (barWidth + space));
                    const barHeight = d.value * 140 / 100;
                    const yOffset = 170 - barHeight;
                    const colors = ['#0066b1', '#0FA336', '#E22718', '#1C69D4', '#0653b6', '#7E7E7E'];
                    const barColor = colors[idx % colors.length];

                    return (
                      <g key={idx}>
                        <rect
                          x={xOffset}
                          y={yOffset}
                          width={barWidth}
                          height={barHeight}
                          rx="0"
                          fill={barColor}
                        />
                        <text
                          x={xOffset + barWidth / 2}
                          y={yOffset - 6}
                          className="fill-theme-secondary text-[9px] font-bold font-sans"
                          textAnchor="middle"
                        >
                          {d.value}%
                        </text>
                        <text
                          x={xOffset + barWidth / 2}
                          y="188"
                          className="fill-theme-muted text-[10px] font-bold font-sans"
                          textAnchor="middle"
                        >
                          {d.label}
                        </text>
                      </g>
                    );
                  })}
                </svg>
              )}
            </div>
          </div>

        </div>
      )}

      {/* Grid: Health Status & Operations List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 relative z-10">
        {/* Health Panel */}
        <div className="bg-theme-surface border border-theme-border p-7 rounded-none space-y-4 lg:col-span-2">
          <h2 className="text-xs font-bold uppercase tracking-wider text-theme-secondary flex items-center gap-2 font-sans">
            <FontAwesomeIcon icon={ShieldCheck} className="text-base" />
            <span>Outreach Gateways Status</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-5 bg-theme-app border border-theme-border rounded-none flex items-start gap-3">
              <div className="w-9 h-9 flex items-center justify-center bg-role-signal/10 border border-role-signal/20 rounded-none text-role-signal shrink-0">
                <FontAwesomeIcon icon={ShieldCheck} className="text-base" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-theme-primary font-sans">SMTP Gateway Health</h4>
                <p className="text-[10px] text-theme-muted mt-1 leading-relaxed font-sans">{metrics?.smtp_health}</p>
                <button 
                  onClick={() => onNavigate('smtp')}
                  className="text-[10px] text-role-creative hover:text-role-creative/80 font-bold mt-2.5 hover:underline block cursor-pointer transition-colors"
                >
                  Manage SMTP relay gateways &rarr;
                </button>
              </div>
            </div>

            <div className="p-5 bg-theme-app border border-theme-border rounded-none flex items-start gap-3">
                <div className="w-9 h-9 flex items-center justify-center bg-role-signal/10 border border-role-signal/20 rounded-none text-role-signal shrink-0">
                  <FontAwesomeIcon icon={ShieldCheck} className="text-base" />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-theme-primary font-sans">Domain DNS Verification</h4>
                  <p className="text-[10px] text-theme-muted mt-1 leading-relaxed font-sans">{metrics?.domain_health}</p>
                  <div className="text-[9px] text-theme-muted mt-2.5 flex gap-1.5">
                    <span className="px-1.5 py-0.5 bg-[#0FA336]/10 text-[#0FA336] rounded-none font-bold">SPF</span>
                    <span className="px-1.5 py-0.5 bg-[#0FA336]/10 text-[#0FA336] rounded-none font-bold">DKIM</span>
                    <span className="px-1.5 py-0.5 bg-[#0FA336]/10 text-[#0FA336] rounded-none font-bold">DMARC</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Funnel list summary */}
        <div className="bg-theme-surface border border-theme-border p-7 rounded-none space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider text-theme-secondary flex items-center gap-2 font-sans">
            <FontAwesomeIcon icon={ChartBar} className="text-base" />
            <span>Conversion metrics</span>
          </h2>

          <div className="space-y-3.5 pt-1">
            {[
              { label: '1. Dispatched', rate: '100%', bg: '#0066b1' },
              { label: '2. Delivered', rate: deliveryRate, bg: '#0FA336' },
              { label: '3. Opened / Read', rate: metrics?.open_rate || '0.0%', bg: '#1C69D4' },
              { label: '4. Link Clicked', rate: '0.0%', bg: '#E22718' },
              { label: '5. Replied (IMAP)', rate: metrics?.reply_rate || '0.0%', bg: '#7E7E7E' }
            ].map((funnel, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-[10px] font-bold font-sans">
                  <span className="text-theme-secondary">{funnel.label}</span>
                  <span className="text-theme-primary">{funnel.rate}</span>
                </div>
                <div className="w-full bg-theme-app h-2.5 rounded-none overflow-hidden border border-theme-border/40">
                  <div 
                    className="h-full rounded-none transition-all duration-300" 
                    style={{ 
                      backgroundColor: funnel.bg, 
                      width: funnel.rate 
                    }} 
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Grid: Recent Replies & Activity Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 relative z-10">
        
        {/* Recent Replies Widget */}
        <div className="bg-theme-surface border border-theme-border p-7 rounded-none space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider flex items-center gap-2 text-theme-secondary font-sans">
            <FontAwesomeIcon icon={MessageSquare} className="text-base" />
            <span>Recent Replies (IMAP Polled)</span>
            {metrics?.reply_rate && (
              <span className="text-[9px] font-bold ml-auto bg-role-signal/10 text-role-signal border border-role-signal/20 px-2 py-0.5 rounded-none font-mono">
                REPLIES: {metrics.reply_rate}
              </span>
            )}
          </h2>
          
          <div className="border border-theme-border rounded-none overflow-hidden min-h-[220px]">
            {recentReplies.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-theme-muted p-4 text-center">
                <FontAwesomeIcon icon={MessageSquare} className="text-theme-muted mb-2 text-3xl" />
                <p className="text-xs font-bold text-theme-primary font-sans">No replies detected yet</p>
                <p className="text-[10px] text-theme-muted mt-1 max-w-[240px] leading-relaxed font-sans">When contacts reply to your emails, they will be fetched via IMAP and shown here.</p>
              </div>
            ) : (
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-theme-app border-b border-theme-border text-theme-muted font-bold uppercase text-[10px] font-sans">
                    <th className="p-3">Contact</th>
                    <th className="p-3">Subject & Snippet</th>
                    <th className="p-3">Received</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-theme-border/60">
                  {recentReplies.map((reply) => (
                    <tr key={reply.id} className="hover:bg-theme-hover transition-colors cursor-pointer" onClick={() => onNavigate('mailbox')}>
                      <td className="p-3 font-sans">
                        <div className="font-bold text-theme-primary">{reply.contact_name}</div>
                        <div className="text-[10px] text-theme-muted mt-0.5">{reply.contact_email}</div>
                      </td>
                      <td className="p-3 max-w-[180px] truncate font-sans">
                        <div className="font-bold text-theme-primary truncate">{reply.subject}</div>
                        <div className="text-[10px] text-theme-muted truncate mt-0.5">{reply.snippet}</div>
                      </td>
                      <td className="p-3 text-theme-muted text-[10px] whitespace-nowrap font-sans">
                        {new Date(reply.received_at).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>

        {/* Recent Activity Feed */}
        <div className="bg-theme-surface border border-theme-border p-7 rounded-none space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-wider flex items-center gap-2 text-theme-secondary font-sans">
            <FontAwesomeIcon icon={Activity} className="text-base" />
            <span>Recent Activity Feed</span>
          </h2>
          
          <div className="border border-theme-border rounded-none overflow-hidden min-h-[220px]">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-theme-app border-b border-theme-border text-theme-muted font-bold uppercase text-[10px] font-sans">
                  <th className="p-3">Action</th>
                  <th className="p-3">Details</th>
                  <th className="p-3">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-theme-border/60">
                {activity.map((item) => (
                  <tr key={item.id} className="hover:bg-theme-hover transition-colors">
                    <td className="p-3 font-bold text-theme-primary font-sans">{item.action}</td>
                    <td className="p-3 text-theme-secondary leading-relaxed font-sans">{item.details}</td>
                    <td className="p-3 text-theme-muted text-[10px] whitespace-nowrap font-sans">
                      {new Date(item.timestamp).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
