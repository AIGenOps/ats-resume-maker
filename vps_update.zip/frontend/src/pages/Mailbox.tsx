import React, { useState, useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { API_BASE } from '../config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faMagnifyingGlass as Search, faXmark as X, faRotate as RefreshCw, 
  faEnvelope as Mail, faCaretDown as ChevronDown, faEnvelopeOpen as MailOpen, 
  faTrashCan as Trash2, faReply as CornerUpLeft, faShare as CornerUpRight,
  faServer as Server, faCircleInfo as Info, faArrowLeft as ArrowLeft, faFolder as Folder, faTag as TagIcon, faPlus as Plus,
  faPaperPlane as Send, faClock as Clock, faFileLines as FileText
} from '@fortawesome/free-solid-svg-icons';
import { useKeyboardShortcuts } from '../hooks/useKeyboardShortcuts';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../contexts/ToastContext';
import FolderSidebar from '../components/mailbox/FolderSidebar';
import MailItemRow from '../components/mailbox/MailItemRow';
import ThreadViewer from '../components/mailbox/ThreadViewer';

// Mobile Touch Swipe Gesture Row Wrapper
interface SwipeableRowProps {
  children: React.ReactNode;
  onSwipeRight: () => void;
  onSwipeLeft: () => void;
}

const SwipeableRow = ({ children, onSwipeRight, onSwipeLeft }: SwipeableRowProps) => {
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [currentTranslate, setCurrentTranslate] = useState(0);
  const [swiping, setSwiping] = useState(false);

  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.targetTouches[0].clientX);
    setSwiping(true);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (!touchStart) return;
    const currentTouch = e.targetTouches[0].clientX;
    const diff = currentTouch - touchStart;
    
    // Cap swipe visual translation
    if (diff > 0) {
      setCurrentTranslate(Math.min(diff, 100)); // Swipe Right (Archive)
    } else {
      setCurrentTranslate(Math.max(diff, -120)); // Swipe Left (Delete)
    }
  };

  const onTouchEnd = () => {
    setSwiping(false);
    if (!touchStart || !touchEnd) {
      setCurrentTranslate(0);
      return;
    }
    const distance = touchEnd - touchStart;
    const isLeftSwipe = distance < -minSwipeDistance;
    const isRightSwipe = distance > minSwipeDistance;

    if (isRightSwipe && distance > 80) {
      onSwipeRight();
    } else if (isLeftSwipe && distance < -80) {
      onSwipeLeft();
    }
    setCurrentTranslate(0);
    setTouchStart(null);
    setTouchEnd(null);
  };

  return (
    <div 
      className="relative overflow-hidden w-full bg-[#1A1A1A]"
      onTouchStart={onTouchStart}
      onTouchMove={(e) => {
        setTouchEnd(e.targetTouches[0].clientX);
        onTouchMove(e);
      }}
      onTouchEnd={onTouchEnd}
    >
      {/* Background Actions Indicator */}
      <div className="absolute inset-0 flex items-center justify-between px-4 z-0 pointer-events-none">
        <div className="flex items-center text-white bg-emerald-600 h-full px-6 font-bold text-xs uppercase">
          <span>Archive</span>
        </div>
        <div className="flex items-center text-white bg-red-600 h-full px-6 font-bold text-xs uppercase">
          <span>Delete</span>
        </div>
      </div>

      {/* Actual Row Container */}
      <div 
        className="relative z-10 w-full transition-transform duration-150 ease-out bg-theme-app"
        style={{ transform: `translateX(${currentTranslate}px)` }}
      >
        {children}
      </div>
    </div>
  );
};

interface MailboxProps {
  token: string;
  onNavigate?: (page: string) => void;
  user?: any;
}

export default function Mailbox({ token, onNavigate, user }: MailboxProps) {
  const { addToast } = useToast();
  const { theme, panePosition, density, sidebarCollapsed, setSidebarCollapsed } = useTheme();

  // Responsive state logic
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);
  const [mobileView, setMobileView] = useState<'folders' | 'threads' | 'reading'>('folders');
  const [mobileFilterTab, setMobileFilterTab] = useState<'all' | 'unread' | 'flagged'>('all');
  const [showSearchOverlay, setShowSearchOverlay] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Active keyboard navigation row and range index tracking
  const [activeRowIndex, setActiveRowIndex] = useState<number | null>(null);
  const [lastClickedIndex, setLastClickedIndex] = useState<number | null>(null);
  const [showCheatSheet, setShowCheatSheet] = useState(false);

  // Accounts state
  const [accounts, setAccounts] = useState<any[]>([]);
  const [activeSmtpId, setActiveSmtpId] = useState('');
  
  // Folders state
  const [activeFolder, setActiveFolder] = useState<'inbox' | 'sent' | 'scheduled' | 'drafts'>('inbox');
  
  // Lists and loading states
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  
  // Thread reading state
  const [messages, setMessages] = useState<any[]>([]);
  const [loadingThread, setLoadingThread] = useState(false);
  
  // Selected single item data (for Sent/Scheduled/Drafts where there isn't a conversation ID)
  const [selectedItemData, setSelectedItemData] = useState<any | null>(null);

  // Reply composer state
  const [replyBody, setReplyBody] = useState('');
  const [sendingReply, setSendingReply] = useState(false);
  const [showReplyBox, setShowReplyBox] = useState(false);

  // Tags state
  const [tags, setTags] = useState<any[]>([]);
  const [activeTagId, setActiveTagId] = useState<string | null>(null);
  const [assigningTagItemId, setAssigningTagItemId] = useState<string | null>(null);

  // Sync mobile transition when folder/tag selection changes
  useEffect(() => {
    if (isMobile) {
      setMobileView('threads');
    }
  }, [activeFolder, activeTagId]);
  
  // Selection/Bulk states
  const [checkedItemIds, setCheckedItemIds] = useState<string[]>([]);
  const [showBulkTagDropdown, setShowBulkTagDropdown] = useState(false);

  // List Virtualization States
  const [scrollTop, setScrollTop] = useState(0);
  const [containerHeight, setContainerHeight] = useState(600);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    setScrollTop(e.currentTarget.scrollTop);
    if (containerRef.current) {
      setContainerHeight(containerRef.current.clientHeight);
    }
  };

  const fetchAccounts = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/v1/smtp/`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      const accountsList = Array.isArray(data) ? data : [];
      setAccounts(accountsList);
      
      const storedId = localStorage.getItem('active_smtp_account_id');
      if (storedId && accountsList.some(acc => acc.id === storedId)) {
        setActiveSmtpId(storedId);
      } else if (accountsList.length > 0) {
        setActiveSmtpId(accountsList[0].id);
        localStorage.setItem('active_smtp_account_id', accountsList[0].id);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const fetchTags = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/tags`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setTags(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchFolderItems = useCallback(async () => {
    setLoading(true);
    try {
      let endpoint = '';
      if (activeFolder === 'inbox') {
        endpoint = `${API_BASE}/api/v1/mailbox/conversations?smtp_id=${activeSmtpId}`;
      } else if (activeFolder === 'sent') {
        endpoint = `${API_BASE}/api/v1/mailbox/sent?smtp_id=${activeSmtpId}`;
      } else if (activeFolder === 'scheduled') {
        endpoint = `${API_BASE}/api/v1/mailbox/scheduled?smtp_id=${activeSmtpId}`;
      } else if (activeFolder === 'drafts') {
        endpoint = `${API_BASE}/api/v1/mailbox/drafts?smtp_id=${activeSmtpId}`;
      }

      const res = await fetch(endpoint, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setItems(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [activeFolder, activeSmtpId, token]);

  // AI Copilot states
  const [showCopilotBar, setShowCopilotBar] = useState(false);
  const [copilotPrompt, setCopilotPrompt] = useState('');
  const [copilotTone, setCopilotTone] = useState(localStorage.getItem('setting_default_tone') || 'professional');
  const [copilotModel] = useState(localStorage.getItem('setting_ai_model') || 'gemini-2.5-flash');

  // Trigger containerHeight update on items count change
  useEffect(() => {
    if (containerRef.current) {
      setContainerHeight(containerRef.current.clientHeight);
    }
  }, [items]);

  useEffect(() => {
    fetchAccounts();
    fetchTags();
  }, []);

  useEffect(() => {
    if (activeSmtpId) {
      fetchFolderItems();
      setSelectedItemId(null);
      setMessages([]);
      setSelectedItemData(null);
      setShowReplyBox(false);
      setCheckedItemIds([]);
      setShowBulkTagDropdown(false);
      
      // Reset virtualization scroll state
      setScrollTop(0);
      if (containerRef.current) {
        containerRef.current.scrollTop = 0;
      }
    }
  }, [activeSmtpId, activeFolder, fetchFolderItems]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowBulkTagDropdown(false);
      }
    };
    if (showBulkTagDropdown) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => window.removeEventListener('keydown', handleEsc);
  }, [showBulkTagDropdown]);

  const getThemeClass = (lightClass: string, darkClass: string) => {
    return theme === 'dark' ? darkClass : lightClass;
  };



  const handleSelectItem = useCallback(async (itemId: string, itemData: any) => {
    setSelectedItemId(itemId);
    setSelectedItemData(itemData);
    setShowReplyBox(false);
    setReplyBody('');

    if (window.innerWidth < 768) {
      setMobileView('reading');
    }

    // Collapse the main navigation sidebar when opening an email to read
    setSidebarCollapsed(true);

    // Fetch conversation thread messages ONLY for Inbox folder items
    if (activeFolder === 'inbox') {
      setLoadingThread(true);
      try {
        const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${itemId}`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const data = await res.json();
          setMessages(Array.isArray(data) ? data : []);
        } else {
          setMessages([]);
        }
        
        // Refresh items folder to clear unread state in side lists
        fetchFolderItems();
      } catch (e) {
        console.error(e);
      } finally {
        setLoadingThread(false);
      }
    }
  }, [activeFolder, token, setSidebarCollapsed, activeSmtpId, fetchFolderItems]);

  const handleSendReply = async () => {
    if (!replyBody.trim()) {
      addToast("Please write a reply message body first.", 'error');
      return;
    }

    setSendingReply(true);
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${selectedItemId}/reply`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          body: replyBody,
          sender_name: localStorage.getItem('setting_sender_name') || null
        })
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.detail || "Failed to send reply");
      }

      setReplyBody('');
      setShowReplyBox(false);
      addToast('Reply dispatched successfully!', 'success');
      
      // Reload thread
      if (selectedItemId) {
        handleSelectItem(selectedItemId, selectedItemData);
      }
    } catch (err: any) {
      addToast(`Send reply failed: ${err.message}`, 'error');
    } finally {
      setSendingReply(false);
    }
  };

  const handleAssignTag = async (convId: string, tagId: string) => {
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${convId}/tags`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ tag_id: tagId })
      });
      const updatedTags = await res.json();
      if (res.ok) {
        setItems((prev: any[]) => prev.map(item => {
          if (item && item.id === convId) {
            return { ...item, tags: updatedTags };
          }
          return item;
        }));
        if (selectedItemData && selectedItemId === convId) {
          setSelectedItemData((prev: any) => ({ ...prev, tags: updatedTags }));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUnassignTag = async (convId: string, tagId: string) => {
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${convId}/tags/${tagId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const updatedTags = await res.json();
      if (res.ok) {
        setItems((prev: any[]) => prev.map(item => {
          if (item && item.id === convId) {
            return { ...item, tags: updatedTags };
          }
          return item;
        }));
        if (selectedItemData && selectedItemId === convId) {
          setSelectedItemData((prev: any) => ({ ...prev, tags: updatedTags }));
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleBulkAssignTag = async (tagId: string) => {
    if (checkedItemIds.length === 0) return;
    setLoading(true);
    try {
      await Promise.all(
        checkedItemIds.map(convId =>
          fetch(`${API_BASE}/api/v1/mailbox/conversations/${convId}/tags`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ tag_id: tagId })
          })
        )
      );

      addToast(`Applied label to ${checkedItemIds.length} items successfully!`, 'success');
      
      // Refresh items list
      fetchFolderItems();
      setCheckedItemIds([]);
      setShowBulkTagDropdown(false);
    } catch (err) {
      console.error(err);
      addToast('Error applying bulk label', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkMarkRead = async () => {
    if (checkedItemIds.length === 0) return;
    setLoading(true);
    try {
      await Promise.all(
        checkedItemIds.map(convId =>
          fetch(`${API_BASE}/api/v1/mailbox/conversations/${convId}/read`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`
            }
          })
        )
      );

      addToast(`Marked ${checkedItemIds.length} items as read!`, 'success');
      fetchFolderItems();
      setCheckedItemIds([]);
    } catch (err) {
      console.error(err);
      addToast('Error marking items as read', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkMarkUnread = async () => {
    if (checkedItemIds.length === 0) return;
    setLoading(true);
    try {
      await Promise.all(
        checkedItemIds.map(convId =>
          fetch(`${API_BASE}/api/v1/mailbox/conversations/${convId}/unread`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`
            }
          })
        )
      );

      addToast(`Marked ${checkedItemIds.length} items as unread!`, 'success');
      fetchFolderItems();
      setCheckedItemIds([]);
    } catch (err) {
      console.error(err);
      addToast('Error marking items as unread', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkDelete = async () => {
    if (checkedItemIds.length === 0) return;
    if (!confirm(`Are you sure you want to delete these ${checkedItemIds.length} conversations?`)) return;
    setLoading(true);
    try {
      await Promise.all(
        checkedItemIds.map(convId =>
          fetch(`${API_BASE}/api/v1/mailbox/conversations/${convId}`, {
            method: 'DELETE',
            headers: {
              'Authorization': `Bearer ${token}`
            }
          })
        )
      );

      addToast(`Deleted ${checkedItemIds.length} items successfully!`, 'success');
      fetchFolderItems();
      setCheckedItemIds([]);
    } catch (err) {
      console.error(err);
      addToast('Error deleting items', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteConversation = useCallback(async (convId: string) => {
    if (!window.confirm("Are you sure you want to permanently delete this conversation?")) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${convId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        addToast("Conversation deleted successfully!", "success");
        fetchFolderItems();
        if (selectedItemId === convId) setSelectedItemId(null);
      } else {
        addToast("Failed to delete conversation", "error");
      }
    } catch (e) {
      console.error(e);
      addToast("Error deleting conversation", "error");
    } finally {
      setLoading(false);
    }
  }, [token, selectedItemId, fetchFolderItems]);

  const handleArchiveConversation = useCallback(async (convId: string) => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${convId}/archive`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        addToast("Conversation archived successfully!", "success");
        fetchFolderItems();
        if (selectedItemId === convId) setSelectedItemId(null);
      } else {
        addToast("Failed to archive conversation", "error");
      }
    } catch (e) {
      console.error(e);
      addToast("Error archiving conversation", "error");
    } finally {
      setLoading(false);
    }
  }, [token, selectedItemId, fetchFolderItems]);

  const handleToggleReadConversation = useCallback(async (convId: string, currentUnread: boolean) => {
    setLoading(true);
    const endpoint = currentUnread ? 'read' : 'unread';
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${convId}/${endpoint}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        addToast(currentUnread ? "Marked as read" : "Marked as unread", "success");
        fetchFolderItems();
      } else {
        addToast("Failed to update status", "error");
      }
    } catch (e) {
      console.error(e);
      addToast("Error updating status", "error");
    } finally {
      setLoading(false);
    }
  }, [token, fetchFolderItems]);

  const handleReplyConversation = useCallback((convId: string) => {
    setSelectedItemId(convId);
    setShowReplyBox(true);
  }, []);

  const handleForwardConversation = useCallback(async (item: any) => {
    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${item.id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const messagesData = await response.json();
      if (response.ok && Array.isArray(messagesData)) {
        const formattedMessages = messagesData.map(m => (
          `\n\n--- Original Message ---\nFrom: ${m.sender_name} <${m.sender_email}>\nDate: ${m.sent_time}\nSubject: ${m.subject}\n\n${m.body_text || m.body || ''}`
        )).join('\n');
        
        sessionStorage.setItem('compose_prepopulated', JSON.stringify({
          subject: `Fwd: ${item.subject || ''}`,
          body: `<p>Begin forwarded message:</p>${formattedMessages.replace(/\n/g, '<br/>')}`
        }));
        window.location.hash = '#/compose';
        if (onNavigate) onNavigate('compose');
      } else {
        addToast("Failed to fetch messages for forwarding", "error");
      }
    } catch (err) {
      console.error(err);
      addToast("Error forwarding conversation", "error");
    } finally {
      setLoading(false);
    }
  }, [token, onNavigate]);

  const filteredItems = items.filter(item => {
    if (!item) return false;
    if (activeTagId && !(item.tags && item.tags.some((t: any) => t.id === activeTagId))) {
      return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      let match = true;
      const operatorRegex = /(?:([a-zA-Z0-9_-]+):"([^"]+)"|([a-zA-Z0-9_-]+):([^\s]+))/g;
      const parsedOperators: { key: string; value: string }[] = [];
      let matchResult;
      while ((matchResult = operatorRegex.exec(q)) !== null) {
        const key = (matchResult[1] || matchResult[3]).toLowerCase();
        const value = (matchResult[2] || matchResult[4]).toLowerCase();
        parsedOperators.push({ key, value });
      }
      const textQuery = q.replace(/(?:[a-zA-Z0-9_-]+):"[^"]+"|([a-zA-Z0-9_-]+):[^\s]+/g, '').trim();
      
      for (const op of parsedOperators) {
        if (op.key === 'from') {
          const fromVal = (item.contact_name || item.sender || '').toLowerCase();
          if (!fromVal.includes(op.value)) match = false;
        } else if (op.key === 'subject') {
          const subjVal = (item.subject || '').toLowerCase();
          if (!subjVal.includes(op.value)) match = false;
        } else if (op.key === 'is') {
          const isUnread = (item.unread_count || 0) > 0;
          if (op.value === 'unread' && !isUnread) match = false;
          if (op.value === 'read' && isUnread) match = false;
        } else if (op.key === 'has') {
          if (op.value === 'attachment') {
            const hasAttach = item.has_attachments || (item.attachments && item.attachments.length > 0);
            if (!hasAttach) match = false;
          }
        } else if (op.key === 'before' || op.key === 'after') {
          const itemTime = item.latest_message_time || item.sent_time || item.scheduled_time || item.updated_at;
          if (itemTime) {
            const itemDate = new Date(itemTime);
            const filterDate = new Date(op.value);
            if (!isNaN(filterDate.getTime())) {
              if (op.key === 'before' && itemDate >= filterDate) match = false;
              if (op.key === 'after' && itemDate <= filterDate) match = false;
            }
          }
        }
      }
      if (textQuery) {
        const subjectMatch = item.subject?.toLowerCase().includes(textQuery);
        const senderMatch = (item.contact_name || item.recipient_email || item.sender || '')?.toLowerCase().includes(textQuery);
        const snippetMatch = item.latest_message_snippet?.toLowerCase().includes(textQuery);
        const bodyMatch = item.body?.toLowerCase().includes(textQuery);
        if (!(subjectMatch || senderMatch || snippetMatch || bodyMatch)) match = false;
      }
      return match;
    }
    return true;
  });

  const handleToggleChecked = useCallback((id: string, isChecked: boolean, event?: React.MouseEvent) => {
    const clickedIdx = filteredItems.findIndex(item => item.id === id);
    if (event && event.shiftKey && lastClickedIndex !== null && clickedIdx !== -1) {
      const start = Math.min(lastClickedIndex, clickedIdx);
      const end = Math.max(lastClickedIndex, clickedIdx);
      const rangeItemIds = filteredItems.slice(start, end + 1).map(item => item.id);
      
      setCheckedItemIds(prev => {
        const otherChecked = prev.filter(checkedId => !rangeItemIds.includes(checkedId));
        if (isChecked) {
          return [...otherChecked, ...rangeItemIds];
        } else {
          return otherChecked;
        }
      });
    } else {
      setCheckedItemIds((prev) => {
        if (isChecked) {
          return [...prev, id];
        } else {
          return prev.filter((itemId) => itemId !== id);
        }
      });
    }
    if (clickedIdx !== -1) {
      setLastClickedIndex(clickedIdx);
      setActiveRowIndex(clickedIdx);
    }
  }, [filteredItems, lastClickedIndex]);

  const getActiveAccountName = () => {
    const active = accounts.find(a => a.id === activeSmtpId);
    return active ? `${active.name} <${active.from_email}>` : 'Unknown Account';
  };

  useKeyboardShortcuts([
    { key: 'i', description: 'Go to Inbox', action: () => { setActiveFolder('inbox'); setSelectedItemId(null); } },
    { key: 's', description: 'Go to Sent', action: () => { setActiveFolder('sent'); setSelectedItemId(null); } },
    { key: 'o', description: 'Go to Scheduled', action: () => { setActiveFolder('scheduled'); setSelectedItemId(null); } },
    { key: 'd', description: 'Go to Drafts', action: () => { setActiveFolder('drafts'); setSelectedItemId(null); } }
  ]);

  const ROW_HEIGHT = density === 'compact' ? 44 : 60;
  const buffer = 15;
  const startIndex = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - buffer);
  const endIndex = Math.min(filteredItems.length, Math.ceil((scrollTop + containerHeight) / ROW_HEIGHT) + buffer);

  const paddingTop = startIndex * ROW_HEIGHT;
  const paddingBottom = (filteredItems.length - endIndex) * ROW_HEIGHT;
  const visibleItems = filteredItems.slice(startIndex, endIndex);

  // Hook shortcuts directly to keydowns
  useEffect(() => {
    const handleShortcuts = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      if (
        activeEl && 
        (activeEl.tagName === 'INPUT' || 
         activeEl.tagName === 'TEXTAREA' || 
         activeEl.getAttribute('contenteditable') === 'true')
      ) {
        return;
      }
      if (e.key === 'j') {
        e.preventDefault();
        setActiveRowIndex(prev => {
          const nextIdx = prev === null ? 0 : Math.min(prev + 1, filteredItems.length - 1);
          if (containerRef.current) {
            containerRef.current.scrollTop = nextIdx * ROW_HEIGHT - containerRef.current.clientHeight / 2;
          }
          return nextIdx;
        });
      } else if (e.key === 'k') {
        e.preventDefault();
        setActiveRowIndex(prev => {
          const nextIdx = prev === null ? 0 : Math.max(prev - 1, 0);
          if (containerRef.current) {
            containerRef.current.scrollTop = nextIdx * ROW_HEIGHT - containerRef.current.clientHeight / 2;
          }
          return nextIdx;
        });
      } else if (e.key === 'Enter') {
        if (activeRowIndex !== null && filteredItems[activeRowIndex]) {
          e.preventDefault();
          handleSelectItem(filteredItems[activeRowIndex].id, filteredItems[activeRowIndex]);
        }
      } else if (e.key === 'e') {
        if (activeRowIndex !== null && filteredItems[activeRowIndex]) {
          e.preventDefault();
          handleToggleReadConversation(filteredItems[activeRowIndex].id, true);
        }
      } else if (e.key === '#') {
        if (activeRowIndex !== null && filteredItems[activeRowIndex]) {
          e.preventDefault();
          handleDeleteConversation(filteredItems[activeRowIndex].id);
        }
      } else if (e.key === 'r') {
        if (selectedItemId) {
          e.preventDefault();
          setShowReplyBox(true);
          setTimeout(() => {
            const editorEl = document.querySelector('#reply-composer-area [contenteditable="true"]');
            if (editorEl) (editorEl as HTMLElement).focus();
          }, 100);
        }
      } else if (e.key === 'c') {
        e.preventDefault();
        if (onNavigate) onNavigate('compose');
      } else if (e.key === '/') {
        e.preventDefault();
        const searchInput = document.querySelector('input[type="text"][placeholder*="Search"]');
        if (searchInput) (searchInput as HTMLInputElement).focus();
      } else if (e.key === '?') {
        e.preventDefault();
        setShowCheatSheet(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleShortcuts);
    return () => window.removeEventListener('keydown', handleShortcuts);
  }, [activeRowIndex, filteredItems, selectedItemId]);

  // Mobile Folders View (Screen 1)
  const renderMobileFoldersView = () => {
    return (
      <div className="flex-grow flex flex-col overflow-y-auto p-4 space-y-4">
        {/* Account picker for mobile */}
        {accounts.length > 0 && (
          <div className="flex flex-col gap-2 p-4 bg-theme-surface border border-theme-border rounded-xl">
            <span className="text-[10px] font-bold text-theme-muted uppercase tracking-wider">Inbox Channel</span>
            <select
              value={activeSmtpId}
              onChange={(e) => setActiveSmtpId(e.target.value)}
              className="w-full bg-theme-app border border-theme-border rounded-lg px-3 py-2 text-sm font-semibold text-theme-primary focus:outline-none"
            >
              {accounts.map((acc) => (
                <option key={acc.id} value={acc.id} className="text-slate-900 bg-white">
                  {acc.name} ({acc.from_email})
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Folders List */}
        <div className="space-y-1">
          <span className="text-[10px] font-bold text-theme-muted uppercase tracking-wider px-2">Folders</span>
          {[
            { id: 'inbox', name: 'Inbox', icon: Mail },
            { id: 'sent', name: 'Sent', icon: Send },
            { id: 'scheduled', name: 'Scheduled', icon: Clock },
            { id: 'drafts', name: 'Drafts', icon: FileText }
          ].map((folder) => {
            const Icon = folder.icon;
            const isActive = activeFolder === folder.id && activeTagId === null;
            return (
              <button
                key={folder.id}
                onClick={() => {
                  setActiveTagId(null);
                  setActiveFolder(folder.id as any);
                  setMobileView('threads');
                }}
                className={`w-full flex items-center justify-between p-4 rounded-xl border text-sm font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                  isActive 
                    ? 'bg-theme-accent/8 border-theme-accent text-theme-accent' 
                    : 'bg-theme-surface border-theme-border text-theme-secondary'
                }`}
              >
                <div className="flex items-center gap-3">
                  <FontAwesomeIcon icon={Icon} className="h-5 w-5 shrink-0" />
                  <span>{folder.name}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Labels List */}
        <div className="space-y-1">
          <span className="text-[10px] font-bold text-theme-muted uppercase tracking-wider px-2">Labels</span>
          {tags.length === 0 ? (
            <div className="p-4 text-center text-xs text-theme-muted bg-theme-surface border border-theme-border rounded-xl">
              No labels created yet.
            </div>
          ) : (
            tags.map((t) => {
              const isActive = activeTagId === t.id;
              return (
                <button
                  key={t.id}
                  onClick={() => {
                    setActiveTagId(t.id);
                    setMobileView('threads');
                  }}
                  className={`w-full flex items-center justify-between p-4 rounded-xl border text-sm font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                    isActive 
                      ? 'bg-theme-accent/8 border-theme-accent text-theme-accent' 
                      : 'bg-theme-surface border-theme-border text-theme-secondary'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-none shrink-0" style={{ backgroundColor: t.color }} />
                    <span>{t.name}</span>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>
    );
  };

  // Pull-to-refresh & Touch Swipe threads view (Screen 2)
  const renderMobileThreadsView = () => {
    const getUserInitials = () => {
      if (user?.full_name) {
        const parts = user.full_name.trim().split(/\s+/);
        if (parts.length >= 2) {
          return (parts[0][0] + parts[1][0]).toUpperCase();
        }
        return parts[0].slice(0, 2).toUpperCase();
      }
      return 'OP';
    };

    const getAvatarBgColor = (name: string) => {
      const colors = [
        'bg-[#2A2D35] text-[#A0AEC0] border border-[#3E424D]/50', // Slate
        'bg-[#252830] text-[#8E92A6] border border-[#373A47]/50', // Navy
        'bg-[#2E2829] text-[#A68E91] border border-[#423738]/50', // Rose
        'bg-[#222A2D] text-[#869FA3] border border-[#323F42]/50', // Teal/Cyan-gray
        'bg-[#2A2630] text-[#9D8EA6] border border-[#3C3545]/50', // Purple
        'bg-[#2F2B28] text-[#A69E90] border border-[#423C37]/50'  // Amber-gray
      ];
      let hash = 0;
      for (let i = 0; i < name.length; i++) {
        hash = name.charCodeAt(i) + ((hash << 5) - hash);
      }
      const index = Math.abs(hash) % colors.length;
      return colors[index];
    };

    const formatTime = (timeStr?: string) => {
      if (!timeStr) return '';
      try {
        const date = new Date(timeStr);
        const now = new Date();
        if (date.toDateString() === now.toDateString()) {
          return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });
        }
        return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
      } catch (e) {
        return '';
      }
    };

    // Filter threads based on active filter tab
    const mobileFilteredItems = filteredItems.filter(item => {
      if (mobileFilterTab === 'unread') {
        return (item.unread_count || 0) > 0;
      }
      if (mobileFilterTab === 'flagged') {
        // match starred threads
        return item.is_starred || item.starred || false;
      }
      return true; // 'all'
    });

    return (
      <div className="flex-grow flex flex-col min-h-0 bg-[#000000] text-theme-primary">
        
        {/* Header: Title in var(--font-heading) Serif + User initials avatar */}
        <div className="flex justify-between items-center px-6 pt-6 pb-4 shrink-0 bg-transparent">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMobileView('folders')}
              className="p-1.5 -ml-1.5 text-theme-muted hover:text-theme-primary cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center mr-1"
            >
              <FontAwesomeIcon icon={ArrowLeft} className="h-5.5 w-5.5" />
            </button>
            <h1 
              className="text-3xl font-extrabold tracking-tight text-white capitalize font-heading"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {activeTagId ? tags.find(t => t.id === activeTagId)?.name : activeFolder}
            </h1>
          </div>
          <div className="w-10 h-10 rounded-full bg-theme-accent text-theme-btnText flex items-center justify-center font-bold text-sm select-none border border-theme-border/20">
            {getUserInitials()}
          </div>
        </div>

        {/* Pill Search Button (Opens fullscreen search overlay) */}
        <div className="px-6 pb-4 shrink-0">
          <button
            onClick={() => setShowSearchOverlay(true)}
            className="w-full mobile-search-pill px-5 py-3 text-xs flex items-center gap-3.5 text-left text-theme-muted hover:text-theme-secondary transition-colors cursor-pointer"
          >
            <FontAwesomeIcon icon={Search} className="h-4.5 w-4.5 text-[#555860]" />
            <span className="font-semibold truncate">Search mail by subject, sender, body...</span>
          </button>
        </div>

        {/* Underline Filter Tabs (All / Unread / Flagged) */}
        <div className="px-6 pb-4 shrink-0">
          <div className="flex gap-6 border-b border-[#202226]/50 overflow-x-auto scrollbar-none">
            {[
              { id: 'all', name: 'All' },
              { id: 'unread', name: 'Unread' },
              { id: 'flagged', name: 'Flagged' }
            ].map(tab => {
              const isActive = mobileFilterTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setMobileFilterTab(tab.id as any)}
                  className={`pb-3 text-sm font-semibold transition-all relative cursor-pointer ${
                    isActive ? 'text-theme-accent font-bold' : 'text-theme-muted hover:text-theme-secondary'
                  }`}
                >
                  <span>{tab.name}</span>
                  {isActive && (
                    <div className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-theme-accent rounded-full animate-fade-in" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Scrollable list */}
        <div className="flex-grow overflow-y-auto px-6 space-y-3 pt-2 pb-safe-content">
          {loading ? (
            <div className="space-y-3 animate-pulse">
              {[...Array(4)].map((_, idx) => (
                <div key={idx} className="p-4 mobile-card h-28" />
              ))}
            </div>
          ) : mobileFilteredItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-24 text-center select-none animate-fade-in">
              <FontAwesomeIcon icon={Mail} className="h-10 w-10 text-[#555860] mb-3" />
              <h3 className="text-xs font-bold text-theme-secondary uppercase tracking-wider">No matching threads</h3>
              <p className="text-[10px] text-theme-muted mt-1 max-w-[200px]">This category search filter is currently empty.</p>
            </div>
          ) : (
            mobileFilteredItems.map((item) => {
              const snippet = item.latest_message_snippet 
                ? item.latest_message_snippet.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&')
                : item.body ? item.body.replace(/<[^>]*>/g, '') : '';
              const isUnread = (item.unread_count || 0) > 0;
              const hasAttachments = item.has_attachments || (item.attachments && item.attachments.length > 0);
              const isSystem = !item.contact_name || item.contact_name === 'Unknown' || item.contact_name.includes('@');
              const senderInitials = item.contact_name ? item.contact_name.slice(0, 2).toUpperCase() : 'JD';
              const latestTime = formatTime(item.latest_message_time || item.sent_time || item.scheduled_time || item.updated_at);
              
              return (
                <SwipeableRow
                  key={item.id}
                  onSwipeRight={() => handleArchiveConversation(item.id)}
                  onSwipeLeft={() => handleDeleteConversation(item.id)}
                >
                  <div 
                    onClick={() => handleSelectItem(item.id, item)}
                    className={`p-4 mobile-card flex items-start gap-3.5 transition-colors cursor-pointer text-left hover:brightness-105 active:brightness-95 ${
                      isUnread ? 'border-theme-accent/25' : ''
                    }`}
                  >
                    {/* Avatar Fallback Logic */}
                    {item.contact_photo ? (
                      <img src={item.contact_photo} alt="" className="w-11 h-11 rounded-full object-cover shrink-0" />
                    ) : isSystem ? (
                      <div className="w-11 h-11 rounded-full bg-[#1F2025] border border-theme-border/40 flex items-center justify-center text-theme-muted shrink-0 select-none">
                        <FontAwesomeIcon icon={Mail} className="h-5.5 w-5.5 text-theme-muted" />
                      </div>
                    ) : (
                      <div className={`w-11 h-11 rounded-full flex items-center justify-center font-bold text-xs shrink-0 select-none ${getAvatarBgColor(item.contact_name || '')}`}>
                        {senderInitials}
                      </div>
                    )}

                    {/* Content Block */}
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline mb-0.5">
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className="font-bold text-white text-sm truncate">
                            {item.contact_name || item.recipient_email || 'Unknown'}
                          </span>
                          {isUnread && (
                            <span className="w-2 h-2 rounded-full bg-[#10B981] shrink-0" title="Unread" />
                          )}
                        </div>
                        
                        <span className="text-[10px] text-theme-muted font-bold font-mono shrink-0 ml-2">
                          {latestTime}
                        </span>
                      </div>

                      <div className="font-semibold text-theme-secondary text-xs truncate mb-1.5 flex items-center gap-1.5">
                        <span className="truncate">{item.subject || '(No Subject)'}</span>
                        {hasAttachments && (
                          <span className="text-[10px] text-theme-muted shrink-0">📎</span>
                        )}
                      </div>

                      <div className="text-theme-muted text-[11px] leading-relaxed line-clamp-2">
                        {snippet || 'No message snippet logged.'}
                      </div>
                    </div>
                  </div>
                </SwipeableRow>
              );
            })
          )}
        </div>

        {/* Fullscreen Search Overlay Portal */}
        {showSearchOverlay && createPortal(
          <div className="fixed inset-0 bg-[#000000] z-[99999] flex flex-col p-6 pb-safe animate-fade-in text-theme-primary">
            <div className="flex items-center gap-3 pb-4 border-b border-[#202226]/50">
              <button
                onClick={() => {
                  setShowSearchOverlay(false);
                  setSearch('');
                }}
                className="p-1.5 -ml-1 text-theme-muted hover:text-theme-primary cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
              >
                <FontAwesomeIcon icon={ArrowLeft} className="h-5.5 w-5.5" />
              </button>
              <div className="flex-grow relative">
                <FontAwesomeIcon icon={Search} className="absolute left-3.5 top-3 h-4.5 w-4.5 text-[#555860]" />
                <input
                  type="text"
                  autoFocus
                  placeholder="Search mail by subject, sender, body..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="w-full bg-[#18191D] border border-transparent rounded-full pl-11 pr-4 py-2.5 text-sm focus:outline-none focus:border-theme-accent/20 focus:ring-0 placeholder-[#555860] text-white"
                  style={{ borderRadius: '9999px' }}
                />
              </div>
              {search && (
                <button 
                  onClick={() => setSearch('')}
                  className="text-xs font-semibold text-theme-accent px-2 py-1 hover:brightness-115 transition-all"
                >
                  Clear
                </button>
              )}
            </div>

            <div className="flex-grow overflow-y-auto pt-4 space-y-3">
              {mobileFilteredItems.length === 0 ? (
                <div className="py-12 text-center text-xs text-theme-muted font-sans">
                  No matching threads found.
                </div>
              ) : (
                mobileFilteredItems.map((item) => {
                  const snippet = item.latest_message_snippet 
                    ? item.latest_message_snippet.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ')
                    : item.body ? item.body.replace(/<[^>]*>/g, '') : '';
                  const isUnread = (item.unread_count || 0) > 0;
                  const hasAttachments = item.has_attachments || (item.attachments && item.attachments.length > 0);
                  const isSystem = !item.contact_name || item.contact_name === 'Unknown' || item.contact_name.includes('@');
                  const senderInitials = item.contact_name ? item.contact_name.slice(0, 2).toUpperCase() : 'JD';
                  const latestTime = formatTime(item.latest_message_time || item.sent_time || item.scheduled_time || item.updated_at);
                  
                  return (
                    <div 
                      key={item.id}
                      onClick={() => {
                        setShowSearchOverlay(false);
                        handleSelectItem(item.id, item);
                      }}
                      className={`p-4 bg-[#121316] border border-[#202226]/60 rounded-xl flex items-start gap-3.5 transition-colors cursor-pointer text-left hover:brightness-105 ${
                        isUnread ? 'border-theme-accent/25' : ''
                      }`}
                      style={{ borderRadius: '16px' }}
                    >
                      {/* Avatar Fallback Logic */}
                      {item.contact_photo ? (
                        <img src={item.contact_photo} alt="" className="w-11 h-11 rounded-full object-cover shrink-0" />
                      ) : isSystem ? (
                        <div className="w-11 h-11 rounded-full bg-[#1F2025] border border-theme-border/40 flex items-center justify-center text-theme-muted shrink-0 select-none">
                          <FontAwesomeIcon icon={Mail} className="h-5.5 w-5.5 text-theme-muted" />
                        </div>
                      ) : (
                        <div className={`w-11 h-11 rounded-full flex items-center justify-center font-bold text-xs shrink-0 select-none ${getAvatarBgColor(item.contact_name || '')}`}>
                          {senderInitials}
                        </div>
                      )}

                      {/* Content Block */}
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-baseline mb-0.5">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <span className="font-bold text-white text-sm truncate">
                              {item.contact_name || item.recipient_email || 'Unknown'}
                            </span>
                            {isUnread && (
                              <span className="w-2 h-2 rounded-full bg-[#10B981] shrink-0" />
                            )}
                          </div>
                          <span className="text-[10px] text-theme-muted font-bold font-mono shrink-0 ml-2">
                            {latestTime}
                          </span>
                        </div>

                        <div className="font-semibold text-theme-secondary text-xs truncate mb-1.5 flex items-center gap-1.5">
                          <span className="truncate">{item.subject || '(No Subject)'}</span>
                          {hasAttachments && (
                            <span className="text-[10px] text-theme-muted shrink-0">📎</span>
                          )}
                        </div>

                        <div className="text-theme-muted text-[11px] leading-relaxed line-clamp-2">
                          {snippet || 'No message snippet logged.'}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>,
          document.body
        )}
      </div>
    );
  };

  // Mobile Reading view (Screen 3)
  const renderMobileReadingView = () => {
    return (
      <div className="flex-grow flex flex-col h-full overflow-hidden bg-theme-app">
        {/* Header */}
        <div className="h-14 flex items-center gap-3 px-4 border-b border-theme-border shrink-0 bg-black/90 text-theme-primary">
          <button
            onClick={() => {
              setSelectedItemId(null);
              setSelectedItemData(null);
              setMobileView('threads');
            }}
            className="p-2 -ml-2 text-theme-muted hover:text-theme-primary cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
          >
            <FontAwesomeIcon icon={ArrowLeft} className="h-5 w-5" />
          </button>
          <span className="text-sm font-bold truncate">Conversation Details</span>
        </div>

        {/* Main Thread Content */}
        <div className="flex-1 overflow-hidden">
          <ThreadViewer
            activeFolder={activeFolder}
            selectedItemId={selectedItemId || ''}
            selectedItemData={selectedItemData}
            messages={messages}
            loadingThread={loadingThread}
            token={token}
            tags={tags}
            onBack={() => {
              setSelectedItemId(null);
              setSelectedItemData(null);
              setMobileView('threads');
            }}
            showReplyBox={showReplyBox}
            setShowReplyBox={setShowReplyBox}
            replyBody={replyBody}
            setReplyBody={setReplyBody}
            sendingReply={sendingReply}
            handleSendReply={handleSendReply}
            showCopilotBar={showCopilotBar}
            setShowCopilotBar={setShowCopilotBar}
            copilotPrompt={copilotPrompt}
            setCopilotPrompt={setCopilotPrompt}
            copilotTone={copilotTone}
            setCopilotTone={setCopilotTone}
            copilotModel={copilotModel}
            handleAssignTag={handleAssignTag}
            handleUnassignTag={handleUnassignTag}
            assigningTagItemId={assigningTagItemId}
            setAssigningTagItemId={setAssigningTagItemId}
            getActiveAccountName={getActiveAccountName}
            onRefresh={fetchFolderItems}
          />
        </div>
      </div>
    );
  };

  const isRightPane = panePosition === 'right';
  const showReadingPane = selectedItemId !== null || selectedItemData !== null;

  if (isMobile) {
    return (
      <div 
        className="overflow-hidden flex flex-col h-full w-full select-none relative"
        style={{ background: 'transparent' }}
      >
        {mobileView === 'folders' && renderMobileFoldersView()}
        {mobileView === 'threads' && renderMobileThreadsView()}
        {mobileView === 'reading' && renderMobileReadingView()}
      </div>
    );
  }

  return (
    <div 
      className="overflow-hidden flex flex-col h-full w-full select-none relative"
      style={{ background: 'transparent' }}
    >
      {/* Search Header */}
      <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center gap-4 mb-4 sm:mb-6 flex-shrink-0 z-10">
        <div className="flex-1 max-w-2xl relative">
          <FontAwesomeIcon icon={Search} className={`absolute left-4 top-3 h-4.5 w-4.5 ${getThemeClass('text-slate-500', 'text-slate-300')}`} />
          <input
            type="text"
            placeholder="Search mail by subject, sender, body (e.g. from:Grace subject:Update)..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className={`w-full pl-12 pr-12 py-2.5 border rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-[#00b5ad]/40 backdrop-blur-xl transition-all ${
              getThemeClass(
                'bg-white/90 border-slate-200/50 text-slate-800 placeholder-slate-500 focus:bg-white shadow-sm', 
                'bg-white/10 border-white/10 text-white placeholder-slate-300 focus:bg-white/20'
              )
            }`}
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className={`absolute right-4 top-3 ${getThemeClass('text-slate-500 hover:text-slate-800', 'text-slate-300 hover:text-white')}`}
            >
              <FontAwesomeIcon icon={X} className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Account Picker */}
        {accounts.length > 0 && (
          <div className="flex items-center gap-3 shrink-0 w-full sm:w-auto">
            <span className="text-xs font-bold text-theme-muted uppercase tracking-wider font-sans hidden sm:inline">Viewing Inbox:</span>
            <div className="relative flex-grow sm:flex-initial">
              <select
                value={activeSmtpId}
                onChange={(e) => setActiveSmtpId(e.target.value)}
                className={`w-full sm:w-auto sm:min-w-[240px] px-5 py-2.5 border rounded-none text-sm font-semibold focus:outline-none focus:ring-0 cursor-pointer appearance-none pr-9 backdrop-blur-xl transition-all text-ellipsis ${
                  getThemeClass(
                    'bg-white/90 border-slate-200/50 text-slate-800 shadow-none', 
                    'bg-white/10 border-white/10 text-white'
                  )
                }`}
              >
                {accounts.map((acc) => (
                  <option key={acc.id} value={acc.id} className="text-slate-900 bg-white">
                    {acc.name} ({acc.from_email})
                  </option>
                ))}
              </select>
              <div className={`pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 ${getThemeClass('text-slate-500', 'text-slate-300')}`}>
                <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                  <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                </svg>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Setup callout banner if no SMTP configurations found */}
      {accounts.length === 0 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-5 mb-6 bg-theme-surface border border-theme-border rounded-none animate-slide-in shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-theme-app border border-theme-border rounded-none shrink-0">
              <FontAwesomeIcon icon={Server} className="text-lg" />
            </div>
            <div className="text-left">
              <h4 className="text-xs font-bold text-theme-primary uppercase tracking-wider font-sans">Connect a mailbox to start sending</h4>
              <p className="text-[10px] text-theme-muted mt-0.5 font-sans">No SMTP configurations found. Setup a gateway to test connection and dispatch messages.</p>
            </div>
          </div>
          <button 
            onClick={() => onNavigate?.('smtp')}
            className="px-4 py-2 bg-black border border-white hover:bg-white hover:text-black text-white text-xs font-bold rounded-none transition-all font-sans cursor-pointer whitespace-nowrap uppercase tracking-wider"
          >
            Configure SMTP Gateway
          </button>
        </div>
      )}

      {/* Main Mailbox Workspace */}
      <div className="flex-grow flex gap-4 sm:gap-6 overflow-hidden min-h-0 z-10">
        
        {/* Left Sidebar (Pill Folders & Labels) */}
        <FolderSidebar
          activeFolder={activeFolder}
          setActiveFolder={setActiveFolder}
          activeTagId={activeTagId}
          setActiveTagId={setActiveTagId}
          items={items}
          tags={tags}
          setTags={setTags}
          token={token}
          onNavigate={onNavigate}
          setSelectedItemId={setSelectedItemId}
          collapsed={sidebarCollapsed}
          setCollapsed={setSidebarCollapsed}
        />

        {/* Dynamic Multi-Pane Layout display */}
        <div className={`flex-grow flex ${isRightPane ? 'flex-row' : 'flex-col'} min-w-0 overflow-hidden rounded-none shadow-none transition-all border border-theme-border ${
          getThemeClass(
            'bg-white/85 border-slate-200/50 text-slate-800',
            'bg-slate-950/45 border-white/5 text-white'
          )
        }`}>
          {/* Middle List Pane */}
          <div 
            className={`h-full overflow-hidden flex flex-col border-theme-border/35 ${
              isRightPane ? 'border-r' : 'border-b'
            } ${
              showReadingPane ? 'hidden md:flex md:w-[420px] shrink-0' : 'flex-grow w-full'
            }`}
          >
            {/* Toolbar */}
            {checkedItemIds.length > 0 ? (
              <div className="p-4 border-b flex justify-between items-center flex-shrink-0 bg-[#1A1A1A] text-white border-b border-theme-border animate-slide-in font-semibold relative z-20">
                <div className="flex items-center gap-3.5">
                  <button
                    onClick={() => setCheckedItemIds([])}
                    className="p-1 hover:bg-white/5 rounded-none transition-colors cursor-pointer"
                    title="Clear Selection"
                  >
                    <FontAwesomeIcon icon={X} className="h-4.5 w-4.5 text-white" />
                  </button>
                  <span className="text-xs font-bold font-mono text-white">
                    {checkedItemIds.length} SELECTED
                  </span>
                </div>
                
                <div className="flex items-center gap-2">
                  {/* Mark as Read */}
                  <button
                    onClick={handleBulkMarkRead}
                    className="p-1.5 hover:bg-white/5 rounded-none transition-colors cursor-pointer text-white flex items-center justify-center"
                    title="Mark as Read"
                  >
                    <FontAwesomeIcon icon={MailOpen} className="h-4.5 w-4.5" />
                  </button>
 
                  {/* Mark as Unread */}
                  <button
                    onClick={handleBulkMarkUnread}
                    className="p-1.5 hover:bg-white/5 rounded-none transition-colors cursor-pointer text-white flex items-center justify-center"
                    title="Mark as Unread"
                  >
                    <FontAwesomeIcon icon={Mail} className="h-4.5 w-4.5" />
                  </button>
 
                  {/* Bulk Delete */}
                  <button
                    onClick={handleBulkDelete}
                    className="p-1.5 hover:bg-white/5 rounded-none transition-colors cursor-pointer text-white flex items-center justify-center"
                    title="Delete Selected"
                  >
                    <FontAwesomeIcon icon={Trash2} className="h-4.5 w-4.5" />
                  </button>
 
                  <div className="relative">
                    <button
                      onClick={() => setShowBulkTagDropdown(!showBulkTagDropdown)}
                      className="px-3.5 py-1.5 bg-black text-white border border-theme-border rounded-none text-xs font-bold transition-all hover:bg-white/5 cursor-pointer flex items-center gap-1.5 uppercase tracking-wider"
                    >
                      <span>Apply Label</span>
                      <FontAwesomeIcon icon={ChevronDown} className="h-3 w-3" />
                    </button>
                  
                    {showBulkTagDropdown && (
                      <div className="absolute right-0 mt-1.5 w-48 bg-black border border-theme-border rounded-none shadow-2xl z-50 overflow-hidden text-left animate-slide-in">
                        {tags.length === 0 ? (
                          <div className="p-3 text-xs font-semibold text-slate-400">No labels created yet</div>
                        ) : (
                          <div className="py-1">
                            {tags.map((t) => (
                              <button
                                key={t.id}
                                onClick={() => handleBulkAssignTag(t.id)}
                                className="w-full px-3.5 py-2 text-xs font-semibold text-slate-350 hover:text-white hover:bg-white/5 transition-all text-left flex items-center gap-2 cursor-pointer"
                              >
                                <div className="w-2.5 h-2.5 rounded-none shrink-0" style={{ backgroundColor: t.color }} />
                                <span>{t.name}</span>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className={`p-4 border-b flex justify-between items-center flex-shrink-0 ${
                getThemeClass('bg-slate-50/50 border-slate-250/10 text-slate-700', 'bg-black/10 border-white/10 text-slate-300')
              }`}>
                <div className="flex items-center gap-4">
                  <span className={`text-xs font-bold uppercase tracking-wider font-mono ${
                    getThemeClass('text-slate-600', 'text-slate-300')
                  }`}>
                    {activeFolder}
                  </span>
                  <button
                    onClick={fetchFolderItems}
                    className={`p-1.5 rounded-none transition-colors ${
                      getThemeClass(
                        'text-slate-500 hover:text-slate-800 hover:bg-slate-250/20', 
                        'text-slate-300 hover:text-white hover:bg-white/5'
                      )
                    }`}
                    title="Refresh"
                  >
                    <FontAwesomeIcon icon={RefreshCw} className={`h-4 w-4 ${loading ? 'fa-spin' : ''}`} />
                  </button>
                </div>
                <div className={`text-xs font-semibold ${getThemeClass('text-slate-500', 'text-slate-300')}`}>
                  {filteredItems.length} {filteredItems.length === 1 ? 'item' : 'items'}
                </div>
              </div>
            )}

            {/* Rows List scroll area */}
            <div 
              ref={containerRef}
              onScroll={handleScroll}
              className="flex-grow overflow-y-auto divide-y divide-theme-border/50 bg-transparent"
            >
              {loading ? (
                <div className="divide-y divide-theme-border/30 animate-pulse">
                  {[...Array(8)].map((_, idx) => (
                    <div key={idx} className="flex items-center gap-2 sm:gap-4 px-3 sm:px-4 py-4 text-left">
                      <div className="hidden sm:flex items-center gap-3 shrink-0">
                        <div className="w-4 h-4 bg-theme-border/50 rounded" />
                        <div className="w-4.5 h-4.5 bg-theme-border/40 rounded-full" />
                      </div>
                      <div className="w-24 sm:w-44 shrink-0">
                        <div className="h-4 bg-theme-border/50 rounded w-20 sm:w-32" />
                      </div>
                      <div className="flex-1 min-w-0 flex items-center gap-3">
                        <div className="h-4 bg-theme-border/50 rounded w-1/3" />
                        <div className="h-3 bg-theme-border/30 rounded w-1/2 hidden md:inline" />
                      </div>
                      <div className="w-16 sm:w-24 shrink-0 flex justify-end">
                        <div className="h-3 bg-theme-border/40 rounded w-12" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredItems.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-24 px-6 text-center select-none h-full m-4 bg-[#1A1A1A]/10 border border-dashed border-theme-border rounded-none">
                  <div className="p-4 bg-theme-app border border-theme-border rounded-none text-theme-muted mb-4 shadow-none">
                    <FontAwesomeIcon icon={Mail} className="h-10 w-10 text-theme-muted" />
                  </div>
                  <h3 className="text-xs font-bold text-theme-primary uppercase tracking-wider font-sans">
                    {activeFolder === 'inbox' ? 'Your inbox is clear' : 'No messages logged'}
                  </h3>
                  <p className="text-[10px] text-theme-muted mt-1.5 max-w-[240px] mx-auto leading-relaxed font-sans">
                    {activeFolder === 'inbox' 
                      ? 'New incoming emails will appear here automatically once polled.' 
                      : 'This category folder is currently empty.'}
                  </p>
                  <button
                    onClick={() => onNavigate?.('compose_floating')}
                    className="mt-5 px-6 py-3 bg-black border border-white hover:bg-white hover:text-black text-white text-xs font-bold rounded-none uppercase tracking-wider transition-all font-sans cursor-pointer shadow-none"
                  >
                    Compose your first email
                  </button>

                </div>
              ) : (
                <div style={{ paddingTop: `${paddingTop}px`, paddingBottom: `${paddingBottom}px` }}>
                  {visibleItems.map((item, idx) => {
                    const absoluteIdx = startIndex + idx;
                    const isActive = absoluteIdx === activeRowIndex;
                    return (
                      <div key={item.id} className={isActive ? 'ring-2 ring-theme-accent ring-inset' : ''}>
                        <MailItemRow
                          item={item}
                          activeFolder={activeFolder}
                          onSelect={handleSelectItem}
                          checked={checkedItemIds.includes(item.id)}
                          onToggleChecked={(id, ch, ev) => handleToggleChecked(id, ch, ev)}
                          onDelete={handleDeleteConversation}
                          onToggleRead={handleToggleReadConversation}
                          onReply={handleReplyConversation}
                          onForward={handleForwardConversation}
                        />
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Reading Pane */}
          <div 
            className={`flex-grow h-full overflow-hidden ${
              showReadingPane ? 'flex flex-col' : 'hidden md:flex items-center justify-center bg-theme-app/10'
            }`}
          >
            {showReadingPane ? (
              <ThreadViewer
                activeFolder={activeFolder}
                selectedItemId={selectedItemId || ''}
                selectedItemData={selectedItemData}
                messages={messages}
                loadingThread={loadingThread}
                token={token}
                tags={tags}
                onBack={() => {
                  setSelectedItemId(null);
                  setSelectedItemData(null);
                }}
                showReplyBox={showReplyBox}
                setShowReplyBox={setShowReplyBox}
                replyBody={replyBody}
                setReplyBody={setReplyBody}
                sendingReply={sendingReply}
                handleSendReply={handleSendReply}
                showCopilotBar={showCopilotBar}
                setShowCopilotBar={setShowCopilotBar}
                copilotPrompt={copilotPrompt}
                setCopilotPrompt={setCopilotPrompt}
                copilotTone={copilotTone}
                setCopilotTone={setCopilotTone}
                copilotModel={copilotModel}
                handleAssignTag={handleAssignTag}
                handleUnassignTag={handleUnassignTag}
                assigningTagItemId={assigningTagItemId}
                setAssigningTagItemId={setAssigningTagItemId}
                getActiveAccountName={getActiveAccountName}
                onRefresh={fetchFolderItems}
              />
            ) : filteredItems.length === 0 ? (
              null
            ) : (
              <div className="flex flex-col items-center justify-center p-8 opacity-60 text-center font-sans">
                <FontAwesomeIcon icon={Mail} className="h-12 w-12 mb-3 text-theme-muted" />
                <span className="text-sm font-semibold text-theme-primary">Select an email to read</span>
                <p className="text-xs text-theme-muted mt-1 max-w-[240px]">Choose a conversation from the list to display details in this reading pane.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Keyboard Shortcuts Cheatsheet Modal */}
      {showCheatSheet && createPortal(
        <div className="modal-backdrop !z-[10005]">
          <div className="modal-content w-full max-w-md bg-theme-surface border border-theme-border rounded-2xl shadow-2xl overflow-hidden p-6 relative">
            <button 
              onClick={() => setShowCheatSheet(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-theme-hover transition-colors text-theme-muted"
            >
              <FontAwesomeIcon icon={X} className="h-5 w-5" />
            </button>
            <h3 className="text-lg font-bold font-outfit mb-5 pr-6 text-theme-primary">Mailbox Keyboard Shortcuts</h3>
            <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
              {[
                { keys: ['J'], desc: 'Move selection down the list' },
                { keys: ['K'], desc: 'Move selection up the list' },
                { keys: ['Enter'], desc: 'Open active selected thread' },
                { keys: ['E'], desc: 'Mark active email as read / archive' },
                { keys: ['#'], desc: 'Delete active selected email' },
                { keys: ['R'], desc: 'Open inline reply box' },
                { keys: ['C'], desc: 'Open floating compose window' },
                { keys: ['/'], desc: 'Focus the search input bar' },
                { keys: ['?'], desc: 'Toggle keyboard cheatsheet' },
                { keys: ['I'], desc: 'Go to Inbox folder' },
                { keys: ['S'], desc: 'Go to Sent folder' },
                { keys: ['O'], desc: 'Go to Scheduled folder' },
                { keys: ['D'], desc: 'Go to Drafts folder' },
              ].map((s, idx) => (
                <div key={idx} className="flex justify-between items-center text-sm py-1.5 border-b border-theme-border last:border-b-0">
                  <span className="text-theme-secondary">{s.desc}</span>
                  <div className="flex gap-1">
                    {s.keys.map((k, kIdx) => (
                      <kbd key={kIdx} className="px-2 py-0.5 bg-theme-app text-theme-accent text-xs font-mono font-bold rounded border border-theme-border uppercase">
                        {k}
                      </kbd>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
