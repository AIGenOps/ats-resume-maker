import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { API_BASE } from '../config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faMagnifyingGlass as Search, faPlus as Plus, faUpload as Upload, faDownload as Download, 
  faEnvelope as Mail, faBuilding as Building, faPhone as Phone, faGlobe as Globe, faUser as User, faTag as Tag, faTrashCan as Trash, 
  faRotate as RefreshCw, faXmark as X, faComments as MessageSquare, faArrowLeft as ArrowLeft
} from '@fortawesome/free-solid-svg-icons';
import { useToast } from '../contexts/ToastContext';

interface ContactsProps {
  token: string;
}

export default function Contacts({ token }: ContactsProps) {
  const { addToast } = useToast();
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [contacts, setContacts] = useState<any[]>([]);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState('');
  const [importSummary, setImportSummary] = useState<any>(null);
  const [uploadingCsv, setUploadingCsv] = useState(false);
  const [importGroupMode, setImportGroupMode] = useState<'existing' | 'new'>('existing');
  const [importSelectedTagId, setImportSelectedTagId] = useState('');
  const [importNewGroupName, setImportNewGroupName] = useState('');
  
  // Selection and tags
  const [selectedContactIds, setSelectedContactIds] = useState<string[]>([]);
  const [availableTags, setAvailableTags] = useState<any[]>([]);

  // Tab and Group States
  const [activeTab, setActiveTab] = useState<'contacts' | 'groups'>('contacts');
  const [selectedGroup, setSelectedGroup] = useState<any>(null);
  const [newGroupName, setNewGroupName] = useState('');

  const handleCreateGroup = async () => {
    const name = newGroupName.trim();
    if (!name) {
      addToast("Please enter a group name", "error");
      return;
    }
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/tags`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name, color: '#3b82f6' })
      });
      const data = await response.json();
      if (response.ok) {
        addToast(`Group "${name}" created successfully!`, "success");
        setNewGroupName('');
        fetchAvailableTags();
      } else {
        addToast(data.detail || "Failed to create group", "error");
      }
    } catch (e) {
      console.error(e);
      addToast("Error creating group", "error");
    }
  };

  const handleDeleteGroup = async () => {
    if (!selectedGroup) return;
    if (!window.confirm(`Are you sure you want to delete the group "${selectedGroup.name}"? Contacts in this group will not be deleted.`)) {
      return;
    }
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/tags/${selectedGroup.id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      if (response.ok) {
        addToast(`Group "${selectedGroup.name}" deleted successfully!`, "success");
        setSelectedGroup(null);
        fetchAvailableTags();
        fetchContacts();
      } else {
        addToast(data.detail || "Failed to delete group", "error");
      }
    } catch (e) {
      console.error(e);
      addToast("Error deleting group", "error");
    }
  };

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [selectedContact, setSelectedContact] = useState<any>(null);
  
  // Add Contact Form State
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');
  const [designation, setDesignation] = useState('');
  const [phone, setPhone] = useState('');
  const [website, setWebsite] = useState('');
  const [linkedin, setLinkedin] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [detailTagInput, setDetailTagInput] = useState('');
  
  // Note Form State
  const [noteContent, setNoteContent] = useState('');
  const [notes, setNotes] = useState<any[]>([]);
  
  // CSV upload state
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [savingContact, setSavingContact] = useState(false);

  const fetchAvailableTags = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/tags`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setAvailableTags(data);
      }
    } catch (e) {
      console.error("Error fetching tags:", e);
    }
  };

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search);
    }, 300);

    return () => {
      clearTimeout(handler);
    };
  }, [search]);

  useEffect(() => {
    setSelectedContactIds([]);
  }, [debouncedSearch, page, statusFilter, activeTab, selectedGroup]);

  useEffect(() => {
    fetchContacts();
    fetchAvailableTags();
  }, [debouncedSearch, page, statusFilter, activeTab, selectedGroup]);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowAddModal(false);
        setShowImportModal(false);
      }
    };
    if (showAddModal || showImportModal) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => window.removeEventListener('keydown', handleEsc);
  }, [showAddModal, showImportModal]);

  const fetchContacts = async () => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams({
        page: page.toString(),
        limit: '20',
      });
      if (debouncedSearch) queryParams.append('search', debouncedSearch);
      if (statusFilter) queryParams.append('status_filter', statusFilter);
      if (activeTab === 'groups' && selectedGroup) {
        queryParams.append('tag', selectedGroup.name);
      }

      const response = await fetch(`${API_BASE}/api/v1/contacts/?${queryParams.toString()}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (data && Array.isArray(data.contacts)) {
        setContacts(data.contacts);
        setTotal(data.total || 0);
      } else {
        setContacts([]);
        setTotal(0);
        if (data && data.detail) {
          addToast(data.detail, 'error');
        }
      }
    } catch (e) {
      console.error(e);
      setContacts([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  };

  const handleAddContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (savingContact) return;
    setSavingContact(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          full_name: fullName,
          email,
          company: company || null,
          designation: designation || null,
          phone: phone || null,
          website: website || null,
          linkedin: linkedin || null,
          tags,
          status: 'active',
          source: 'manual',
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        addToast(data.detail || 'Failed to create contact.', 'error');
        return;
      }

      // Close modal first so UI updates immediately
      setShowAddModal(false);

      // Reset
      setFullName('');
      setEmail('');
      setCompany('');
      setDesignation('');
      setPhone('');
      setWebsite('');
      setLinkedin('');
      setTags([]);
      
      // Refresh contact list
      await fetchContacts();
    } catch (err) {
      console.error(err);
      addToast('A network error occurred while adding the contact.', 'error');
    } finally {
      setSavingContact(false);
    }
  };

  const handleCsvImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0 || uploadingCsv) return;
    const file = e.target.files[0];

    // Resolve which group tag to assign
    let tagNameToSend = '';
    if (importGroupMode === 'new' && importNewGroupName.trim()) {
      tagNameToSend = importNewGroupName.trim();
    } else if (importGroupMode === 'existing' && importSelectedTagId) {
      const found = availableTags.find((t: any) => String(t.id) === String(importSelectedTagId));
      if (found) tagNameToSend = found.name;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    if (tagNameToSend) {
      formData.append('default_tag', tagNameToSend);
    }

    try {
      setUploadingCsv(true);
      const response = await fetch(`${API_BASE}/api/v1/contacts/import`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });
      const data = await response.json();
      if (response.ok) {
        setImportSummary(data);
        setShowImportModal(false);
        setImportGroupMode('existing');
        setImportSelectedTagId('');
        setImportNewGroupName('');
        fetchAvailableTags();
      } else {
        addToast(data.detail || 'Failed to import CSV.', 'error');
      }
    } catch (err: any) {
      console.error(err);
      addToast(err.message || 'A network error occurred during CSV import.', 'error');
    } finally {
      setUploadingCsv(false);
      e.target.value = '';
    }
  };

  const handleCsvExport = () => {
    window.open(`${API_BASE}/api/v1/contacts/export/csv?token=${token}`, '_blank');
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (indexToRemove: number) => {
    setTags(tags.filter((_, idx) => idx !== indexToRemove));
  };

  const handleAddTagToContact = async (contactId: string) => {
    if (!detailTagInput.trim() || !selectedContact) return;
    const tagName = detailTagInput.trim();
    const currentTagNames = selectedContact.tags ? selectedContact.tags.map((t: any) => t.name) : [];
    if (currentTagNames.includes(tagName)) {
      setDetailTagInput('');
      return;
    }
    const updatedTags = [...currentTagNames, tagName];
    await updateContactTags(contactId, updatedTags);
    setDetailTagInput('');
  };

  const handleRemoveTagFromContact = async (contactId: string, tagIdToRemove: string) => {
    if (!selectedContact) return;
    const currentTags = selectedContact.tags || [];
    const updatedTags = currentTags.filter((t: any) => t.id !== tagIdToRemove).map((t: any) => t.name);
    await updateContactTags(contactId, updatedTags);
  };

  const updateContactTags = async (contactId: string, updatedTagNames: string[]) => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/${contactId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          full_name: selectedContact.full_name,
          email: selectedContact.email,
          company: selectedContact.company || null,
          designation: selectedContact.designation || null,
          phone: selectedContact.phone || null,
          website: selectedContact.website || null,
          linkedin: selectedContact.linkedin || null,
          status: selectedContact.status || 'active',
          source: selectedContact.source || 'crm',
          custom_fields: selectedContact.custom_fields || {},
          tags: updatedTagNames
        })
      });
      
      if (response.ok) {
        const updatedContact = await response.json();
        setSelectedContact(updatedContact);
        fetchContacts();
        addToast("Contact tags updated successfully!", 'success');
      } else {
        const err = await response.json();
        addToast(err.detail || "Failed to update tags.", 'error');
      }
    } catch (e) {
      console.error(e);
      addToast("Error updating contact tags.", 'error');
    }
  };

  const handleToggleSelect = (contactId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedContactIds(prev => 
      prev.includes(contactId) 
        ? prev.filter(id => id !== contactId) 
        : [...prev, contactId]
    );
  };

  const handleSelectAll = () => {
    if (contacts.length > 0 && selectedContactIds.length === contacts.length) {
      setSelectedContactIds([]);
    } else {
      setSelectedContactIds(contacts.map(c => c.id));
    }
  };

  const handleBulkDelete = async () => {
    if (!window.confirm(`Are you sure you want to delete ${selectedContactIds.length} contacts?`)) return;
    try {
      setLoading(true);
      await Promise.all(selectedContactIds.map(id =>
        fetch(`${API_BASE}/api/v1/contacts/${id}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        })
      ));
      addToast(`Successfully deleted ${selectedContactIds.length} contacts!`, 'success');
      setSelectedContactIds([]);
      fetchContacts();
    } catch (e) {
      console.error(e);
      addToast("Error deleting contacts in bulk.", 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkAddTag = async (tagName: string) => {
    if (!tagName.trim()) return;
    try {
      setLoading(true);
      await Promise.all(selectedContactIds.map(async (id) => {
        const contact = contacts.find(c => c.id === id);
        if (!contact) return;
        const currentTagNames = contact.tags ? contact.tags.map((t: any) => t.name) : [];
        if (currentTagNames.includes(tagName)) return;
        const updatedTags = [...currentTagNames, tagName];
        
        await fetch(`${API_BASE}/api/v1/contacts/${id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            full_name: contact.full_name,
            email: contact.email,
            company: contact.company || null,
            designation: contact.designation || null,
            phone: contact.phone || null,
            website: contact.website || null,
            linkedin: contact.linkedin || null,
            status: contact.status || 'active',
            source: contact.source || 'crm',
            custom_fields: contact.custom_fields || {},
            tags: updatedTags
          })
        });
      }));
      addToast(`Successfully added group "${tagName}" to selected contacts!`, 'success');
      setSelectedContactIds([]);
      fetchContacts();
      fetchAvailableTags();
    } catch (e) {
      console.error(e);
      addToast("Error adding group in bulk.", 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkRemoveTag = async (tagName: string) => {
    if (!tagName.trim()) return;
    try {
      setLoading(true);
      await Promise.all(selectedContactIds.map(async (id) => {
        const contact = contacts.find(c => c.id === id);
        if (!contact) return;
        const currentTagNames = contact.tags ? contact.tags.map((t: any) => t.name) : [];
        if (!currentTagNames.includes(tagName)) return;
        const updatedTags = currentTagNames.filter((t: string) => t !== tagName);
        
        await fetch(`${API_BASE}/api/v1/contacts/${id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            full_name: contact.full_name,
            email: contact.email,
            company: contact.company || null,
            designation: contact.designation || null,
            phone: contact.phone || null,
            website: contact.website || null,
            linkedin: contact.linkedin || null,
            status: contact.status || 'active',
            source: contact.source || 'crm',
            custom_fields: contact.custom_fields || {},
            tags: updatedTags
          })
        });
      }));
      addToast(`Successfully removed group "${tagName}" from selected contacts!`, 'success');
      setSelectedContactIds([]);
      fetchContacts();
      fetchAvailableTags();
    } catch (e) {
      console.error(e);
      addToast("Error removing group in bulk.", 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkSetStatus = async (status: 'active' | 'unsubscribed') => {
    try {
      setLoading(true);
      await Promise.all(selectedContactIds.map(async (id) => {
        const contact = contacts.find(c => c.id === id);
        if (!contact) return;
        const currentTagNames = contact.tags ? contact.tags.map((t: any) => t.name) : [];
        
        await fetch(`${API_BASE}/api/v1/contacts/${id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            full_name: contact.full_name,
            email: contact.email,
            company: contact.company || null,
            designation: contact.designation || null,
            phone: contact.phone || null,
            website: contact.website || null,
            linkedin: contact.linkedin || null,
            status: status,
            source: contact.source || 'crm',
            custom_fields: contact.custom_fields || {},
            tags: currentTagNames
          })
        });
      }));
      addToast(`Successfully updated status for selected contacts!`, 'success');
      setSelectedContactIds([]);
      fetchContacts();
    } catch (e) {
      console.error(e);
      addToast("Error setting status in bulk.", 'error');
    } finally {
      setLoading(false);
    }
  };

  const fetchContactDetails = async (contactId: string) => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/${contactId}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      setSelectedContact(data.contact);
      setNotes(data.notes || []);
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteContent.trim() || !selectedContact) return;

    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/${selectedContact.id}/notes`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ content: noteContent }),
      });

      if (response.ok) {
        setNoteContent('');
        fetchContactDetails(selectedContact.id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteContact = async (contactId: string) => {
    if (!confirm('Are you sure you want to delete this contact?')) return;
    try {
      await fetch(`${API_BASE}/api/v1/contacts/${contactId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      setSelectedContact(null);
      fetchContacts();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6 animate-slide-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-theme-primary font-display uppercase">Directory</h1>
          <p className="text-theme-muted text-sm mt-1">Manage, search, group, and import/export your recipient database.</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setShowImportModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-theme-surface border border-theme-border rounded-none font-semibold hover:bg-theme-app text-sm transition-colors text-theme-secondary cursor-pointer"
          >
            <FontAwesomeIcon icon={Upload} className="h-4 w-4" />
            <span>Import CSV</span>
          </button>

          <button
            onClick={handleCsvExport}
            className="flex items-center gap-2 px-4 py-2.5 bg-theme-surface border border-theme-border rounded-none font-semibold hover:bg-theme-app text-sm transition-colors text-theme-secondary"
          >
            <FontAwesomeIcon icon={Download} className="h-4 w-4" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-sm transition-colors uppercase tracking-wider"
          >
            <FontAwesomeIcon icon={Plus} className="h-4 w-4" />
            <span>Add Contact</span>
          </button>
        </div>
      </div>

      {/* Tab Switcher */}
      <div className="flex border-b border-theme-border/60">
        <button
          type="button"
          onClick={() => { setActiveTab('contacts'); setPage(1); }}
          className={`px-4 py-2 text-sm font-semibold border-b-2 transition-all cursor-pointer ${
            activeTab === 'contacts'
              ? 'border-theme-accent text-theme-accent font-bold'
              : 'border-transparent text-theme-muted hover:text-theme-primary'
          }`}
        >
          Contacts
        </button>
        <button
          type="button"
          onClick={() => { setActiveTab('groups'); setPage(1); }}
          className={`px-4 py-2 text-sm font-semibold border-b-2 transition-all cursor-pointer ${
            activeTab === 'groups'
              ? 'border-theme-accent text-theme-accent font-bold'
              : 'border-transparent text-theme-muted hover:text-theme-primary'
          }`}
        >
          Groups
        </button>
      </div>

      {/* Group Control Panel (shown only when activeTab === 'groups') */}
      {activeTab === 'groups' && (
        <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center justify-between bg-theme-surface/50 border border-theme-border p-4 rounded-none animate-fade-in">
          <div className="flex flex-wrap items-center gap-3">
            <label className="text-xs font-bold uppercase tracking-wider text-theme-secondary font-mono">Select Group:</label>
            <select
              value={selectedGroup?.id || ''}
              onChange={(e) => {
                const grp = availableTags.find(t => t.id === e.target.value);
                setSelectedGroup(grp || null);
                setPage(1);
              }}
              className="px-3.5 py-2 bg-theme-surface border border-theme-input rounded-none text-sm font-semibold focus:outline-none focus:border-theme-accent transition-colors text-theme-primary cursor-pointer min-w-48"
            >
              <option value="">-- Choose a Group --</option>
              {availableTags.map((t) => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>

            {selectedGroup && (
              <button
                type="button"
                onClick={handleDeleteGroup}
                className="px-3 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-650 dark:text-red-400 font-semibold rounded-none text-xs flex items-center gap-1.5 cursor-pointer border border-transparent transition-colors"
              >
                <FontAwesomeIcon icon={Trash} className="h-3.5 w-3.5" />
                <span>Delete Group</span>
              </button>
            )}
          </div>

          <div className="flex items-center gap-3">
            <input
              type="text"
              placeholder="New group name..."
              value={newGroupName}
              onChange={(e) => setNewGroupName(e.target.value)}
              className="px-3.5 py-2 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent transition-colors text-theme-primary w-40"
            />
            <button
              type="button"
              onClick={handleCreateGroup}
              className="px-3.5 py-2 bg-black border border-theme-border hover:bg-white hover:text-black text-white rounded-none text-xs font-bold flex items-center gap-1.5 cursor-pointer uppercase tracking-wider"
            >
              <FontAwesomeIcon icon={Plus} className="h-3.5 w-3.5" />
              <span>Create Group</span>
            </button>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center">
        <div className="relative flex-1">
          <FontAwesomeIcon icon={Search} className="absolute left-3 top-3 h-5 w-5 text-theme-muted" />
          <input
            type="text"
            placeholder="Search contacts by name, email, company..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="w-full pl-10 pr-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors"
          />
        </div>
        
        <select
          value={statusFilter}
          onChange={(e) => {
            setStatusFilter(e.target.value);
            setPage(1);
          }}
          className="px-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm focus:outline-none focus:border-[#00b5ad] transition-colors text-theme-primary cursor-pointer font-semibold"
        >
          <option value="">All Statuses</option>
          <option value="active">Active Only</option>
          <option value="unsubscribed">Unsubscribed</option>
        </select>

        <button
          onClick={fetchContacts}
          className="p-2.5 border border-theme-border bg-theme-surface rounded-none hover:bg-theme-app transition-colors flex items-center justify-center"
        >
          <FontAwesomeIcon icon={RefreshCw} className={`h-5 w-5 text-theme-muted ${loading ? 'fa-spin' : ''}`} />
        </button>
      </div>

      {/* Grid: Table list & details side-by-side */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Table View */}
        <div className="bg-theme-surface rounded-none lg:col-span-2 overflow-hidden border border-theme-border flex flex-col">
          {/* Bulk Actions Panel */}
          {selectedContactIds.length > 0 && (
            <div className="bg-theme-accent/5 border-b border-theme-border px-6 py-3 flex flex-wrap items-center justify-between gap-3 text-xs animate-slide-in shrink-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-theme-accent text-sm">{selectedContactIds.length}</span>
                <span className="text-theme-secondary font-semibold">contacts selected</span>
              </div>
              
              <div className="flex items-center gap-3">
                {/* Bulk Add to Tag Dropdown */}
                <div className="relative group/bulk-add">
                  <button className="px-3 py-1.5 bg-theme-surface border border-theme-border rounded-none text-theme-secondary hover:text-theme-primary hover:bg-theme-hover font-semibold flex items-center gap-1.5 cursor-pointer transition-colors">
                    <FontAwesomeIcon icon={Tag} className="h-3.5 w-3.5 text-theme-muted" />
                    <span>Add to Group</span>
                  </button>
                  <div className="absolute right-0 mt-1 hidden group-hover/bulk-add:block hover:block z-50 w-48 bg-theme-surface border border-theme-border rounded-none shadow-2xl p-2.5 space-y-1.5 text-left">
                    <div className="text-[10px] font-bold uppercase text-theme-muted px-2 mb-1">
                      Select Group
                    </div>
                    <div className="max-h-40 overflow-y-auto space-y-1">
                      {availableTags.length === 0 ? (
                        <p className="text-[10px] text-theme-muted px-2">No groups created.</p>
                      ) : (
                        availableTags.map(t => (
                          <button
                            key={t.id}
                            onClick={() => handleBulkAddTag(t.name)}
                            className="w-full text-left px-2 py-1.5 rounded-none hover:bg-theme-hover text-theme-primary font-semibold truncate flex items-center gap-1.5 cursor-pointer transition-colors"
                          >
                            <span className="w-2.5 h-2.5 rounded-none shrink-0" style={{ backgroundColor: t.color }} />
                            <span>{t.name}</span>
                          </button>
                        ))
                      )}
                    </div>
                    <div className="border-t border-theme-border pt-1.5 mt-1.5">
                      <input 
                        type="text"
                        placeholder="Create new group..."
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            const val = (e.target as HTMLInputElement).value.trim();
                            if (val) {
                              handleBulkAddTag(val);
                              (e.target as HTMLInputElement).value = '';
                            }
                          }
                        }}
                        className="w-full px-2 py-1 bg-theme-app border border-theme-input rounded-none text-[11px] text-theme-primary placeholder-theme-muted focus:outline-none focus:border-theme-accent transition-colors"
                      />
                    </div>
                  </div>
                </div>

                {/* Bulk Remove from Tag Dropdown */}
                <div className="relative group/bulk-remove">
                  <button className="px-3 py-1.5 bg-theme-surface border border-theme-border rounded-none text-theme-secondary hover:text-theme-primary hover:bg-theme-hover font-semibold flex items-center gap-1.5 cursor-pointer transition-colors">
                    <FontAwesomeIcon icon={X} className="h-3.5 w-3.5 text-theme-muted" />
                    <span>Remove Group</span>
                  </button>
                  <div className="absolute right-0 mt-1 hidden group-hover/bulk-remove:block hover:block z-50 w-48 bg-theme-surface border border-theme-border rounded-none shadow-2xl p-2.5 space-y-1.5 text-left">
                    <div className="text-[10px] font-bold uppercase text-theme-muted px-2 mb-1">
                      Remove Group
                    </div>
                    <div className="max-h-40 overflow-y-auto space-y-1">
                      {availableTags.length === 0 ? (
                        <p className="text-[10px] text-theme-muted px-2">No groups created.</p>
                      ) : (
                        availableTags.map(t => (
                          <button
                            key={t.id}
                            onClick={() => handleBulkRemoveTag(t.name)}
                            className="w-full text-left px-2 py-1.5 rounded-none hover:bg-theme-hover text-theme-primary font-semibold truncate flex items-center gap-1.5 cursor-pointer transition-colors"
                          >
                            <span className="w-2.5 h-2.5 rounded-none shrink-0" style={{ backgroundColor: t.color }} />
                            <span>{t.name}</span>
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                {/* Bulk Status Select */}
                <div className="relative group/bulk-status">
                  <button className="px-3 py-1.5 bg-theme-surface border border-theme-border rounded-none text-theme-secondary hover:text-theme-primary hover:bg-theme-hover font-semibold flex items-center gap-1.5 cursor-pointer transition-colors">
                    <span>Status</span>
                  </button>
                  <div className="absolute right-0 mt-1 hidden group-hover/bulk-status:block hover:block z-50 w-32 bg-theme-surface border border-theme-border rounded-none shadow-2xl p-2 space-y-0.5 text-left">
                    <button
                      onClick={() => handleBulkSetStatus('active')}
                      className="w-full text-left px-2.5 py-1.5 rounded-none hover:bg-theme-hover text-emerald-600 dark:text-emerald-400 font-semibold cursor-pointer transition-colors"
                    >
                      Set Active
                    </button>
                    <button
                      onClick={() => handleBulkSetStatus('unsubscribed')}
                      className="w-full text-left px-2.5 py-1.5 rounded-none hover:bg-theme-hover text-rose-600 dark:text-rose-400 font-semibold cursor-pointer transition-colors"
                    >
                      Set Unsubscribed
                    </button>
                  </div>
                </div>

                <button
                  onClick={handleBulkDelete}
                  className="px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-650 dark:text-red-400 font-semibold rounded-none flex items-center gap-1 cursor-pointer border border-transparent transition-colors"
                >
                  <FontAwesomeIcon icon={Trash} className="h-3.5 w-3.5" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          )}

          <div className="overflow-x-auto">
            {isMobile ? (
              <div className="space-y-3 bg-transparent">
                {loading ? (
                  Array.from({ length: 3 }).map((_, idx) => (
                    <div key={idx} className="p-4 space-y-2 animate-pulse">
                      <div className="h-4 bg-theme-border/50 rounded w-1/3" />
                      <div className="h-3 bg-theme-border/30 rounded w-1/2" />
                    </div>
                  ))
                ) : activeTab === 'groups' && !selectedGroup ? (
                  <div className="p-8 text-center text-xs text-theme-muted">
                    Please choose a group to view contacts.
                  </div>
                ) : contacts.length === 0 ? (
                  <div className="p-8 text-center text-xs text-theme-muted">
                    No contacts registered.
                  </div>
                ) : (
                  contacts.map((c) => (
                    <div
                      key={c.id}
                      onClick={() => fetchContactDetails(c.id)}
                      className={`p-4 hover:bg-[#1A1C21] transition-colors flex flex-col gap-2 relative cursor-pointer ${
                        isMobile ? 'mobile-card mb-3' : 'border-b border-theme-border/30'
                      } ${
                        selectedContact?.id === c.id ? 'border-theme-accent/25 bg-theme-accent/5' : ''
                      }`}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-semibold text-theme-primary text-sm">{c.full_name}</div>
                          <div className="text-theme-muted text-xs mt-0.5">{c.email}</div>
                        </div>
                        <span className={`text-[10px] px-2 py-0.5 rounded-none font-semibold uppercase ${
                          c.status === 'active' 
                            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20' 
                            : 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                        }`}>
                          {c.status}
                        </span>
                      </div>
                      {c.company && (
                        <div className="text-xs text-theme-secondary font-medium">
                          {c.company} {c.designation ? `— ${c.designation}` : ''}
                        </div>
                      )}
                      {c.tags && c.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {c.tags.map((t: any) => (
                            <span
                              key={t.id}
                              style={{ backgroundColor: `${t.color}15`, color: t.color }}
                              className="text-[10px] px-2 py-0.5 rounded-none font-semibold border border-transparent"
                            >
                              {t.name}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            ) : (
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-theme-app/50 border-b border-theme-border text-theme-muted font-bold uppercase text-[10px] tracking-wider">
                    <th className="w-10 pl-6 py-3">
                      <input 
                        type="checkbox"
                        checked={contacts.length > 0 && selectedContactIds.length === contacts.length}
                        onChange={handleSelectAll}
                        className="custom-checkbox"
                      />
                    </th>
                    <th className="px-6 py-3">Contact</th>
                    <th className="px-6 py-3">Company</th>
                    <th className="px-6 py-3">Groups</th>
                    <th className="px-6 py-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-theme-border/50">
                  {loading ? (
                    Array.from({ length: 5 }).map((_, idx) => (
                      <tr key={idx} className="border-b border-theme-border/30">
                        <td className="w-10 pl-6 py-4">
                          <div className="w-4 h-4 bg-theme-border/50 rounded-none animate-pulse" />
                        </td>
                        <td className="px-6 py-4">
                          <div className="h-4 bg-theme-border/50 rounded-none animate-pulse w-32" />
                          <div className="h-3 bg-theme-border/30 rounded-none animate-pulse w-24 mt-2" />
                        </td>
                        <td className="px-6 py-4">
                          <div className="h-4 bg-theme-border/50 rounded-none animate-pulse w-28" />
                          <div className="h-3 bg-theme-border/30 rounded-none animate-pulse w-16 mt-2" />
                        </td>
                        <td className="px-6 py-4">
                          <div className="h-5 bg-theme-border/40 rounded-none animate-pulse w-14" />
                        </td>
                        <td className="px-6 py-4">
                          <div className="h-5 bg-theme-border/40 rounded-none animate-pulse w-16" />
                        </td>
                      </tr>
                    ))
                  ) : activeTab === 'groups' && !selectedGroup ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-16 text-center">
                        <div className="flex flex-col items-center justify-center space-y-3">
                          <FontAwesomeIcon icon={Tag} className="h-10 w-10 text-theme-muted" />
                          <p className="text-sm font-semibold text-theme-primary">No Group Selected</p>
                          <p className="text-xs text-theme-muted max-w-[280px] mx-auto">Please choose a group from the dropdown above to view its contacts.</p>
                        </div>
                      </td>
                    </tr>
                  ) : contacts.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-16 text-center">
                        <div className="flex flex-col items-center justify-center space-y-3">
                          <FontAwesomeIcon icon={User} className="h-10 w-10 text-theme-muted" />
                          <p className="text-sm font-semibold text-[#60A5FA]">No contacts registered</p>
                          <p className="text-xs text-theme-muted max-w-[280px] mx-auto">Import a CSV mailing list to get started.</p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    contacts.map((c) => (
                      <tr
                        key={c.id}
                        onClick={() => fetchContactDetails(c.id)}
                        className={`cursor-pointer hover:bg-theme-hover/60 border-b border-theme-border/50 transition-colors ${
                          selectedContact?.id === c.id ? 'bg-theme-accent/5 hover:bg-theme-accent/10' : ''
                        }`}
                      >
                        <td className="w-10 pl-6 py-4" onClick={(e) => e.stopPropagation()}>
                          <input 
                            type="checkbox"
                            checked={selectedContactIds.includes(c.id)}
                            onChange={(e) => handleToggleSelect(c.id, e as any)}
                            className="custom-checkbox"
                          />
                        </td>
                        <td className="px-6 py-4">
                          <div className="font-semibold text-theme-primary text-sm">{c.full_name}</div>
                          <div className="text-theme-muted text-xs mt-0.5">{c.email}</div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-theme-secondary text-sm">{c.company || '—'}</div>
                          <div className="text-theme-muted text-xs mt-0.5">{c.designation || ''}</div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-1">
                            {c.tags?.map((t: any) => (
                              <span
                                key={t.id}
                                style={{ backgroundColor: `${t.color}15`, color: t.color }}
                                className="text-xs px-2.5 py-0.5 rounded-none font-semibold border border-transparent"
                              >
                                {t.name}
                              </span>
                            )) || '—'}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`text-xs px-2.5 py-0.5 rounded-none font-semibold uppercase ${
                            c.status === 'active' 
                              ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20' 
                              : c.status === 'unsubscribed'
                              ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border border-rose-500/20'
                              : 'bg-theme-app border border-theme-border text-theme-secondary'
                          }`}>
                            {c.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            )}
          </div>

          {/* Pagination */}
          {total > 20 && (
            <div className="p-4 bg-theme-app border-t border-theme-border flex justify-between items-center text-xs">
              <button
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
                className="px-3 py-1.5 border border-theme-border bg-theme-surface rounded-none hover:bg-theme-app disabled:opacity-50 text-theme-secondary"
              >
                Previous
              </button>
              <span className="text-theme-muted">Page {page} of {Math.ceil(total / 20)} ({total} contacts)</span>
              <button
                disabled={page * 20 >= total}
                onClick={() => setPage(page + 1)}
                className="px-3 py-1.5 border border-theme-border bg-theme-surface rounded-none hover:bg-theme-app disabled:opacity-50 text-theme-secondary"
              >
                Next
              </button>
            </div>
          )}
        </div>

        {/* Contact Details Panel */}
        {(!isMobile || selectedContact) && (
          <div className={isMobile 
            ? "fixed inset-0 z-[9999] overflow-y-auto bg-theme-app p-6 pb-28 flex flex-col space-y-6 animate-slide-up text-theme-primary" 
            : "bg-theme-surface rounded-none p-6 space-y-6 border border-theme-border"
          }>
            {isMobile && (
              <div className="flex items-center gap-3 pb-4 border-b border-theme-border shrink-0">
                <button
                  type="button"
                  onClick={() => setSelectedContact(null)}
                  className="p-2 -ml-2 text-theme-muted hover:text-theme-primary cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
                >
                  <FontAwesomeIcon icon={ArrowLeft} className="h-5 w-5" />
                </button>
                <h2 className="text-sm font-bold uppercase tracking-wider text-theme-accent">Contact Details</h2>
              </div>
            )}
            {selectedContact ? (
              <div className="space-y-4 animate-slide-in">
                <div className={`p-5 border border-theme-border bg-theme-surface ${isMobile ? 'mobile-card' : 'rounded-none'} space-y-4`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-xl font-bold font-outfit text-theme-primary font-heading" style={{ fontFamily: 'var(--font-heading)' }}>{selectedContact.full_name}</h3>
                      <p className="text-theme-muted text-xs font-semibold mt-1">UUID: {selectedContact.id.slice(0, 8)}...</p>
                    </div>
                  <button
                    onClick={() => handleDeleteContact(selectedContact.id)}
                    className="p-2 text-red-655 hover:bg-red-500/10 rounded-none transition-colors"
                    title="Delete Contact"
                  >
                    <FontAwesomeIcon icon={Trash} className="h-5 w-5" />
                  </button>
                </div>

                {/* Information List */}
                <div className="space-y-3.5 text-sm">
                  <div className="flex items-center gap-3 text-theme-secondary">
                    <FontAwesomeIcon icon={Mail} className="h-4 w-4 shrink-0 text-theme-muted" />
                    <span>{selectedContact.email}</span>
                  </div>
                  {selectedContact.company && (
                    <div className="flex items-center gap-3 text-theme-secondary">
                      <FontAwesomeIcon icon={Building} className="h-4 w-4 shrink-0 text-theme-muted" />
                      <span>{selectedContact.company} ({selectedContact.designation})</span>
                    </div>
                  )}
                  {selectedContact.phone && (
                    <div className="flex items-center gap-3 text-theme-secondary">
                      <FontAwesomeIcon icon={Phone} className="h-4 w-4 shrink-0 text-theme-muted" />
                      <span>{selectedContact.phone}</span>
                    </div>
                  )}
                  {selectedContact.website && (
                    <div className="flex items-center gap-3 text-theme-secondary">
                      <FontAwesomeIcon icon={Globe} className="h-4 w-4 shrink-0 text-theme-muted" />
                       <a href={selectedContact.website} target="_blank" rel="noreferrer" className="text-theme-accent hover:text-theme-accentHover hover:underline font-medium">
                        {selectedContact.website}
                      </a>
                    </div>
                  )}
                </div>
              </div>

              {/* Tags/Groups Management Section */}
                <div className={`p-5 border border-theme-border bg-theme-surface ${isMobile ? 'mobile-card' : 'rounded-none'} space-y-3`}>
                  <div className="flex items-center gap-2">
                    <FontAwesomeIcon icon={Tag} className="h-4 w-4 text-theme-muted" />
                    <span className="text-xs font-bold uppercase tracking-wider text-theme-muted">Assigned Groups/Tags</span>
                  </div>
                  <div className="flex flex-wrap gap-1.5 min-h-[24px]">
                    {selectedContact.tags && selectedContact.tags.length > 0 ? (
                      selectedContact.tags.map((t: any) => (
                        <span key={t.id} className="inline-flex items-center gap-1.5 px-3 py-1 rounded-none text-xs font-semibold bg-theme-app border border-theme-border text-theme-secondary">
                          <span>{t.name}</span>
                          <button
                            type="button"
                            onClick={() => handleRemoveTagFromContact(selectedContact.id, t.id)}
                            className="hover:text-red-500 transition-colors cursor-pointer"
                            title="Remove Tag"
                          >
                            <FontAwesomeIcon icon={X} className="h-3 w-3" />
                          </button>
                        </span>
                      ))
                    ) : (
                      <span className="text-xs text-theme-muted italic">No groups/tags assigned to this contact.</span>
                    )}
                  </div>
                  
                  <div className="flex gap-2 pt-1.5">
                    <input
                      type="text"
                      placeholder="Add to tag/group (e.g. VIP)..."
                      value={detailTagInput}
                      onChange={(e) => setDetailTagInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddTagToContact(selectedContact.id);
                        }
                      }}
                      className="flex-1 px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-xs text-theme-primary placeholder-theme-muted focus:outline-none focus:border-theme-accent font-semibold"
                    />
                    <button
                      type="button"
                      onClick={() => handleAddTagToContact(selectedContact.id)}
                      className="px-4 py-2 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-xs transition-colors cursor-pointer uppercase tracking-wider"
                    >
                      Add Group
                    </button>
                  </div>
                </div>

                {/* Contact Notes Timeline */}
                <div className={`p-5 border border-theme-border bg-theme-surface ${isMobile ? 'mobile-card' : 'rounded-none'} space-y-4`}>
                  <h4 className="font-bold text-sm flex items-center gap-2 text-theme-primary font-heading" style={{ fontFamily: 'var(--font-heading)' }}>
                    <FontAwesomeIcon icon={MessageSquare} className="h-4 w-4 text-theme-muted" />
                    <span>Activity Timeline & Notes</span>
                  </h4>

                  <form onSubmit={handleAddNote} className="space-y-2">
                    <textarea
                      placeholder="Add an internal outreach log or note..."
                      value={noteContent}
                      onChange={(e) => setNoteContent(e.target.value)}
                      required
                      className="w-full p-3 bg-theme-surface border border-theme-input rounded-none text-sm text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors resize-none h-20"
                    />
                    <div className="flex justify-end">
                      <button
                        type="submit"
                        className="px-3.5 py-1.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-xs transition-colors uppercase tracking-wider"
                      >
                        Post Note
                      </button>
                    </div>
                  </form>

                  <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
                    {notes.length === 0 ? (
                      <p className="text-xs text-theme-muted text-center py-4">No logged notes for this contact yet.</p>
                    ) : (
                      notes.map((note) => (
                        <div key={note.id} className={`p-3 bg-theme-app border border-theme-border rounded-none space-y-1 ${isMobile ? 'mobile-card' : ''}`}>
                          <div className="flex justify-between text-xs text-theme-muted font-semibold">
                            <span>{note.author_name}</span>
                            <span>{new Date(note.created_at).toLocaleDateString()}</span>
                          </div>
                          <p className="text-xs text-theme-secondary leading-relaxed whitespace-pre-wrap">{note.content}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-16 text-theme-muted flex flex-col justify-center items-center">
                <FontAwesomeIcon icon={User} className="h-12 w-12 mb-3 text-theme-muted" />
                <p className="text-sm font-semibold">No Contact Selected</p>
                <p className="text-xs text-theme-muted mt-1 max-w-[200px]">Click a contact in the table list to inspect tags, details, and logged timeline.</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Add Contact Modal */}
      {showAddModal && createPortal(
        <div className="modal-backdrop" onClick={() => setShowAddModal(false)}>
          <div 
            className="modal-content bg-theme-surface border border-theme-border text-theme-primary rounded-none w-full max-w-xl max-h-[90vh] flex flex-col overflow-hidden relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-6 py-4 border-b border-theme-border shrink-0">
              <h3 className="text-xl font-bold font-outfit text-theme-primary">Add New Outreach Contact</h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-1.5 rounded-none hover:bg-theme-app transition-colors text-theme-muted"
              >
                <FontAwesomeIcon icon={X} className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleAddContact} className="flex-1 flex flex-col min-h-0">
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Full Name</label>
                    <input
                      type="text"
                      required
                      placeholder="Grace Harper"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Email Address</label>
                    <input
                      type="email"
                      required
                      placeholder="grace@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Company Name</label>
                    <input
                      type="text"
                      placeholder="Google DeepMind"
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Designation</label>
                    <input
                      type="text"
                      placeholder="Researcher"
                      value={designation}
                      onChange={(e) => setDesignation(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-1">
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Phone Number</label>
                    <input
                      type="text"
                      placeholder="+1-555-0100"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors"
                    />
                  </div>
                  <div className="md:col-span-1">
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Website URL</label>
                    <input
                      type="url"
                      placeholder="https://example.com"
                      value={website}
                      onChange={(e) => setWebsite(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors"
                    />
                  </div>
                  <div className="md:col-span-1">
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">LinkedIn Profile</label>
                    <input
                      type="text"
                      placeholder="linkedin.com/in/user"
                      value={linkedin}
                      onChange={(e) => setLinkedin(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors"
                    />
                  </div>
                </div>

                {/* Tags Selector */}
                <div>
                  <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Tags</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. Sponsor, Recruitment, VIP"
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddTag();
                        }
                      }}
                      className="flex-1 px-3.5 py-2.5 bg-theme-surface border border-theme-input rounded-none text-sm text-theme-primary placeholder-[#64748b] focus:outline-none focus:border-[#00b5ad] focus:ring-0 transition-colors"
                    />
                    <button
                      type="button"
                      onClick={handleAddTag}
                      className="px-4 py-2.5 bg-theme-surface border border-theme-border hover:bg-theme-app rounded-none font-semibold text-sm transition-colors text-theme-secondary"
                    >
                      Add Tag
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1.5 text-xs px-2.5 py-1 bg-theme-accent/10 text-theme-accent border border-[#00b5ad]/20 rounded-none font-semibold"
                      >
                        <span>{tag}</span>
                        <button type="button" onClick={() => handleRemoveTag(idx)} className="hover:text-red-500">
                          <FontAwesomeIcon icon={X} className="h-3 w-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="px-6 py-4 border-t border-theme-border bg-theme-app/30 flex justify-end gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 bg-theme-surface border border-theme-border hover:bg-theme-app rounded-none font-semibold text-sm transition-colors text-theme-primary"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingContact}
                  className="px-6 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-sm transition-colors disabled:opacity-50 uppercase tracking-wider"
                >
                  {savingContact ? 'Saving...' : 'Save Contact'}
                </button>
              </div>
            </form>
          </div>
        </div>,
        document.body
      )}
      {/* CSV Import Guide & Upload Modal */}
      {showImportModal && createPortal(
        <div className="modal-backdrop" onClick={() => { if (!uploadingCsv) { setShowImportModal(false); setImportGroupMode('existing'); setImportSelectedTagId(''); setImportNewGroupName(''); } }}>
          <div 
            className="modal-content w-full max-w-xl max-h-[90vh] flex flex-col overflow-hidden relative text-left rounded-none bg-theme-surface border border-theme-border text-theme-primary shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-6 py-4 border-b border-theme-border shrink-0">
              <h3 className="text-xl font-bold font-outfit text-theme-primary">Import Contacts from CSV</h3>
              <button
                disabled={uploadingCsv}
                onClick={() => { if (!uploadingCsv) { setShowImportModal(false); setImportGroupMode('existing'); setImportSelectedTagId(''); setImportNewGroupName(''); } }}
                className="p-1.5 rounded-none hover:bg-theme-hover transition-colors text-theme-muted disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <FontAwesomeIcon icon={X} className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <p className="text-xs text-theme-muted leading-relaxed">
                Upload a comma-separated values (CSV) file containing your contact database. You can also define custom columns, and they will be automatically imported as custom attributes.
              </p>

              {/* CSV Structure Guide */}
              <div className="space-y-4">
                <div className="p-4 rounded-none bg-theme-app border border-theme-border">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-theme-secondary mb-2">Required Headers</h4>
                  <div className="flex flex-wrap gap-2 text-xs">
                    <span className="px-2 py-1 rounded-none font-mono font-bold text-red-500 bg-red-500/10 border border-red-500/20">email</span>
                    <span className="px-2 py-1 rounded-none font-mono font-bold text-red-500 bg-red-500/10 border border-red-500/20">name <span className="font-sans font-normal text-theme-muted">or</span> full_name</span>
                  </div>
                  <p className="text-xs text-theme-muted mt-2">Every row must contain a valid name and email address to import successfully.</p>
                </div>

                <div className="p-4 rounded-none bg-theme-app border border-theme-border">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-theme-secondary mb-2">Optional Standard Headers</h4>
                  <div className="flex flex-wrap gap-1.5 font-mono text-xs text-theme-muted">
                    {['company', 'designation', 'phone', 'website', 'linkedin', 'tags'].map(h => (
                      <span key={h} className="px-1.5 py-0.5 rounded-none bg-theme-surface border border-theme-border text-theme-secondary">{h}</span>
                    ))}
                  </div>
                  <p className="text-xs text-theme-muted mt-2">
                    <span className="text-theme-secondary font-semibold">tags</span> can be a comma-separated list (e.g. <code className="font-mono text-theme-accent">vip,prospect</code>). Any other columns will be stored as custom fields.
                  </p>
                </div>

                {/* Sample Preview */}
                <div className="p-4 rounded-none font-mono text-xs text-theme-secondary overflow-x-auto whitespace-nowrap bg-theme-surface border border-theme-border">
                  <span className="text-theme-accent">name,email,company,designation,tags</span><br />
                  Grace Harper,grace@harper.com,Harper Inds,CEO,vip,prospect<br />
                  Aditya Pidurkar,aditya@pidurkar.com,TechCorp,Founder,prospect
                </div>
              </div>
            </div>

            {/* Group Assignment Section */}
            <div className="px-6 py-4 border-t border-theme-border bg-theme-app/20 space-y-3 shrink-0">
              <h4 className="text-xs font-bold uppercase tracking-wider text-theme-secondary">Assign to Group <span className="font-normal text-theme-muted">(optional)</span></h4>
              
              {/* Toggle: Existing / New */}
              <div className="flex gap-0 border border-theme-border rounded-none overflow-hidden w-fit">
                <button
                  type="button"
                  onClick={() => setImportGroupMode('existing')}
                  className={`px-4 py-1.5 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer ${
                    importGroupMode === 'existing'
                      ? 'bg-emerald-500 text-white'
                      : 'bg-theme-surface text-theme-muted hover:text-theme-secondary'
                  }`}
                >
                  Existing Group
                </button>
                <button
                  type="button"
                  onClick={() => setImportGroupMode('new')}
                  className={`px-4 py-1.5 text-xs font-bold uppercase tracking-wider transition-colors border-l border-theme-border cursor-pointer ${
                    importGroupMode === 'new'
                      ? 'bg-emerald-500 text-white'
                      : 'bg-theme-surface text-theme-muted hover:text-theme-secondary'
                  }`}
                >
                  Create New
                </button>
              </div>

              {importGroupMode === 'existing' ? (
                <select
                  value={importSelectedTagId}
                  onChange={(e) => setImportSelectedTagId(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-theme-surface border border-theme-border rounded-none text-theme-primary focus:outline-none focus:border-theme-accent"
                >
                  <option value="">— No group (import without group) —</option>
                  {availableTags.map((tag: any) => (
                    <option key={tag.id} value={tag.id}>{tag.name}</option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  value={importNewGroupName}
                  onChange={(e) => setImportNewGroupName(e.target.value)}
                  placeholder="Enter new group name..."
                  className="w-full px-3 py-2 text-xs bg-theme-surface border border-theme-border rounded-none text-theme-primary placeholder:text-theme-muted focus:outline-none focus:border-theme-accent"
                />
              )}
            </div>

            {/* Action Buttons inside Modal */}
            <div className="px-6 py-4 border-t border-theme-border bg-theme-app/30 flex flex-col sm:flex-row items-center justify-end gap-3 shrink-0">
              <button
                type="button"
                disabled={uploadingCsv}
                onClick={() => {
                  if (uploadingCsv) return;
                  const csvHeaders = "name,email,company,designation,phone,website,linkedin,tags\n";
                  const csvData = "Grace Harper,grace@harper.com,Harper Industries,CEO,+1234567890,https://harper.com,https://linkedin.com/in/grace,vip,prospect\n";
                  const blob = new Blob([csvHeaders + csvData], { type: 'text/csv;charset=utf-8;' });
                  const url = URL.createObjectURL(blob);
                  const link = document.createElement("a");
                  link.setAttribute("href", url);
                  link.setAttribute("download", "sample_contacts.csv");
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                  addToast("Downloaded sample_contacts.csv successfully!", "success");
                }}
                className="w-full sm:w-auto px-4 py-2.5 rounded-none font-bold text-xs transition-colors flex items-center justify-center gap-2 bg-theme-surface border border-theme-border text-theme-secondary cursor-pointer hover:bg-theme-hover disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <FontAwesomeIcon icon={Download} className="h-4 w-4" />
                <span>Download Sample CSV</span>
              </button>

              <label className={`w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-xs transition-colors select-none uppercase tracking-wider ${uploadingCsv ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}>
                {uploadingCsv ? (
                  <>
                    <FontAwesomeIcon icon={RefreshCw} className="h-4 w-4 fa-spin" />
                    <span>Processing Import...</span>
                  </>
                ) : (
                  <>
                    <FontAwesomeIcon icon={Upload} className="h-4 w-4" />
                    <span>Select & Upload CSV</span>
                  </>
                )}
                <input type="file" accept=".csv" onChange={handleCsvImport} disabled={uploadingCsv} className="hidden" />
              </label>
            </div>
          </div>
        </div>,
        document.body
      )}
      {/* CSV Import Summary Modal */}
      {importSummary && createPortal(
        <div className="modal-backdrop" onClick={() => { setImportSummary(null); fetchContacts(); }}>
          <div 
            className="modal-content w-full max-w-xl max-h-[85vh] flex flex-col overflow-hidden relative text-left rounded-none bg-theme-surface border border-theme-border text-theme-primary shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-6 py-4 border-b border-theme-border shrink-0">
              <h3 className="text-xl font-bold font-outfit text-theme-primary uppercase tracking-wider">Import CSV Summary</h3>
              <button
                onClick={() => { setImportSummary(null); fetchContacts(); }}
                className="p-1.5 rounded-none hover:bg-theme-hover transition-colors text-theme-muted"
              >
                <FontAwesomeIcon icon={X} className="h-5 w-5" />
              </button>
            </div>
            
            {/* BMW M Stripe Divider */}
            <div className="m-stripe-divider h-[3px] shrink-0" />

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Status Indicator Banner */}
              <div className={`p-4 border rounded-none ${
                importSummary.errors && importSummary.errors.length > 0 
                  ? 'bg-rose-500/10 border-rose-500/30 text-rose-450' 
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-450'
              }`}>
                <h4 className="text-sm font-bold uppercase tracking-wider mb-1">
                  {importSummary.errors && importSummary.errors.length > 0 ? 'Import Completed with Failures' : 'Import Successful'}
                </h4>
                <p className="text-xs text-theme-muted">
                  {importSummary.message || 'The CSV contact database file has been processed successfully.'}
                </p>
              </div>

              {/* Stats Counters Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                <div className="p-3 bg-theme-app border border-theme-border rounded-none">
                  <div className="text-2xl font-bold font-outfit text-emerald-500">
                    {importSummary.summary?.added ?? 0}
                  </div>
                  <div className="text-[10px] text-theme-muted font-bold uppercase mt-1">Added</div>
                </div>

                <div className="p-3 bg-theme-app border border-theme-border rounded-none">
                  <div className="text-2xl font-bold font-outfit text-blue-500">
                    {importSummary.summary?.updated ?? 0}
                  </div>
                  <div className="text-[10px] text-theme-muted font-bold uppercase mt-1">Updated</div>
                </div>

                <div className="p-3 bg-theme-app border border-theme-border rounded-none">
                  <div className="text-2xl font-bold font-outfit text-amber-500">
                    {importSummary.summary?.duplicates_skipped ?? 0}
                  </div>
                  <div className="text-[10px] text-theme-muted font-bold uppercase mt-1">In-File Dupes</div>
                </div>

                <div className="p-3 bg-theme-app border border-theme-border rounded-none">
                  <div className="text-2xl font-bold font-outfit text-rose-500">
                    {importSummary.summary?.failed ?? 0}
                  </div>
                  <div className="text-[10px] text-theme-muted font-bold uppercase mt-1">Failed</div>
                </div>
              </div>

              {/* Group Associated (if any) */}
              {importSummary.tag && (
                <div className="p-4 bg-theme-app border border-theme-border rounded-none flex items-center justify-between text-xs">
                  <span className="text-theme-muted font-semibold uppercase">Assigned Group:</span>
                  <span 
                    style={{ backgroundColor: `${importSummary.tag.color}15`, color: importSummary.tag.color }}
                    className="px-2.5 py-0.5 rounded-none font-bold border border-theme-border/20"
                  >
                    {importSummary.tag.name}
                  </span>
                </div>
              )}

              {/* Detailed Failures Table */}
              {importSummary.errors && importSummary.errors.length > 0 && (
                <div className="space-y-3.5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-rose-500 font-mono">
                    Failed Rows & Verification Reasons ({importSummary.errors.length})
                  </h4>
                  
                  <div className="border border-theme-border rounded-none max-h-48 overflow-y-auto">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-theme-app border-b border-theme-border text-theme-muted font-bold uppercase text-[9px] tracking-wider">
                          <th className="px-3 py-2 w-16">Row</th>
                          <th className="px-3 py-2 w-48">Value</th>
                          <th className="px-3 py-2">Failure Reason</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-theme-border/50 font-mono text-[11px] text-theme-secondary bg-theme-surface">
                        {importSummary.errors.map((err: any, idx: number) => (
                          <tr key={idx} className="hover:bg-theme-hover/20">
                            <td className="px-3 py-2 text-theme-muted font-bold">#{err.row}</td>
                            <td className="px-3 py-2 truncate max-w-[12rem]">{err.email || '—'}</td>
                            <td className="px-3 py-2 text-rose-500 font-medium">{err.reason}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-4 border-t border-theme-border bg-theme-app/30 flex justify-end shrink-0">
              <button
                type="button"
                onClick={() => { setImportSummary(null); fetchContacts(); }}
                className="px-6 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
              >
                Dismiss Summary
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
