import React, { useState, useEffect } from 'react';
import { API_BASE } from '../config';
import { Mail, Lock, User, ShieldAlert, Sparkles } from 'lucide-react';

interface LoginProps {
  onLoginSuccess: (token: string, user: any) => void;
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const [isSetup, setIsSetup] = useState(false);
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Check if system is initialized (needs setup)
  useEffect(() => {
    checkSetup();
  }, []);

  const checkSetup = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/v1/auth/setup-status`);
      const data = await res.json();
      if (data && data.need_setup) {
        setIsSetup(true);
      } else {
        setIsSetup(false);
      }
    } catch (e) {
      console.log("Could not check setup:", e);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const formData = new URLSearchParams();
      formData.append('username', username);
      formData.append('password', password);

      const response = await fetch(`${API_BASE}/api/v1/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Login failed. Please check credentials.');
      }

      onLoginSuccess(data.access_token, data.user);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch(`${API_BASE}/api/v1/auth/setup-initial-admin`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          full_name: fullName,
          username,
          email,
          password,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Setup failed.');
      }

      // Successful setup! Now switch to login mode and fill in details
      setIsSetup(false);
      setError('System initialized! Please login with your credentials.');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-transparent flex flex-col justify-center items-center p-6 relative overflow-hidden font-outfit">
      {/* Decorative glowing background orbs */}
      <div className="glow-orb-indigo top-[-5%] left-[-5%] opacity-40" style={{ background: 'radial-gradient(circle, rgba(0,181,173,0.15) 0%, transparent 70%)' }} />
      <div className="glow-orb-purple bottom-[-5%] right-[-5%] opacity-30" style={{ background: 'radial-gradient(circle, rgba(0,156,149,0.12) 0%, transparent 70%)' }} />
      
      <div className="w-full max-w-md bg-theme-surface/80 backdrop-blur-2xl border border-theme-border rounded-2xl p-8 shadow-2xl relative glow-border animate-slide-in">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-theme-primary font-outfit tracking-tight">ThunderCipher Mailer</h2>
          <p className="text-theme-secondary text-xs mt-1.5 font-medium">
            {isSetup ? 'Create the master administrator account' : 'Enterprise Outreach Portal'}
          </p>
        </div>

        {error && (
          <div className={`p-4 rounded-xl text-xs mb-6 flex items-start gap-3 border transition-all duration-300 ${
            error.includes('initialized') 
              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' 
              : 'bg-red-500/10 border-red-500/20 text-red-500'
          }`}>
            <ShieldAlert className="h-5 w-5 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {isSetup ? (
          <form onSubmit={handleSetup} className="space-y-4">
            <div>
              <label className="block text-theme-secondary text-xs font-semibold uppercase tracking-wider mb-1.5">Full Name</label>
              <div className="relative">
                <User className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-theme-secondary" />
                <input
                  type="text"
                  required
                  placeholder="Grace Harper"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-theme-surface border border-theme-input rounded-xl text-theme-primary placeholder-theme-secondary focus:outline-none focus:border-theme-accent focus:ring-2 focus:ring-theme-accent/20 transition-all duration-300 text-sm shadow-inner"
                />
              </div>
            </div>

            <div>
              <label className="block text-theme-secondary text-xs font-semibold uppercase tracking-wider mb-1.5">Username</label>
              <div className="relative">
                <User className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-theme-secondary" />
                <input
                  type="text"
                  required
                  placeholder="admin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-theme-surface border border-theme-input rounded-xl text-theme-primary placeholder-theme-secondary focus:outline-none focus:border-theme-accent focus:ring-2 focus:ring-theme-accent/20 transition-all duration-300 text-sm shadow-inner"
                />
              </div>
            </div>

            <div>
              <label className="block text-theme-secondary text-xs font-semibold uppercase tracking-wider mb-1.5">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-theme-secondary" />
                <input
                  type="email"
                  required
                  placeholder="admin@thundercipher.in"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-theme-surface border border-theme-input rounded-xl text-theme-primary placeholder-theme-secondary focus:outline-none focus:border-theme-accent focus:ring-2 focus:ring-theme-accent/20 transition-all duration-300 text-sm shadow-inner"
                />
              </div>
            </div>

            <div>
              <label className="block text-theme-secondary text-xs font-semibold uppercase tracking-wider mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-theme-secondary" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-theme-surface border border-theme-input rounded-xl text-theme-primary placeholder-theme-secondary focus:outline-none focus:border-theme-accent focus:ring-2 focus:ring-theme-accent/20 transition-all duration-300 text-sm shadow-inner"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-premium py-3 mt-4 disabled:opacity-50 disabled:cursor-not-allowed text-sm font-bold text-theme-btnText"
            >
              {loading ? 'Initializing...' : 'Setup Administrator'}
            </button>

            <div className="text-center mt-4">
              <button
                type="button"
                onClick={() => setIsSetup(false)}
                className="text-xs text-theme-secondary hover:underline hover:text-theme-accent transition-colors"
              >
                Back to Login
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-theme-secondary text-xs font-semibold uppercase tracking-wider mb-1.5">Email or Username</label>
              <div className="relative">
                <User className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-theme-secondary" />
                <input
                  type="text"
                  required
                  placeholder="admin@thundercipher.in"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-theme-surface border border-theme-input rounded-xl text-theme-primary placeholder-theme-secondary focus:outline-none focus:border-theme-accent focus:ring-2 focus:ring-theme-accent/20 transition-all duration-300 text-sm shadow-inner"
                />
              </div>
            </div>

            <div>
              <label className="block text-theme-secondary text-xs font-semibold uppercase tracking-wider mb-1.5">Password</label>
              <div className="relative">
                <Lock className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-theme-secondary" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-theme-surface border border-theme-input rounded-xl text-theme-primary placeholder-theme-secondary focus:outline-none focus:border-theme-accent focus:ring-2 focus:ring-theme-accent/20 transition-all duration-300 text-sm shadow-inner"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full btn-premium py-3 mt-4 disabled:opacity-50 disabled:cursor-not-allowed text-sm font-bold text-theme-btnText"
            >
              {loading ? 'Signing In...' : 'Sign In'}
            </button>

            <div className="text-center mt-6 text-xs text-theme-secondary">
              Don't have an account?{' '}
              <span className="text-theme-accent font-semibold">Request access from your administrator</span>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
