import React, { useState, useEffect, useRef } from 'react';
import { API_BASE } from '../config';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../contexts/ToastContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faGear as SettingsIcon, faWandMagicSparkles as Sparkles, faShieldHalved as Shield, faBell as Bell, faUser as User, faVolumeHigh as Volume2, 
  faFloppyDisk as Save, faCheck as Check, faFont as Type, faCaretDown as ChevronDown, faCaretRight as ChevronRight, 
  faUpload as Upload, faPlus as Plus, faXmark as X, faTrashCan as Trash2, faPalette as Palette, faKeyboard as Keyboard, 
  faServer as Server, faTag as Tag, faCircleInfo as Info, faArrowLeft as ArrowLeft
} from '@fortawesome/free-solid-svg-icons';

export default function Settings({ token }: { token: string }) {
  const { addToast } = useToast();
  const { 
    theme, setTheme, 
    accent, setAccent, 
    density, setDensity, 
    panePosition, setPanePosition 
  } = useTheme();

  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);
  const [mobileActiveTab, setMobileActiveTab] = useState<'general' | 'appearance' | 'labels' | 'shortcuts' | 'accounts' | null>(null);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState<'general' | 'appearance' | 'labels' | 'shortcuts' | 'accounts'>('general');

  // Profile Settings
  const [fullName, setFullName] = useState('');
  const [userRole, setUserRole] = useState('Operator');
  const [defaultSenderName, setDefaultSenderName] = useState(localStorage.getItem('setting_sender_name') || '');

  // AI Copilot Settings
  const [aiModel, setAiModel] = useState(localStorage.getItem('setting_ai_model') || 'gemini-2.5-flash');
  const [defaultTone, setDefaultTone] = useState(localStorage.getItem('setting_default_tone') || 'professional');
  const [mailboxBg, setMailboxBg] = useState(localStorage.getItem('setting_mailbox_bg') || 'sunset');

  // Safety & Warmup Settings
  const [dailyLimit, setDailyLimit] = useState(localStorage.getItem('setting_daily_limit') || '150');
  const [sendDelay, setSendDelay] = useState(localStorage.getItem('setting_send_delay') || '45');

  // Notifications Settings
  const [enableSound, setEnableSound] = useState(localStorage.getItem('setting_enable_sound') !== 'false');
  const [enableToasts, setEnableToasts] = useState(localStorage.getItem('setting_enable_toasts') !== 'false');

  // Discord Webhooks Settings
  const [failedMailsWebhook, setFailedMailsWebhook] = useState('');
  const [generalMailsWebhook, setGeneralMailsWebhook] = useState('');
  const [customCategories, setCustomCategories] = useState<{name: string, url: string}[]>([]);

  // UI Typography Font Settings
  const [fontBody, setFontBody] = useState(localStorage.getItem('setting_font_body') || 'DM Sans');
  const [fontHeading, setFontHeading] = useState(localStorage.getItem('setting_font_heading') || 'Cinzel');
  const [fontSize, setFontSize] = useState(localStorage.getItem('setting_font_size') || 'medium');
  const [fontWeight, setFontWeight] = useState(localStorage.getItem('setting_font_weight') || '400');
  const [letterSpacing, setLetterSpacing] = useState(localStorage.getItem('setting_letter_spacing') || 'normal');
  const [lineHeight, setLineHeight] = useState(localStorage.getItem('setting_line_height') || '1.6');

  // Labels Management State
  const [tagsList, setTagsList] = useState<any[]>([]);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState('#6366F1');
  const [creatingTag, setCreatingTag] = useState(false);

  // Accounts List State
  const [accounts, setAccounts] = useState<any[]>([]);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchProfile();
    fetchWebhooks();
    fetchTags();
    fetchAccounts();
  }, []);

  const fetchTags = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/tags`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setTagsList(data || []);
      }
    } catch (e) {
      console.error("Error fetching tags:", e);
    }
  };

  const fetchAccounts = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/smtp/`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setAccounts(data || []);
      }
    } catch (e) {
      console.error("Error fetching SMTP accounts:", e);
    }
  };

  const handleCreateTag = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagName.trim() || creatingTag) return;
    setCreatingTag(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/tags`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name: newTagName.trim(), color: newTagColor })
      });
      if (response.ok) {
        addToast(`Label "${newTagName}" created successfully!`, 'success');
        setNewTagName('');
        fetchTags();
      } else {
        const err = await response.json();
        addToast(err.detail || 'Failed to create label', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error creating label', 'error');
    } finally {
      setCreatingTag(false);
    }
  };

  const handleDeleteTag = async (tagId: string, tagName: string) => {
    if (!confirm(`Are you sure you want to delete label "${tagName}"?`)) return;
    try {
      const response = await fetch(`${API_BASE}/api/v1/contacts/tags/${tagId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        addToast(`Label "${tagName}" deleted successfully!`, 'success');
        fetchTags();
      } else {
        addToast('Failed to delete label', 'error');
      }
    } catch (err: any) {
      addToast(err.message || 'Error deleting label', 'error');
    }
  };

  const handleCustomBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        const MAX_SIZE = 1280;
        if (width > height) {
          if (width > MAX_SIZE) {
            height *= MAX_SIZE / width;
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width *= MAX_SIZE / height;
            height = MAX_SIZE;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.7);
          localStorage.setItem('setting_mailbox_bg_custom', compressedDataUrl);
          setMailboxBg('custom');
          localStorage.setItem('setting_mailbox_bg', 'custom');
          window.dispatchEvent(new Event('settings-changed'));
          addToast('Custom background updated!', 'success');
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const applyTypography = (configs: {
    body: string;
    heading: string;
    size: string;
    weight: string;
    spacing: string;
    leading: string;
  }) => {
    const fontMapping: Record<string, string> = {
      'Outfit': "'Outfit', sans-serif",
      'Inter': "'Inter', sans-serif",
      'DM Sans': "'DM Sans', sans-serif",
      'JetBrains Mono': "'JetBrains Mono', monospace",
      'Playfair Display': "'Playfair Display', serif",
      'Roboto': "'Roboto', sans-serif",
      'Lora': "'Lora', serif",
      'Poppins': "'Poppins', sans-serif"
    };

    const sizeMapping: Record<string, string> = {
      'small': '13px',
      'medium': '15px',
      'large': '17px',
      'xlarge': '19px'
    };

    const spacingMapping: Record<string, string> = {
      'tight': '-0.02em',
      'normal': '0em',
      'wide': '0.04em'
    };

    const root = document.documentElement;
    root.style.setProperty('--font-body', fontMapping[configs.body] || fontMapping['Outfit']);
    root.style.setProperty('--font-heading', fontMapping[configs.heading] || fontMapping['Outfit']);
    root.style.setProperty('--font-size-base', sizeMapping[configs.size] || sizeMapping['medium']);
    root.style.setProperty('--font-weight-base', configs.weight);
    root.style.setProperty('--letter-spacing-base', spacingMapping[configs.spacing] || spacingMapping['normal']);
    root.style.setProperty('--line-height-base', configs.leading);
  };

  const handleTypographyChange = (key: string, value: string) => {
    const updated = {
      body: key === 'body' ? value : fontBody,
      heading: key === 'heading' ? value : fontHeading,
      size: key === 'size' ? value : fontSize,
      weight: key === 'weight' ? value : fontWeight,
      spacing: key === 'spacing' ? value : letterSpacing,
      leading: key === 'leading' ? value : lineHeight
    };

    if (key === 'body') setFontBody(value);
    if (key === 'heading') setFontHeading(value);
    if (key === 'size') setFontSize(value);
    if (key === 'weight') setFontWeight(value);
    if (key === 'spacing') setLetterSpacing(value);
    if (key === 'leading') setLineHeight(value);

    applyTypography(updated);
    localStorage.setItem(`setting_font_${key}`, value);
  };

  const fetchWebhooks = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/settings/webhooks`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setFailedMailsWebhook(data.FAILED_MAILS_WEBHOOK || '');
        setGeneralMailsWebhook(data.GENERAL_MAILS_WEBHOOK || '');
        setCustomCategories(data.CUSTOM_CATEGORIES || []);
      }
    } catch (e) {
      console.error('Error fetching webhooks:', e);
    }
  };

  const fetchProfile = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/auth/me`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setFullName(data.full_name || '');
        setUserRole(data.role || 'Operator');
      }
    } catch (e) {
      console.error('Error fetching profile settings:', e);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    // Save frontend local storage settings
    localStorage.setItem('setting_ai_model', aiModel);
    localStorage.setItem('setting_default_tone', defaultTone);
    localStorage.setItem('setting_mailbox_bg', mailboxBg);
    localStorage.setItem('setting_daily_limit', dailyLimit);
    localStorage.setItem('setting_send_delay', sendDelay);
    localStorage.setItem('setting_enable_sound', String(enableSound));
    localStorage.setItem('setting_enable_toasts', String(enableToasts));
    localStorage.setItem('setting_sender_name', defaultSenderName);

    // Save all typography settings
    localStorage.setItem('setting_font_body', fontBody);
    localStorage.setItem('setting_font_heading', fontHeading);
    localStorage.setItem('setting_font_size', fontSize);
    localStorage.setItem('setting_font_weight', fontWeight);
    localStorage.setItem('setting_font_spacing', letterSpacing);
    localStorage.setItem('setting_font_leading', lineHeight);

    try {
      // Save profile updates to backend if changed
      await fetch(`${API_BASE}/api/v1/auth/me`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ full_name: fullName })
      });

      // Save Webhooks
      await fetch(`${API_BASE}/api/v1/settings/webhooks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          webhooks: {
            FAILED_MAILS_WEBHOOK: failedMailsWebhook,
            GENERAL_MAILS_WEBHOOK: generalMailsWebhook,
            CUSTOM_CATEGORIES: customCategories
          }
        })
      });
      
      addToast('Settings saved successfully!', 'success');
    } catch (err) {
      console.error('Failed to sync backend settings updates:', err);
      addToast('Error syncing profile settings with backend.', 'error');
    }

    window.dispatchEvent(new Event('settings-changed'));
    setLoading(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6 animate-slide-in text-left">
      {isMobile && mobileActiveTab === null ? (
        <div className="space-y-6">
          {isMobile && (
            <div className="flex justify-between items-center pb-2 shrink-0 bg-transparent relative z-10 pt-4">
              <h1 className="text-3xl font-extrabold tracking-tight text-white capitalize font-heading" style={{ fontFamily: 'var(--font-heading)' }}>
                Settings
              </h1>
              <div className="w-10 h-10 rounded-full bg-theme-accent text-theme-btnText flex items-center justify-center font-bold text-sm select-none border border-theme-border/20">
                {(() => {
                  const name = localStorage.getItem('setting_sender_name') || 'JD';
                  const parts = name.trim().split(/\s+/);
                  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
                  return parts[0].slice(0, 2).toUpperCase();
                })()}
              </div>
            </div>
          )}

          <div className="space-y-3 pt-2">
            {[
              { id: 'general', name: 'General Settings', icon: User, desc: 'Identity profile, limits' },
              { id: 'appearance', name: 'Appearance', icon: Palette, desc: 'Theme, accent colors, layouts' },
              { id: 'labels', name: 'Labels & Folders', icon: Tag, desc: 'Tags and custom categorization folders' },
              { id: 'shortcuts', name: 'Shortcuts', icon: Keyboard, desc: 'Keyboard mapping guidelines' },
              { id: 'accounts', name: 'SMTP Accounts', icon: Server, desc: 'Outgoing SMTP mail config' }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    setActiveTab(tab.id as any);
                    setMobileActiveTab(tab.id as any);
                  }}
                  className="w-full flex items-center justify-between p-4 bg-[#121316] border border-[#202226]/50 rounded-xl hover:brightness-105 transition-colors cursor-pointer min-h-[44px] mobile-card"
                  style={{ borderRadius: '16px' }}
                >
                  <div className="flex items-center gap-3.5">
                    <div className="p-2.5 bg-[#1F2025] rounded-lg text-theme-secondary">
                      <FontAwesomeIcon icon={Icon} className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-theme-primary">{tab.name}</div>
                      <div className="text-xs text-theme-muted font-medium mt-0.5">{tab.desc}</div>
                    </div>
                  </div>
                   <FontAwesomeIcon icon={ChevronRight} className="h-5 w-5 text-theme-muted" />
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <>
          {isMobile ? (
            <div className="flex items-center gap-3 pb-4 border-b border-[#202226]/50 shrink-0">
              <button
                type="button"
                onClick={() => setMobileActiveTab(null)}
                className="p-1.5 -ml-1.5 text-theme-muted hover:text-theme-primary cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center mr-1"
              >
                <FontAwesomeIcon icon={ArrowLeft} className="h-5.5 w-5.5" />
              </button>
              <h2 className="text-sm font-bold uppercase tracking-wider text-theme-accent font-heading" style={{ fontFamily: 'var(--font-heading)' }}>
                {mobileActiveTab} Settings
              </h2>
            </div>
          ) : (
            <div className="flex justify-between items-center border-b border-theme-border/60 pb-5">
              <div>
                <h1 className="text-3xl font-extrabold tracking-tight text-theme-primary font-display uppercase flex items-center gap-3">
                  <FontAwesomeIcon icon={SettingsIcon} className="h-8 w-8 text-theme-accent" />
                  <span>Settings</span>
                </h1>
                <p className="text-sm text-theme-muted mt-1 font-sans">Configure your identity, layout appearance preferences, labels, and gateway limits.</p>
              </div>
            </div>
          )}

          <div className="flex flex-col md:flex-row gap-8 items-stretch min-h-[550px]">
            {/* Left Tabs Menu Sidebar */}
            {!isMobile && (
              <aside className="w-full md:w-56 shrink-0 flex flex-row md:flex-col gap-1 border-b md:border-b-0 md:border-r border-theme-border/50 pb-4 md:pb-0 md:pr-4">
                {[
                  { id: 'general', name: 'General', icon: User },
                  { id: 'appearance', name: 'Appearance', icon: Palette },
                  { id: 'labels', name: 'Labels & Folders', icon: Tag },
                  { id: 'shortcuts', name: 'Shortcuts', icon: Keyboard },
                  { id: 'accounts', name: 'Accounts', icon: Server }
                ].map(tab => {
                  const Icon = tab.icon;
                  const active = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex items-center gap-3 px-4 py-2.5 rounded-none text-xs font-bold transition-all text-left cursor-pointer ${
                        active 
                          ? 'bg-theme-accent/8 text-theme-accent border border-theme-accent/20' 
                          : 'text-theme-secondary hover:bg-theme-hover hover:text-theme-primary'
                      }`}
                    >
                       <FontAwesomeIcon icon={Icon} className="h-4.5 w-4.5" />
                      <span>{tab.name}</span>
                    </button>
                  );
                })}
              </aside>
            )}

            {/* Right Active Tab Panel Workspace */}
            <div className="flex-1 min-w-0">
              <form onSubmit={handleSave} className="space-y-6 h-full flex flex-col justify-between">
            <div className="space-y-6">
              
              {/* TAB 1: GENERAL SETTINGS */}
              {activeTab === 'general' && (
                <div className="space-y-6 max-w-2xl animate-fade-in">
                  <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent">Identity Profile</h3>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Full Name</label>
                        <input
                          type="text"
                          required
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          className="w-full px-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Operator Role</label>
                        <input
                          type="text"
                          disabled
                          value={userRole}
                          className="w-full px-4 py-2.5 bg-theme-app border border-theme-border rounded-none text-xs font-semibold text-theme-muted capitalize cursor-not-allowed select-none"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Default Display Sender Name</label>
                      <input
                        type="text"
                        value={defaultSenderName}
                        onChange={(e) => defaultSenderName && setDefaultSenderName(e.target.value)}
                        className="w-full px-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent transition-colors text-theme-primary"
                        placeholder="e.g. ThunderCipher Mailer"
                      />
                    </div>
                  </div>

                  <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent">AI Copilot & Safety cap limits</h3>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Copilot Model</label>
                        <select
                          value={aiModel}
                          onChange={(e) => setAiModel(e.target.value)}
                          className="w-full px-3 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary cursor-pointer"
                        >
                          <option value="gemini-2.5-flash">Gemini 2.5 Flash (Fast, Recommended)</option>
                          <option value="gemini-2.5-pro">Gemini 2.5 Pro (Complex Reasoning)</option>
                          <option value="gemini-3.5-flash">Gemini 3.5 Flash (Frontier Speed)</option>
                          <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro (Frontier Reasoner)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Default Generation Tone</label>
                        <select
                          value={defaultTone}
                          onChange={(e) => setDefaultTone(e.target.value)}
                          className="w-full px-3 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary cursor-pointer"
                        >
                          <option value="professional">Professional</option>
                          <option value="friendly">Friendly</option>
                          <option value="direct">Direct</option>
                          <option value="urgent">Urgent</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Daily Limit Cap (Emails/Day)</label>
                        <input
                          type="number"
                          value={dailyLimit}
                          onChange={(e) => setDailyLimit(e.target.value)}
                          className="w-full px-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Send Delay / Jitter (Seconds)</label>
                        <input
                          type="number"
                          value={sendDelay}
                          onChange={(e) => setSendDelay(e.target.value)}
                          className="w-full px-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent">Notifications Sound effects</h3>
                    
                    <div className="space-y-4 divide-y divide-theme-border/50">
                      <div className="flex items-center justify-between pt-1">
                        <div>
                          <h4 className="text-xs font-bold text-theme-primary">WebSocket Sound Chimes</h4>
                          <p className="text-[10px] text-theme-muted">Plays notification sounds on new incoming messages.</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setEnableSound(!enableSound)}
                          className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-none border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                            enableSound ? 'bg-theme-accent' : 'bg-theme-app border-theme-border'
                          }`}
                        >
                          <span className={`pointer-events-none inline-block h-4 w-4 transform rounded-none bg-white transition duration-200 ease-in-out ${
                            enableSound ? 'translate-x-5' : 'translate-x-0'
                          }`} />
                        </button>
                      </div>

                      <div className="flex items-center justify-between pt-4">
                        <div>
                          <h4 className="text-xs font-bold text-theme-primary">Visual Toast Notifications</h4>
                          <p className="text-[10px] text-theme-muted">Displays real-time message previews on screen corners.</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setEnableToasts(!enableToasts)}
                          className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-none border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                            enableToasts ? 'bg-theme-accent' : 'bg-theme-app border-theme-border'
                          }`}
                        >
                          <span className={`pointer-events-none inline-block h-4 w-4 transform rounded-none bg-white transition duration-200 ease-in-out ${
                            enableToasts ? 'translate-x-5' : 'translate-x-0'
                          }`} />
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent">Discord Webhooks Integration</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Failed Mails Alert Webhook</label>
                        <input
                          type="text"
                          value={failedMailsWebhook}
                          onChange={(e) => setFailedMailsWebhook(e.target.value)}
                          placeholder="https://discord.com/api/webhooks/..."
                          className="w-full px-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">General Activity Log Webhook</label>
                        <input
                          type="text"
                          value={generalMailsWebhook}
                          onChange={(e) => setGeneralMailsWebhook(e.target.value)}
                          placeholder="https://discord.com/api/webhooks/..."
                          className="w-full px-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: APPEARANCE SETTINGS */}
              {activeTab === 'appearance' && (
                <div className="space-y-6 max-w-3xl animate-fade-in">
                  <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent">Theme Mode & Layouts Density</h3>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Visual Mode</label>
                        <div className="flex gap-2 bg-theme-app border border-theme-border rounded-none p-1">
                          {(['light', 'dark', 'system'] as const).map(mode => (
                            <button
                              key={mode}
                              type="button"
                              onClick={() => setTheme(mode)}
                              className={`flex-1 py-1.5 rounded-none text-[10px] font-bold uppercase transition-all cursor-pointer ${
                                theme === mode
                                  ? 'bg-theme-accent text-theme-btnText shadow-sm'
                                  : 'text-theme-muted hover:text-theme-primary'
                              }`}
                            >
                              {mode}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">List Spacing Density</label>
                        <div className="flex gap-2 bg-theme-app border border-theme-border rounded-none p-1">
                          {(['comfortable', 'compact'] as const).map(d => (
                            <button
                              key={d}
                              type="button"
                              onClick={() => setDensity(d)}
                              className={`flex-1 py-1.5 rounded-none text-[10px] font-bold uppercase transition-all cursor-pointer ${
                                density === d
                                  ? 'bg-theme-accent text-theme-btnText shadow-sm'
                                  : 'text-theme-muted hover:text-theme-primary'
                              }`}
                            >
                              {d}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Reading Pane Position</label>
                        <div className="flex gap-2 bg-theme-app border border-theme-border rounded-none p-1">
                          {(['right', 'bottom'] as const).map(pos => (
                            <button
                              key={pos}
                              type="button"
                              onClick={() => setPanePosition(pos)}
                              className={`flex-1 py-1.5 rounded-none text-[10px] font-bold uppercase transition-all cursor-pointer ${
                                panePosition === pos
                                  ? 'bg-theme-accent text-theme-btnText shadow-sm'
                                  : 'text-theme-muted hover:text-theme-primary'
                              }`}
                            >
                              {pos}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent">Mailbox Portal Backdrop</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3">
                      {[
                        { id: 'sunset', name: 'Sunset Glow' },
                        { id: 'aurora', name: 'Aurora' },
                        { id: 'forest', name: 'Forest' },
                        { id: 'ocean', name: 'Deep Ocean' },
                        { id: 'minimal', name: 'Minimal' },
                        { id: 'custom', name: 'Custom Upload' }
                      ].map(bg => (
                        <button
                          key={bg.id}
                          type="button"
                          onClick={() => {
                            if (bg.id === 'custom') {
                              fileInputRef.current?.click();
                            } else {
                              setMailboxBg(bg.id);
                              localStorage.setItem('setting_mailbox_bg', bg.id);
                              window.dispatchEvent(new Event('settings-changed'));
                            }
                          }}
                          className={`p-3 border rounded-none text-center transition-all cursor-pointer ${
                            mailboxBg === bg.id
                              ? 'border-theme-accent bg-theme-accent/5 text-theme-accent font-bold'
                              : 'border-theme-border bg-theme-surface/50 text-theme-secondary hover:bg-theme-hover hover:text-theme-primary'
                          }`}
                        >
                          <div className="text-[10px] font-bold uppercase leading-tight truncate">{bg.name}</div>
                        </button>
                      ))}
                    </div>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleCustomBgUpload}
                      className="hidden"
                    />
                  </div>

                  <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent">Typography font configuration</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Body Font Family</label>
                        <select
                          value={fontBody}
                          onChange={(e) => handleTypographyChange('body', e.target.value)}
                          className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary cursor-pointer"
                        >
                          {['Outfit', 'Inter', 'DM Sans', 'JetBrains Mono', 'Roboto', 'Lora', 'Poppins'].map(f => (
                            <option key={f} value={f}>{f}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Heading Font Family</label>
                        <select
                          value={fontHeading}
                          onChange={(e) => handleTypographyChange('heading', e.target.value)}
                          className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary cursor-pointer"
                        >
                          {['Outfit', 'Inter', 'DM Sans', 'JetBrains Mono', 'Roboto', 'Lora', 'Poppins'].map(f => (
                            <option key={f} value={f}>{f}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Font Base Size</label>
                        <select
                          value={fontSize}
                          onChange={(e) => handleTypographyChange('size', e.target.value)}
                          className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary cursor-pointer"
                        >
                          <option value="small">Small (13px)</option>
                          <option value="medium">Medium (15px)</option>
                          <option value="large">Large (17px)</option>
                          <option value="xlarge">Extra Large (19px)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Font Weight Base</label>
                        <select
                          value={fontWeight}
                          onChange={(e) => handleTypographyChange('weight', e.target.value)}
                          className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary cursor-pointer"
                        >
                          <option value="300">Light (300)</option>
                          <option value="400">Regular (400)</option>
                          <option value="500">Medium (500)</option>
                          <option value="600">Semibold (600)</option>
                          <option value="700">Bold (700)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Letter Spacing</label>
                        <select
                          value={letterSpacing}
                          onChange={(e) => handleTypographyChange('spacing', e.target.value)}
                          className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary cursor-pointer"
                        >
                          <option value="tight">Tight</option>
                          <option value="normal">Normal</option>
                          <option value="wide">Wide</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Line Height</label>
                        <select
                          value={lineHeight}
                          onChange={(e) => handleTypographyChange('leading', e.target.value)}
                          className="w-full px-3 py-2 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary cursor-pointer"
                        >
                          <option value="1.4">Condensed (1.4)</option>
                          <option value="1.6">Comfortable (1.6)</option>
                          <option value="1.8">Loose (1.8)</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: LABELS & FILTERS */}
              {activeTab === 'labels' && (
                <div className="space-y-6 max-w-2xl animate-fade-in">
                  <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent flex items-center gap-2">
                      <FontAwesomeIcon icon={Tag} className="h-4.5 w-4.5 text-role-creative" />
                      <span>Custom Folders & Labels</span>
                    </h3>

                    {/* Create Label Form */}
                    <form onSubmit={handleCreateTag} className="flex flex-col sm:flex-row gap-3.5 items-end bg-theme-app/50 border border-theme-border/60 p-4 rounded-none">
                      <div className="flex-1 w-full">
                        <label className="block text-[10px] font-bold uppercase text-theme-muted mb-1">New Label Name</label>
                        <input
                          type="text"
                          required
                          value={newTagName}
                          onChange={(e) => setNewTagName(e.target.value)}
                          placeholder="e.g. Inquiries, Support"
                          className="w-full px-3.5 py-2 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent text-theme-primary"
                        />
                      </div>
                      
                      <div className="w-full sm:w-auto">
                        <label className="block text-[10px] font-bold uppercase text-theme-muted mb-1">Color Palette</label>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={newTagColor}
                            onChange={(e) => setNewTagColor(e.target.value)}
                            className="w-10 h-9 p-0.5 rounded-none border border-theme-border/60 bg-transparent cursor-pointer shrink-0"
                          />
                          <span className="text-[10px] font-mono font-semibold text-theme-muted uppercase">{newTagColor}</span>
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={creatingTag}
                        className="px-4 py-2.5 bg-theme-accent hover:bg-theme-accentHover text-theme-btnText font-bold rounded-none text-xs transition-all shrink-0 cursor-pointer w-full sm:w-auto"
                      >
                        {creatingTag ? 'Creating...' : 'Add Label'}
                      </button>
                    </form>

                    {/* Labels List */}
                    <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                      {tagsList.length === 0 ? (
                        <div className="text-center py-8 text-theme-muted text-xs font-semibold">
                          No custom labels found. Create your first label above.
                        </div>
                      ) : (
                        tagsList.map(tag => (
                          <div 
                            key={tag.id}
                            className="flex items-center justify-between px-4 py-2.5 bg-theme-app/30 border border-theme-border/40 rounded-none hover:bg-theme-hover transition-colors"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-3.5 h-3.5 rounded-none shrink-0 border border-black/10" style={{ backgroundColor: tag.color }} />
                              <span className="text-xs font-bold text-theme-primary">{tag.name}</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleDeleteTag(tag.id, tag.name)}
                              className="p-1 hover:bg-red-500/10 text-theme-muted hover:text-red-500 rounded-none transition-colors cursor-pointer"
                              title="Delete Label"
                            >
                              <FontAwesomeIcon icon={Trash2} className="h-4 w-4" />
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: KEYBOARD SHORTCUTS CHEATSHEET */}
              {activeTab === 'shortcuts' && (
                <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300 max-w-2xl animate-fade-in">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent flex items-center gap-2">
                    <FontAwesomeIcon icon={Keyboard} className="h-4.5 w-4.5" />
                    <span>Keyboard Navigation Reference</span>
                  </h3>
                  <p className="text-xs text-theme-muted mt-1 leading-relaxed">
                    Improve your dispatch velocity inside the Mailbox portal using these quick shortcut keys. Press <kbd className="px-1.5 py-0.5 border rounded-none bg-theme-app font-mono text-[10px]">?</kbd> anywhere to show this helper.
                  </p>
                  
                  <div className="border border-theme-border rounded-none overflow-hidden mt-3">
                    <table className="w-full text-left text-xs border-collapse">
                      <thead>
                        <tr className="bg-theme-app border-b border-theme-border/80">
                          <th className="px-4 py-2.5 font-bold uppercase tracking-wider text-theme-muted">Action Description</th>
                          <th className="px-4 py-2.5 font-bold uppercase tracking-wider text-theme-muted text-right">Shortcut Keys</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-theme-border/40">
                        {[
                          { action: 'Move active selection down list', keys: ['J'] },
                          { action: 'Move active selection up list', keys: ['K'] },
                          { action: 'Open selected conversation thread', keys: ['Enter'] },
                          { action: 'Mark active selected email as read', keys: ['E'] },
                          { action: 'Delete active selected email', keys: ['#'] },
                          { action: 'Trigger inline reply composer', keys: ['R'] },
                          { action: 'Open floating outreach composer', keys: ['C'] },
                          { action: 'Focus text search query input', keys: ['/'] },
                          { action: 'Toggle this keyboard cheat sheet modal', keys: ['?'] },
                          { action: 'Switch mailbox folder view to Inbox', keys: ['I'] },
                          { action: 'Switch mailbox folder view to Sent', keys: ['S'] },
                          { action: 'Switch mailbox folder view to Scheduled', keys: ['O'] },
                          { action: 'Switch mailbox folder view to Drafts', keys: ['D'] },
                        ].map((s, idx) => (
                          <tr key={idx} className="hover:bg-theme-hover transition-colors">
                            <td className="px-4 py-2.5 font-semibold text-theme-secondary">{s.action}</td>
                            <td className="px-4 py-2.5 text-right">
                              {s.keys.map((k, kIdx) => (
                                <kbd key={kIdx} className="px-2 py-0.5 bg-theme-app text-theme-accent text-[10px] font-mono font-bold rounded-none border border-theme-border uppercase">
                                  {k}
                                </kbd>
                              ))}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 5: ACCOUNTS GATEWAYS */}
              {activeTab === 'accounts' && (
                <div className="space-y-6 max-w-2xl animate-fade-in">
                  <div className="bg-theme-surface border border-theme-border rounded-none p-8 space-y-6 shadow-sm transition-all duration-300">
                    <h3 className="text-sm font-bold uppercase tracking-wider text-theme-accent flex items-center gap-2">
                      <FontAwesomeIcon icon={Server} className="h-4.5 w-4.5" />
                      <span>SMTP/IMAP Gateways</span>
                    </h3>
                    <p className="text-xs text-theme-muted mt-1 leading-relaxed">
                      Below are the active relay servers configured to dispatch campaigns and receive synced replies.
                    </p>

                    <div className="space-y-3 mt-4">
                      {accounts.length === 0 ? (
                        <div className="text-center py-8 text-theme-muted text-xs font-semibold">
                          No SMTP/IMAP configurations setup. Add one on the dedicated portal.
                        </div>
                      ) : (
                        accounts.map(acc => (
                          <div 
                            key={acc.id}
                            className="flex items-center justify-between px-4 py-3.5 bg-theme-app/30 border border-theme-border/40 rounded-none"
                          >
                            <div>
                              <div className="text-xs font-bold text-theme-primary">{acc.name}</div>
                              <div className="text-[10px] text-theme-muted mt-0.5">{acc.username} • {acc.host}:{acc.port}</div>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className={`px-2.5 py-0.5 rounded-none text-[9px] font-bold uppercase border ${
                                acc.is_active 
                                  ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500 dark:text-emerald-400' 
                                  : 'bg-red-500/10 border-red-500/20 text-red-500 dark:text-red-400'
                              }`}>
                                {acc.is_active ? 'Active' : 'Disabled'}
                              </span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>

                    <div className="pt-4 border-t border-theme-border/50 flex justify-end">
                      <button
                        type="button"
                        onClick={() => {
                          window.location.hash = '#/smtp';
                        }}
                        className="px-4 py-2 bg-theme-surface border border-theme-border hover:bg-theme-hover rounded-none text-xs font-bold text-theme-secondary cursor-pointer transition-all flex items-center gap-1.5"
                      >
                        <FontAwesomeIcon icon={SettingsIcon} className="h-4 w-4" />
                        <span>Manage Gateway Settings</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Sticky Save Buttons Footer bar (only for tabs that have form inputs) */}
            {['general', 'appearance'].includes(activeTab) && (
              <div className="pt-6 border-t border-theme-border/50 flex justify-end items-center gap-3">
                {saved && (
                  <span className="text-xs font-bold text-role-signal flex items-center gap-1 animate-pulse">
                    <FontAwesomeIcon icon={Check} className="h-4 w-4" />
                    <span>Settings Updated Successfully!</span>
                  </span>
                )}
                <button
                  type="submit"
                  disabled={loading}
                  className="flex items-center gap-1.5 px-6 py-2.5 bg-black border border-white hover:bg-white hover:text-black text-white font-bold rounded-none text-xs transition-all disabled:opacity-50 cursor-pointer uppercase tracking-wider"
                >
                   <FontAwesomeIcon icon={Save} className="h-4 w-4" />
                  <span>{loading ? 'Saving...' : 'Save Settings'}</span>
                </button>
              </div>
            )}
          </form>
        </div>
      </div>
      </>
    )}
    </div>
  );
}
