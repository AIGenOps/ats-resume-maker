import { useEffect } from 'react';

export interface ShortcutMapping {
  key: string;
  description: string;
  action: () => void;
}

export function useKeyboardShortcuts(shortcuts: ShortcutMapping[]) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      if (activeEl) {
        const tagName = activeEl.tagName.toLowerCase();
        const isEditable = activeEl.getAttribute('contenteditable') === 'true';
        if (
          tagName === 'input' ||
          tagName === 'textarea' ||
          tagName === 'select' ||
          isEditable
        ) {
          if (e.key === 'Escape') {
            (activeEl as HTMLElement).blur();
          }
          return;
        }
      }

      const targetShortcut = shortcuts.find(
        (s) => s.key.toLowerCase() === e.key.toLowerCase()
      );
      if (targetShortcut) {
        e.preventDefault();
        targetShortcut.action();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [shortcuts]);
}
