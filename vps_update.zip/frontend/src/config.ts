// API Base URL config. 
// In development/production, it defaults to resolving the current hostname on port 8000
// unless overridden by VITE_API_BASE_URL.
const getApiBase = (): string => {
  const envUrl = import.meta.env.VITE_API_BASE_URL;
  if (envUrl) {
    return envUrl as string;
  }
  
  if (typeof window !== 'undefined' && window.location) {
    const hostname = window.location.hostname;
    const protocol = window.location.protocol;
    const port = window.location.port;
    
    // Fall back to port 8000 during local development (Vite dev server)
    if (port === '5173' || port === '3000') {
      return `${protocol}//${hostname}:8000`;
    }
    return window.location.origin;
  }
  return '';
};

export const API_BASE = getApiBase();
