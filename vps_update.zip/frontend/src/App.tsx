import { useState, useEffect, lazy, Suspense } from 'react';
import { createPortal } from 'react-dom';
import { API_BASE } from './config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faGauge as LayoutDashboard, faPaperPlane as Send, faUsers as Users, faChartLine as Activity, 
  faFileLines as FileText, faServer as Server, faShieldHalved as Shield, faRightFromBracket as LogOut, 
  faWandMagicSparkles as Sparkles, faEnvelope as Mail, faXmark as X, faKeyboard as Keyboard, faSun as Sun, faMoon as Moon, 
  faGear as Settings, faCaretLeft as CaretLeft, faCaretRight as CaretRight, faMagnifyingGlass as Search,
  faEllipsis as DotsThree, faHouse as House, faPlus as Plus
} from '@fortawesome/free-solid-svg-icons';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import Login from './pages/Login';
import FloatingComposer from './components/FloatingComposer';
import { useTheme } from './contexts/ThemeContext';

// Lazy-loaded pages for Route-Based Code Splitting
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Contacts = lazy(() => import('./pages/Contacts'));
const Templates = lazy(() => import('./pages/Templates'));
const Campaigns = lazy(() => import('./pages/Campaigns'));
const SmtpSettings = lazy(() => import('./pages/SmtpSettings'));
const Logs = lazy(() => import('./pages/Logs'));
const Mailbox = lazy(() => import('./pages/Mailbox'));
const SettingsPage = lazy(() => import('./pages/Settings'));
const Compose = lazy(() => import('./pages/Compose'));

function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [user, setUser] = useState<any>(null);
  const [currentPage, setCurrentPage] = useState<string>('dashboard');
  const { theme, sidebarCollapsed, setSidebarCollapsed } = useTheme();
  const [toast, setToast] = useState<{ show: boolean; contactName: string; subject: string; snippet: string } | null>(null);
  const [showShortcutsHelp, setShowShortcutsHelp] = useState(false);
  const [showCommandBar, setShowCommandBar] = useState(false);
  
  // Overlay Compose states
  const [showFloatingComposer, setShowFloatingComposer] = useState(false);
  const [composerMinimized, setComposerMinimized] = useState(false);
  const [commandQuery, setCommandQuery] = useState('');
  const [focusedCommandIndex, setFocusedCommandIndex] = useState(0);

  // Responsive breakpoint states
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);
  const [showMoreDrawer, setShowMoreDrawer] = useState(false);
  const [showMobileSearch, setShowMobileSearch] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [bgUpdatedKey, setBgUpdatedKey] = useState(0);

  useEffect(() => {
    const handleSettingsChanged = () => {
      setBgUpdatedKey(prev => prev + 1);
    };
    window.addEventListener('settings-changed', handleSettingsChanged);
    return () => window.removeEventListener('settings-changed', handleSettingsChanged);
  }, []);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  const handleNavigate = (page: string) => {
    if (page === 'compose_floating') {
      setShowFloatingComposer(true);
      setComposerMinimized(false);
      return;
    }
    setCurrentPage(page);
    window.location.hash = `#/${page}`;
  };

  const getGlobalMailboxBg = () => {
    if (theme !== 'dark') {
      return 'none';
    }
    const bg = localStorage.getItem('setting_mailbox_bg') || 'sunset';
    const bgMap: Record<string, string> = {
      sunset: '/backgrounds/sunset.jpg',
      aurora: '/backgrounds/aurora.jpg',
      forest: '/backgrounds/forest.jpg',
      ocean: '/backgrounds/ocean.jpg',
      minimal: '/backgrounds/minimal.jpg'
    };
    let imageUrl = bgMap[bg] || bgMap['sunset'];
    if (bg === 'custom') {
      const customData = localStorage.getItem('setting_mailbox_bg_custom');
      if (customData) {
        imageUrl = customData;
      }
    }
    const overlay = 'linear-gradient(to bottom, rgba(9, 13, 22, 0.45), rgba(9, 13, 22, 0.85))';
    return `${overlay}, url('${imageUrl}')`;
  };

  const getThemeClass = (lightClass: string, darkClass: string) => {
    return theme === 'dark' ? darkClass : lightClass;
  };

  useEffect(() => {
    const handleHashChange = () => {
      const path = window.location.hash.substring(2) || 'dashboard';
      const validPages = ['dashboard', 'mailbox', 'compose', 'contacts', 'campaigns', 'templates', 'smtp', 'logs', 'settings'];
      if (validPages.includes(path)) {
        setCurrentPage(path);
      } else {
        window.location.hash = '#/dashboard';
      }
    };

    if (!window.location.hash) {
      window.location.hash = '#/dashboard';
    } else {
      handleHashChange();
    }

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);



  useEffect(() => {
    const body = localStorage.getItem('setting_font_body') || 'DM Sans';
    const heading = localStorage.getItem('setting_font_heading') || 'Cinzel';
    const size = localStorage.getItem('setting_font_size') || 'medium';
    const weight = localStorage.getItem('setting_font_weight') || '400';
    const spacing = localStorage.getItem('setting_font_spacing') || 'normal';
    const leading = localStorage.getItem('setting_font_leading') || '1.6';

    const fontMapping: Record<string, string> = {
      'DM Sans': "'DM Sans', -apple-system, BlinkMacSystemFont, system-ui, sans-serif",
      'Cinzel': "'Cinzel', Georgia, serif",
      'Outfit': "'Outfit', sans-serif",
      'Inter': "'Inter', sans-serif",
      'JetBrains Mono': "'JetBrains Mono', monospace",
      'Playfair Display': "'Playfair Display', serif",
      'Roboto': "'Roboto', sans-serif",
      'Lora': "'Lora', serif",
      'Poppins': "'Poppins', sans-serif"
    };

    const sizeMapping: Record<string, string> = {
      'small': '13px',
      'medium': '15px',
      'large': '17px',
      'xlarge': '19px'
    };

    const spacingMapping: Record<string, string> = {
      'tight': '-0.02em',
      'normal': '-0.01em',
      'wide': '0.04em'
    };

    const root = document.documentElement;
    root.style.setProperty('--font-body', fontMapping[body] || fontMapping['DM Sans']);
    root.style.setProperty('--font-heading', fontMapping[heading] || fontMapping['Cinzel']);
    root.style.setProperty('--font-size-base', sizeMapping[size] || sizeMapping['medium']);
    root.style.setProperty('--font-weight-base', weight);
    root.style.setProperty('--letter-spacing-base', spacingMapping[spacing] || spacingMapping['normal']);
    root.style.setProperty('--line-height-base', leading);
  }, []);

  useEffect(() => {
    if (token) {
      fetchCurrentUser();
    }
  }, [token]);

  // Real-time WebSocket Notifications
  useEffect(() => {
    if (!token) return;

    let ws: WebSocket;
    let reconnectTimeout: any;

    const connectWs = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host = API_BASE.startsWith('http') 
        ? API_BASE.replace('http://', '').replace('https://', '') 
        : window.location.host;
      const wsUrl = `${protocol}//${host}/api/v1/mailbox/ws?token=${encodeURIComponent(token)}`;

      ws = new WebSocket(wsUrl);

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'new_email') {
            setToast({
              show: true,
              contactName: data.contact_name,
              subject: data.subject,
              snippet: data.snippet
            });

            try {
              const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
              const osc = audioCtx.createOscillator();
              const gain = audioCtx.createGain();
              osc.type = 'sine';
              osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
              osc.frequency.setValueAtTime(880.00, audioCtx.currentTime + 0.12);
              gain.gain.setValueAtTime(0.06, audioCtx.currentTime);
              gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.35);
              osc.connect(gain);
              gain.connect(audioCtx.destination);
              osc.start();
              osc.stop(audioCtx.currentTime + 0.35);
            } catch (soundErr) {
              console.warn(soundErr);
            }

            setTimeout(() => {
              setToast(null);
            }, 6000);
          }
        } catch (e) {
          console.error('Error parsing WS event:', e);
        }
      };

      ws.onclose = () => {
        reconnectTimeout = setTimeout(connectWs, 3000);
      };
    };

    connectWs();

    return () => {
      if (ws) {
        ws.onclose = null; // Prevent reconnect scheduling during teardown
        ws.close();
      }
      clearTimeout(reconnectTimeout);
    };
  }, [token]);

  // Keyboard Shortcuts
  useKeyboardShortcuts([
    { key: 'd', description: 'Go to Dashboard', action: () => handleNavigate('dashboard') },
    { key: 'c', description: 'Go to Compose', action: () => handleNavigate('compose') },
    { key: 'm', description: 'Go to Mailbox', action: () => handleNavigate('mailbox') },
    { key: 't', description: 'Go to Templates', action: () => handleNavigate('templates') },
    { key: 's', description: 'Go to SMTP Settings', action: () => handleNavigate('smtp') },
    { key: 'l', description: 'Go to Audit Logs', action: () => handleNavigate('logs') },
    { key: 'g', description: 'Go to Settings', action: () => handleNavigate('settings') },
    { key: '?', description: 'Toggle Shortcuts Help', action: () => setShowShortcutsHelp(prev => !prev) },
  ]);

  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setShowCommandBar(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, []);

  const fetchCurrentUser = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/auth/me`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (response.ok) {
        setUser(data);
      } else {
        handleLogout();
      }
    } catch (e) {
      console.error("Failed to fetch user:", e);
    }
  };

  const handleLoginSuccess = (newToken: string, loggedInUser: any) => {
    localStorage.setItem('token', newToken);
    setToken(newToken);
    setUser(loggedInUser);
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
  };

  if (!token) {
    return (
      <div 
        className="min-h-screen flex flex-col justify-center items-center relative text-theme-primary bg-[#0C0D10]"
        style={{
          background: 'radial-gradient(circle at 15% 20%, rgba(43, 74, 203, 0.15) 0%, transparent 45%), radial-gradient(circle at 85% 80%, rgba(139, 92, 246, 0.1) 0%, transparent 55%), #0C0D10'
        }}
      >
        <Login onLoginSuccess={handleLoginSuccess} />
      </div>
    );
  }

  const navItems = [
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
    { id: 'mailbox', name: 'Mailbox', icon: Mail },
    { id: 'compose', name: 'Compose', icon: Send },
    { id: 'contacts', name: 'Directory', icon: Users },
    { id: 'campaigns', name: 'Campaigns', icon: Activity },
    { id: 'templates', name: 'Templates', icon: FileText },
    { id: 'smtp', name: 'SMTP Gateways', icon: Server },
    { id: 'logs', name: 'Audit Logs', icon: Shield },
    { id: 'settings', name: 'Settings', icon: Settings },
  ];

  const commandList = [
    { title: 'Go to Dashboard', shortcut: 'D', action: () => handleNavigate('dashboard') },
    { title: 'Go to Mailbox Portal', shortcut: 'M', action: () => handleNavigate('mailbox') },
    { title: 'Compose Outreach Email', shortcut: 'C', action: () => handleNavigate('compose') },
    { title: 'Go to Directory', shortcut: 'Shift + C', action: () => handleNavigate('contacts') },
    { title: 'Go to Campaigns', shortcut: 'Shift + A', action: () => handleNavigate('campaigns') },
    { title: 'Go to Email Templates', shortcut: 'T', action: () => handleNavigate('templates') },
    { title: 'Go to SMTP Gateways', shortcut: 'S', action: () => handleNavigate('smtp') },
    { title: 'Go to Audit Logs', shortcut: 'L', action: () => handleNavigate('logs') },
    { title: 'Go to Settings', shortcut: 'G', action: () => handleNavigate('settings') }
  ];

  const filteredCommands = commandList.filter(cmd => 
    cmd.title.toLowerCase().includes(commandQuery.toLowerCase())
  );

  return (
    <>
      <div className="min-h-screen bg-theme-app text-theme-primary flex relative animate-cinematic-reveal">
      
      
      {/* Sidebar */}
      {!isMobile && (
        <aside className={`flex flex-col shrink-0 z-10 h-screen sticky top-0 transition-all duration-300 border-r border-theme-border bg-[#0D0D0D] text-theme-primary ${sidebarCollapsed ? 'w-20' : 'w-64'}`}>
          <div className="shrink-0">
            {/* Logo & Toggle */}
            <div className={`p-5 flex items-center ${sidebarCollapsed ? 'flex-col gap-4' : 'justify-between gap-3'}`}>
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-none shrink-0 bg-theme-accent/10 text-theme-accent">
                  <FontAwesomeIcon icon={Sparkles} className="h-5 w-5" />
                </div>
                {!sidebarCollapsed && (
                  <span className="font-bold text-sm tracking-[0.15em] uppercase text-theme-primary font-display pl-1">
                    TCMail
                  </span>
                )}
              </div>
              <button
                onClick={toggleSidebar}
                className="p-1.5 border border-theme-border rounded-none text-theme-muted hover:text-theme-primary hover:bg-theme-hover transition-colors cursor-pointer"
                title={sidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
              >
                {sidebarCollapsed ? <FontAwesomeIcon icon={CaretRight} className="h-4.5 w-4.5" /> : <FontAwesomeIcon icon={CaretLeft} className="h-4.5 w-4.5" />}
              </button>
            </div>
            <div className="m-stripe-divider" />
          </div>

          {/* Navigation — scrollable */}
          <div className="flex-1 overflow-y-auto min-h-0">
            <nav className="p-4 space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavigate(item.id)}
                    title={sidebarCollapsed ? item.name : undefined}
                    className={`w-full flex items-center rounded-none text-xs font-bold uppercase tracking-wider transition-all duration-200 relative group cursor-pointer ${
                      sidebarCollapsed ? 'justify-center p-3' : 'gap-3.5 px-4 py-3'
                    } ${
                      isActive
                        ? 'bg-theme-accent/8 text-theme-accent border border-theme-accent/20'
                        : 'text-theme-secondary hover:text-theme-primary hover:bg-theme-hover'
                    }`}
                  >
                    <FontAwesomeIcon icon={Icon} className={`h-[18px] w-[18px] shrink-0 transition-transform duration-200 ${isActive ? 'scale-110' : 'group-hover:scale-105'}`} />
                    {!sidebarCollapsed && <span>{item.name}</span>}
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="shrink-0 p-4 space-y-3">
            <div className="m-stripe-divider mb-4" />
            <div className={`flex items-center p-2.5 rounded-none border bg-theme-surface border-theme-border ${sidebarCollapsed ? 'justify-center' : 'gap-3'}`}>
              <div className="h-8 w-8 rounded-none bg-theme-accent text-theme-btnText flex items-center justify-center font-bold text-xs uppercase shrink-0">
                {user?.full_name?.slice(0, 2) || 'OP'}
              </div>
              {!sidebarCollapsed && (
                <div className="min-w-0 flex-1 transition-opacity duration-200">
                  <div className="text-xs font-bold truncate text-theme-primary">{user?.full_name || 'Loading...'}</div>
                  <div className="text-[10px] text-theme-muted truncate capitalize mt-0.5">{user?.role || 'Operator'}</div>
                </div>
              )}
            </div>

            <button
              onClick={handleLogout}
              title={sidebarCollapsed ? 'Sign Out' : undefined}
              className={`w-full flex items-center text-xs font-bold uppercase tracking-wider text-red-500 hover:bg-red-500/10 rounded-none transition-all duration-200 cursor-pointer ${sidebarCollapsed ? 'justify-center p-3' : 'gap-3 px-4 py-2.5'}`}
            >
              <FontAwesomeIcon icon={LogOut} className="h-4 w-4 shrink-0" />
              {!sidebarCollapsed && <span>Sign Out</span>}
            </button>
          </div>
        </aside>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 relative overflow-hidden">
        {/* Glow decoration removed for M industrial design */}
        
        {/* Top Navbar */}
        {isMobile ? null : (
          <header className={`h-14 flex items-center justify-between px-8 shrink-0 sticky top-0 z-30 border-b border-theme-border bg-black/85 text-theme-primary`}>
            <div className="flex items-center gap-3 text-xs font-bold text-theme-muted">
              <span>Portal</span>
              <span className={theme === 'dark' ? 'text-white/20' : 'text-theme-border'}>/</span>
              <span className={`capitalize px-2.5 py-1 rounded-none ${
                theme === 'dark'
                  ? 'text-white font-bold bg-white/10 border border-white/10'
                  : 'text-theme-accent font-bold bg-theme-accent/8'
              }`}>{currentPage}</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowCommandBar(true)}
                className={`flex items-center gap-2 px-3 py-2 border rounded-none transition-all duration-200 text-xs font-semibold ${
                  theme === 'dark'
                    ? 'border-white/10 hover:bg-white/5 text-white/80 hover:text-white'
                    : 'border-theme-border text-theme-muted hover:text-theme-accent hover:border-theme-input hover:bg-theme-app'
                }`}
                title="Search Portal (Ctrl + K)"
              >
                <FontAwesomeIcon icon={Search} className="h-4 w-4" />
                <span className={`hidden sm:inline border px-1.5 py-0.5 rounded-none text-xs font-mono font-bold ${
                  theme === 'dark'
                    ? 'bg-white/5 border-white/10 text-white/50'
                    : 'bg-theme-app border-theme-border/60'
                }`}>Ctrl K</span>
              </button>
              <button
                onClick={() => setShowShortcutsHelp(true)}
                className={`p-2 border rounded-none transition-all duration-200 ${
                  theme === 'dark'
                    ? 'border-white/10 hover:bg-white/5 text-white/80 hover:text-white'
                    : 'border-theme-border text-theme-muted hover:text-theme-accent hover:border-theme-input hover:bg-theme-app'
                }`}
                title="Keyboard Shortcuts"
              >
                <FontAwesomeIcon icon={Keyboard} className="h-4 w-4" />
              </button>
            </div>
          </header>
        )}

        {/* Content */}
        <main className={`flex-1 ${
          currentPage === 'mailbox' 
            ? 'max-w-none w-full p-4 flex flex-col min-h-0 overflow-hidden' 
            : 'overflow-y-auto p-8 max-w-7xl w-full mx-auto'
        } ${isMobile ? 'pb-safe-content px-4 py-6' : ''} relative z-10`}>
          <Suspense fallback={
            <div className="flex-grow flex items-center justify-center min-h-[300px]">
              <div className="flex flex-col items-center gap-3">
                <div className="w-8 h-8 rounded-full border-2 border-theme-accent border-t-transparent animate-spin" />
                <span className="text-xs font-bold font-mono tracking-widest text-theme-accent animate-pulse">HYDRATING PORTAL...</span>
              </div>
            </div>
          }>
            {currentPage === 'dashboard' && <Dashboard token={token} onNavigate={handleNavigate} />}
            {currentPage === 'mailbox' && <Mailbox token={token} onNavigate={handleNavigate} user={user} />}
            {currentPage === 'compose' && <Compose token={token || ''} />}
            {currentPage === 'contacts' && <Contacts token={token} />}
            {currentPage === 'campaigns' && <Campaigns token={token} />}
            {currentPage === 'templates' && <Templates token={token} />}
            {currentPage === 'smtp' && <SmtpSettings token={token} />}
            {currentPage === 'logs' && <Logs token={token} />}
            {currentPage === 'settings' && <SettingsPage token={token} />}
          </Suspense>
        </main>
      </div>

      {/* Floating Overlay Compose Dock */}
      {showFloatingComposer && (
        <FloatingComposer
          token={token || ''}
          onClose={() => setShowFloatingComposer(false)}
          minimized={composerMinimized}
          setMinimized={setComposerMinimized}
          onNavigate={handleNavigate}
        />
      )}

      {/* Toast Notification */}
      {toast && toast.show && (
        <div className="fixed top-5 right-5 z-[9999] max-w-sm w-full bg-theme-surface border border-theme-border rounded-none shadow-2xl backdrop-blur-xl p-4 flex gap-3.5 animate-slide-in relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1.5 h-full bg-theme-accent" />
          <div className="h-10 w-10 rounded-none bg-theme-app flex items-center justify-center font-bold text-theme-accent text-sm font-sans uppercase shrink-0 border border-theme-border">
            {toast.contactName.slice(0, 2)}
          </div>
          <div className="flex-1 min-w-0 pr-4">
            <h4 className="text-sm font-bold text-theme-primary truncate">{toast.contactName}</h4>
            <p className="text-xs font-semibold text-theme-secondary truncate mt-0.5">{toast.subject}</p>
            <p className="text-xs text-theme-muted truncate mt-0.5">{toast.snippet}</p>
          </div>
          <button 
            onClick={() => setToast(null)}
            className="absolute top-3.5 right-3.5 text-theme-muted hover:text-theme-primary transition-colors"
          >
            <FontAwesomeIcon icon={X} className="h-4 w-4" />
          </button>
        </div>
      )}

      {/* Keyboard Shortcuts Modal */}
      {showShortcutsHelp && createPortal(
        <div className="modal-backdrop">
          <div className="modal-content w-full max-w-md bg-theme-surface border border-theme-border rounded-2xl shadow-2xl overflow-hidden p-6 relative">
            <button 
              onClick={() => setShowShortcutsHelp(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg hover:bg-theme-hover transition-colors text-theme-muted"
            >
              <FontAwesomeIcon icon={X} className="h-5 w-5" />
            </button>
            <h3 className="text-lg font-bold font-outfit mb-5 pr-6 text-theme-primary">Keyboard Shortcuts</h3>
            <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
              {[
                { keys: ['D'], desc: 'Dashboard' },
                { keys: ['C'], desc: 'Compose page' },
                { keys: ['M'], desc: 'Mailbox portal' },
                { keys: ['T'], desc: 'Templates' },
                { keys: ['S'], desc: 'SMTP Settings' },
                { keys: ['L'], desc: 'Audit Logs' },
                { keys: ['?'], desc: 'Toggle Shortcuts' },
                { keys: ['R'], desc: 'Reply to thread' },
                { keys: ['Esc'], desc: 'Close / Clear' },
                { keys: ['↑', '↓'], desc: 'Navigate threads' },
              ].map((s, idx) => (
                <div key={idx} className="flex justify-between items-center text-sm py-1.5 border-b border-theme-border last:border-b-0">
                  <span className="text-theme-secondary">{s.desc}</span>
                  <div className="flex gap-1">
                    {s.keys.map((k, kIdx) => (
                      <kbd key={kIdx} className="px-2 py-0.5 bg-theme-app text-theme-accent text-xs font-mono font-bold rounded border border-theme-border uppercase">
                        {k}
                      </kbd>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Global Command Bar Modal */}
      {showCommandBar && createPortal(
        <div 
          className="modal-backdrop !items-start !pt-[15vh]"
          onClick={() => { setShowCommandBar(false); setCommandQuery(''); }}
        >
          <div 
            className="modal-content w-full max-w-xl bg-theme-surface border border-theme-border rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl relative flex flex-col min-h-0 text-left text-theme-primary"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Search Input */}
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-theme-border">
              <FontAwesomeIcon icon={Search} className="h-5 w-5 text-theme-muted shrink-0" />
              <input
                type="text"
                autoFocus
                placeholder="Type a command or search page navigation..."
                value={commandQuery}
                onChange={(e) => {
                  setCommandQuery(e.target.value);
                  setFocusedCommandIndex(0);
                }}
                onKeyDown={(e) => {
                  const itemsCount = filteredCommands.length;
                  if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    setFocusedCommandIndex(prev => (prev + 1) % itemsCount);
                  } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    setFocusedCommandIndex(prev => (prev - 1 + itemsCount) % itemsCount);
                  } else if (e.key === 'Enter') {
                    e.preventDefault();
                    if (itemsCount > 0) {
                      filteredCommands[focusedCommandIndex].action();
                      setShowCommandBar(false);
                      setCommandQuery('');
                    }
                  } else if (e.key === 'Escape') {
                    setShowCommandBar(false);
                    setCommandQuery('');
                  }
                }}
                className="w-full bg-transparent border-none text-theme-primary text-sm focus:outline-none focus:ring-0 placeholder-theme-muted"
              />
              <span className="text-xs text-theme-muted font-mono font-bold bg-theme-app border border-theme-border px-1.5 py-0.5 rounded">ESC</span>
            </div>

            {/* Commands List */}
            <div className="max-h-[300px] overflow-y-auto p-2 space-y-1">
              {filteredCommands.length === 0 ? (
                <div className="p-4 text-center text-sm text-theme-muted">
                  No matching commands found.
                </div>
              ) : (
                filteredCommands.map((cmd, idx) => {
                  const isFocused = focusedCommandIndex === idx;
                  return (
                    <button
                      key={idx}
                      onClick={() => {
                        cmd.action();
                        setShowCommandBar(false);
                        setCommandQuery('');
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-semibold transition-all text-left ${
                        isFocused 
                          ? 'bg-theme-accent text-theme-btnText' 
                          : 'text-theme-secondary hover:bg-theme-hover'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span className="capitalize">{cmd.title}</span>
                      </div>
                      <kbd className={`px-2 py-0.5 text-xs font-mono rounded border ${
                        isFocused 
                          ? 'bg-theme-accentHover border-theme-border text-theme-btnText' 
                          : 'bg-theme-app border-theme-border text-theme-muted'
                      }`}>
                        {cmd.shortcut}
                      </kbd>
                    </button>
                  );
                })
              )}
            </div>

            {/* Modal Footer Help */}
            <div className="p-3 bg-theme-app/50 border-t border-theme-border flex justify-between items-center text-xs text-theme-muted font-medium">
              <span>Use <kbd className="font-mono bg-theme-hover px-1 rounded">↑↓</kbd> to navigate, <kbd className="font-mono bg-theme-hover px-1 rounded">Enter</kbd> to select</span>
              <span>Search Portal</span>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Mobile Bottom Tab Navigation */}
      {isMobile && createPortal(
        <div className="fixed bottom-0 left-0 right-0 h-16 bg-[#000000]/80 backdrop-blur-xl border-t border-[#202226]/50 flex items-center justify-around z-40 px-4 pb-safe mobile-bottom-nav">
          <button
            onClick={() => {
              handleNavigate('dashboard');
              setShowMoreDrawer(false);
            }}
            className={`flex flex-col items-center justify-center gap-1 min-w-[44px] min-h-[44px] cursor-pointer transition-colors ${currentPage === 'dashboard' && !showMoreDrawer ? 'text-theme-accent font-bold' : 'text-theme-muted hover:text-theme-primary'}`}
          >
            <FontAwesomeIcon icon={House} className="h-5.5 w-5.5" />
            <span className="text-[9px] font-bold tracking-wide">Dashboard</span>
          </button>

          <button
            onClick={() => {
              handleNavigate('mailbox');
              setShowMoreDrawer(false);
            }}
            className={`flex flex-col items-center justify-center gap-1 min-w-[44px] min-h-[44px] cursor-pointer transition-colors ${currentPage === 'mailbox' && !showMoreDrawer ? 'text-theme-accent font-bold' : 'text-theme-muted hover:text-theme-primary'}`}
          >
            <FontAwesomeIcon icon={Mail} className="h-5.5 w-5.5" />
            <span className="text-[9px] font-bold tracking-wide">Inbox</span>
          </button>

          {/* Compose raised FAB slot */}
          <div className="relative -top-4">
            <button
              onClick={() => {
                handleNavigate('compose');
                setShowMoreDrawer(false);
              }}
              className="h-12 w-12 rounded-full bg-theme-accent text-theme-btnText flex items-center justify-center shadow-[0_4px_16px_rgba(var(--accent-rgb),0.3)] cursor-pointer active:scale-95 transition-transform"
              style={{ minWidth: '48px', minHeight: '48px', borderRadius: '9999px' }}
            >
              <FontAwesomeIcon icon={Plus} className="h-6 w-6 text-black" />
            </button>
          </div>

          <button
            onClick={() => {
              handleNavigate('contacts');
              setShowMoreDrawer(false);
            }}
            className={`flex flex-col items-center justify-center gap-1 min-w-[44px] min-h-[44px] cursor-pointer transition-colors ${currentPage === 'contacts' && !showMoreDrawer ? 'text-theme-accent font-bold' : 'text-theme-muted hover:text-theme-primary'}`}
          >
            <FontAwesomeIcon icon={Users} className="h-5.5 w-5.5" />
            <span className="text-[9px] font-bold tracking-wide">Directory</span>
          </button>

          <button
            onClick={() => setShowMoreDrawer(true)}
            className={`flex flex-col items-center justify-center gap-1 min-w-[44px] min-h-[44px] cursor-pointer transition-colors ${showMoreDrawer ? 'text-theme-accent font-bold' : 'text-theme-muted hover:text-theme-primary'}`}
          >
            <FontAwesomeIcon icon={DotsThree} className="h-5.5 w-5.5" />
            <span className="text-[9px] font-bold tracking-wide">More</span>
          </button>
        </div>,
        document.body
      )}

      {/* Mobile More Bottom Sheet Drawer */}
      {isMobile && showMoreDrawer && createPortal(
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[200] flex flex-col justify-end animate-fade-in"
          onClick={() => setShowMoreDrawer(false)}
        >
          <div 
            className="bg-[#0A0B0D] border-t border-theme-border rounded-t-2xl p-6 pb-safe space-y-4 max-h-[85vh] flex flex-col overflow-y-auto animate-slide-up"
            onClick={(e) => e.stopPropagation()}
            style={{ borderTopLeftRadius: '16px', borderTopRightRadius: '16px' }}
          >
            <div className="flex justify-between items-center pb-2 border-b border-[#202226]/50">
              <span className="text-xs font-bold uppercase tracking-wider text-theme-muted font-heading">More Hub</span>
              <button 
                onClick={() => setShowMoreDrawer(false)}
                className="p-1 text-theme-muted hover:text-theme-primary cursor-pointer"
              >
                <FontAwesomeIcon icon={X} className="h-5 w-5" />
              </button>
            </div>

            <div className="space-y-2 pt-2">
              {[
                { id: 'campaigns', name: 'Campaigns', icon: Activity, desc: 'Manage outreach schedules and buffers' },
                { id: 'templates', name: 'Templates', icon: FileText, desc: 'Design and reuse email layouts' },
                { id: 'smtp', name: 'SMTP Gateways', icon: Server, desc: 'Configure outgoing mail servers' },
                { id: 'logs', name: 'Audit Logs', icon: Shield, desc: 'Inspect system events and safety trails' },
                { id: 'settings', name: 'Settings', icon: Settings, desc: 'Profile identity and design settings' }
              ].map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      handleNavigate(item.id);
                      setShowMoreDrawer(false);
                    }}
                    className={`w-full flex items-center justify-between p-3.5 rounded-xl border text-left transition-colors cursor-pointer ${
                      isActive 
                        ? 'bg-theme-accent/8 border-theme-accent text-theme-accent font-bold' 
                        : 'bg-[#121316] border-[#202226]/40 text-theme-secondary hover:text-theme-primary'
                    }`}
                    style={{ borderRadius: '16px' }}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`p-2 rounded-lg ${isActive ? 'bg-theme-accent/10' : 'bg-[#1F2025]'}`}>
                        <FontAwesomeIcon icon={Icon} className="h-5 w-5 shrink-0" />
                      </div>
                      <div>
                        <div className="text-sm font-bold">{item.name}</div>
                        <div className="text-xs text-theme-muted font-medium mt-0.5">{item.desc}</div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="pt-4 border-t border-[#202226]/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-8 w-8 rounded-full bg-theme-accent text-theme-btnText flex items-center justify-center font-bold text-xs uppercase select-none">
                  {user?.full_name?.slice(0, 2) || 'OP'}
                </div>
                <div>
                  <div className="text-xs font-bold text-white">{user?.full_name || 'Operator'}</div>
                  <div className="text-[10px] text-theme-muted capitalize">{user?.role || 'Operator'}</div>
                </div>
              </div>
              <button
                onClick={() => {
                  handleLogout();
                  setShowMoreDrawer(false);
                }}
                className="flex items-center gap-2 px-4 py-2 border border-red-500/20 text-red-500 rounded-none text-xs font-bold uppercase tracking-wider bg-red-500/5 hover:bg-red-500/10 transition-colors cursor-pointer"
              >
                <FontAwesomeIcon icon={LogOut} className="h-4 w-4" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Mobile Fullscreen Search Overlay */}
      {isMobile && showMobileSearch && createPortal(
        <div className="fixed inset-0 bg-[#07080a] z-[9999] flex flex-col p-6 pb-safe animate-fade-in">
          <div className="flex items-center gap-3 pb-4 border-b border-theme-border">
            <FontAwesomeIcon icon={Search} className="h-5 w-5 text-theme-muted shrink-0" />
            <input
              type="text"
              autoFocus
              placeholder="Search page navigation..."
              value={commandQuery}
              onChange={(e) => setCommandQuery(e.target.value)}
              className="flex-1 bg-transparent border-none text-theme-primary text-base focus:outline-none focus:ring-0 placeholder-theme-muted"
            />
            <button 
              onClick={() => {
                setShowMobileSearch(false);
                setCommandQuery('');
              }}
              className="p-1 text-theme-muted hover:text-theme-primary cursor-pointer min-w-[44px] min-h-[44px] flex items-center justify-center"
            >
              <FontAwesomeIcon icon={X} className="h-6 w-6" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto pt-4 space-y-2">
            {filteredCommands.length === 0 ? (
              <div className="p-8 text-center text-sm text-theme-muted">
                No matches found.
              </div>
            ) : (
              filteredCommands.map((cmd, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    cmd.action();
                    setShowMobileSearch(false);
                    setCommandQuery('');
                  }}
                  className="w-full flex items-center justify-between p-4 rounded-xl bg-theme-surface border border-theme-border text-left text-sm font-bold uppercase tracking-wider text-theme-primary cursor-pointer hover:border-theme-accent transition-colors"
                >
                  <span>{cmd.title}</span>
                </button>
              ))
            )}
          </div>
        </div>,
        document.body
      )}
    </div>
    </>
  );
}

export default App;
