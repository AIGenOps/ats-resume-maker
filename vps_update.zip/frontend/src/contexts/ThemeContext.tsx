import React, { createContext, useContext, useState, useEffect } from 'react';

export type ThemeMode = 'light' | 'dark' | 'system';
export type AccentColor = 'blue' | 'green' | 'purple';
export type DensitySetting = 'comfortable' | 'compact';
export type PanePositionSetting = 'right' | 'bottom';

interface ThemeContextType {
  theme: ThemeMode;
  accent: AccentColor;
  density: DensitySetting;
  panePosition: PanePositionSetting;
  sidebarCollapsed: boolean;
  setTheme: (theme: ThemeMode) => void;
  setAccent: (accent: AccentColor) => void;
  setDensity: (density: DensitySetting) => void;
  setPanePosition: (position: PanePositionSetting) => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    return (localStorage.getItem('theme') as ThemeMode) || 'dark';
  });
  const [accent, setAccentState] = useState<AccentColor>(() => {
    return (localStorage.getItem('accent') as AccentColor) || 'blue';
  });
  const [density, setDensityState] = useState<DensitySetting>(() => {
    return (localStorage.getItem('density') as DensitySetting) || 'comfortable';
  });
  const [panePosition, setPanePositionState] = useState<PanePositionSetting>(() => {
    return (localStorage.getItem('panePosition') as PanePositionSetting) || 'right';
  });
  const [sidebarCollapsed, setSidebarCollapsedState] = useState<boolean>(() => {
    return localStorage.getItem('sidebarCollapsed') === 'true';
  });

  const setTheme = (t: ThemeMode) => {
    setThemeState(t);
    localStorage.setItem('theme', t);
  };

  const setAccent = (a: AccentColor) => {
    setAccentState(a);
    localStorage.setItem('accent', a);
  };

  const setDensity = (d: DensitySetting) => {
    setDensityState(d);
    localStorage.setItem('density', d);
  };

  const setPanePosition = (p: PanePositionSetting) => {
    setPanePositionState(p);
    localStorage.setItem('panePosition', p);
  };

  const setSidebarCollapsed = (c: boolean) => {
    setSidebarCollapsedState(c);
    localStorage.setItem('sidebarCollapsed', String(c));
  };

  useEffect(() => {
    const root = window.document.documentElement;

    // 1. Handle Light/Dark/System Theme Mode
    const applyTheme = () => {
      root.classList.remove('light', 'dark');
      if (theme === 'system') {
        const systemIsDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        root.classList.add(systemIsDark ? 'dark' : 'light');
      } else {
        root.classList.add(theme);
      }
    };

    applyTheme();

    // Listen for system theme changes if mode is 'system'
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleSystemThemeChange = () => {
      if (theme === 'system') applyTheme();
    };

    mediaQuery.addEventListener('change', handleSystemThemeChange);

    // 2. Handle Accent Color attributes
    root.setAttribute('data-accent', accent);

    // 3. Handle Layout Density attributes
    root.setAttribute('data-density', density);

    return () => {
      mediaQuery.removeEventListener('change', handleSystemThemeChange);
    };
  }, [theme, accent, density]);

  return (
    <ThemeContext.Provider value={{
      theme,
      accent,
      density,
      panePosition,
      sidebarCollapsed,
      setTheme,
      setAccent,
      setDensity,
      setPanePosition,
      setSidebarCollapsed
    }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
