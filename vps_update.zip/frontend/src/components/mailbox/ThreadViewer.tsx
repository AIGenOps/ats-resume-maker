import React, { useState, useEffect } from 'react';
import DOMPurify from 'dompurify';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faRotate as RefreshCw, faTag as Tag, faReply as CornerUpLeft, 
  faPaperPlane as Send, faWandMagicSparkles as Sparkles, faTrashCan as Trash2, 
  faEnvelopeOpen as MailOpen, faEnvelope as Mail, faShare as CornerUpRight 
} from '@fortawesome/free-solid-svg-icons';
import RichTextEditor from '../RichTextEditor';
import AiCopilotDrawer from './AiCopilotDrawer';
import { useToast } from '../../contexts/ToastContext';
import { API_BASE } from '../../config';


interface TagItem {
  id: string;
  name: string;
  color: string;
}

interface MessageItem {
  id: string;
  sender: string;
  recipient: string;
  subject: string;
  body: string;
  is_incoming: boolean;
  created_at: string;
  sender_name?: string;
}

interface ThreadViewerProps {
  activeFolder: 'inbox' | 'sent' | 'scheduled' | 'drafts';
  selectedItemId: string;
  selectedItemData: any;
  messages: MessageItem[];
  loadingThread: boolean;
  token: string;
  tags: TagItem[];
  onBack: () => void;
  showReplyBox: boolean;
  setShowReplyBox: (show: boolean) => void;
  replyBody: string;
  setReplyBody: (body: string) => void;
  sendingReply: boolean;
  handleSendReply: () => void;
  showCopilotBar: boolean;
  setShowCopilotBar: React.Dispatch<React.SetStateAction<boolean>>;
  copilotPrompt: string;
  setCopilotPrompt: (prompt: string) => void;
  copilotTone: string;
  setCopilotTone: (tone: string) => void;
  copilotModel: string;
  handleAssignTag: (convId: string, tagId: string) => void;
  handleUnassignTag: (convId: string, tagId: string) => void;
  assigningTagItemId: string | null;
  setAssigningTagItemId: React.Dispatch<React.SetStateAction<string | null>>;
  getActiveAccountName: () => string;
  onRefresh?: () => void;
}

export default function ThreadViewer({
  activeFolder,
  selectedItemId,
  selectedItemData,
  messages,
  loadingThread,
  token,
  tags,
  onBack,
  showReplyBox,
  setShowReplyBox,
  replyBody,
  setReplyBody,
  sendingReply,
  handleSendReply,
  showCopilotBar,
  setShowCopilotBar,
  copilotPrompt,
  setCopilotPrompt,
  copilotTone,
  setCopilotTone,
  copilotModel,
  handleAssignTag,
  handleUnassignTag,
  assigningTagItemId,
  setAssigningTagItemId,
  getActiveAccountName,
  onRefresh,
}: ThreadViewerProps) {
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const formatTime = (dateStr: string) => {
    if (!dateStr) return '';
    try {
      const date = new Date(dateStr);
      return date.toLocaleDateString('en-IN', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    } catch (e) {
      return '';
    }
  };

  const removeUnsubscribeFooter = (html: string): string => {
    if (!html) return '';
    // Strip standard hr + unsubscribe paragraph
    const pattern = /<hr[^>]*>\s*<p[^>]*>If you no longer wish to receive these communications,.*?<\/p>/gi;
    let cleaned = html.replace(pattern, '');
    
    // Catch generic unsubscribe paragraph
    const generalPattern = /<p[^>]*>If you no longer wish to receive these communications,.*?<\/p>/gi;
    cleaned = cleaned.replace(generalPattern, '');

    // Clean trailing break tags
    cleaned = cleaned.replace(/(?:<br\s*\/?>\s*){2,}\s*$/gi, '');
    return cleaned.trim();
  };

  const { addToast } = useToast();

  const [expandedMessageIds, setExpandedMessageIds] = React.useState<string[]>([]);

  // Automatically expand the latest message on messages load
  React.useEffect(() => {
    if (messages && messages.length > 0) {
      const latestMsgId = messages[messages.length - 1].id;
      setExpandedMessageIds([latestMsgId]);
    }
  }, [messages]);

  const toggleMessageExpanded = (msgId: string) => {
    setExpandedMessageIds(prev => 
      prev.includes(msgId) ? prev.filter(id => id !== msgId) : [...prev, msgId]
    );
  };

  React.useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowReplyBox(false);
        setShowCopilotBar(false);
      }
    };
    if (showReplyBox || showCopilotBar) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => window.removeEventListener('keydown', handleEsc);
  }, [showReplyBox, showCopilotBar]);

  const getThreadContactInfo = () => {
    try {
      let email = selectedItemData?.contact_email || '';
      let name = selectedItemData?.contact_name || '';

      if (activeFolder !== 'inbox') {
        const sentEmail = selectedItemData?.recipient_email || selectedItemData?.recipients?.join(', ') || 'unknown@unknown.com';
        const parts = sentEmail.split('@');
        const sentName = parts[0] ? parts[0].charAt(0).toUpperCase() + parts[0].slice(1) : 'Unknown Recipient';
        return { email: sentEmail, name: sentName };
      }

      if (!email || email === 'unknown@unknown.com') {
        const incoming = (messages || []).find(m => m && m.is_incoming);
        if (incoming && incoming.sender) {
          email = incoming.sender;
        } else if (messages && messages.length > 0 && messages[0] && messages[0].sender) {
          email = messages[0].sender;
        } else {
          email = 'unknown@unknown.com';
        }
      }

      if (!name || name === 'Unknown Contact') {
        if (email && email !== 'unknown@unknown.com') {
          const parts = email.split('@');
          const prefix = parts[0] ? parts[0].split('.')[0] : 'unknown';
          name = prefix.charAt(0).toUpperCase() + prefix.slice(1);
        } else {
          name = 'Unknown Contact';
        }
      }

      return { email, name };
    } catch (e) {
      console.error("Error in getThreadContactInfo fallback:", e);
      return { email: 'unknown@unknown.com', name: 'Unknown Contact' };
    }
  };

  const handleMarkRead = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${selectedItemId}/read`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        addToast("Marked as read successfully!", "success");
        if (onRefresh) onRefresh();
      } else {
        addToast("Failed to mark as read", "error");
      }
    } catch (e) {
      console.error(e);
      addToast("Error marking thread as read", "error");
    }
  };

  const handleMarkUnread = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${selectedItemId}/unread`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        addToast("Marked as unread successfully!", "success");
        if (onRefresh) onRefresh();
        onBack();
      } else {
        addToast("Failed to mark as unread", "error");
      }
    } catch (e) {
      console.error(e);
      addToast("Error marking thread as unread", "error");
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Are you sure you want to permanently delete this conversation and all associated messages?")) return;
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/conversations/${selectedItemId}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        addToast("Conversation deleted successfully!", "success");
        if (onRefresh) onRefresh();
        onBack();
      } else {
        addToast("Failed to delete conversation", "error");
      }
    } catch (e) {
      console.error(e);
      addToast("Error deleting conversation", "error");
    }
  };

  const handleReplyToggle = () => {
    setShowReplyBox(true);
    setTimeout(() => {
      const replyEl = document.getElementById('reply-composer-area');
      if (replyEl) {
        replyEl.scrollIntoView({ behavior: 'smooth' });
        const editor = replyEl.querySelector('[contenteditable="true"]') as HTMLElement;
        if (editor) editor.focus();
      }
    }, 150);
  };

  const handleForward = () => {
    const formattedMessages = messages.map(m => `
      <div style="border-left: 2px solid #1C69D4; padding-left: 12px; margin-top: 15px; color: #8a93a6;">
        <p><b>From:</b> ${m.sender}</p>
        <p><b>To:</b> ${m.recipient}</p>
        <p><b>Date:</b> ${new Date(m.created_at).toLocaleString()}</p>
        <p><b>Subject:</b> ${m.subject}</p>
        <div style="margin-top: 10px; color: #ffffff;">${m.body}</div>
      </div>
    `).join('<br/>');

    sessionStorage.setItem('compose_prepopulated', JSON.stringify({
      subject: `Fwd: ${selectedItemData?.subject || ''}`,
      body: `<p>Begin forwarded message:</p>${formattedMessages}`
    }));
    window.location.hash = '#/compose';
  };

  const stripHtmlTags = (html: string): string => {
    if (!html) return '';
    return html
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  const renderFormattedBody = (body: string) => {
    if (!body) return { __html: '' };

    // Safely resolve DOMPurify at runtime to handle bundler differences
    let cleanHtml = '';
    let sanitizationSuccess = false;
    try {
      const purifier = (DOMPurify as any).default || DOMPurify;
      if (purifier && typeof purifier.sanitize === 'function') {
        cleanHtml = purifier.sanitize(body);
        sanitizationSuccess = true;
      }
    } catch (e) {
      console.warn("DOMPurify sanitization failed, stripping HTML tags as fallback:", e);
    }

    const isHtml = /<[a-z][\s\S]*>/i.test(body);
    if (isHtml) {
      if (sanitizationSuccess) {
        return { __html: cleanHtml };
      } else {
        // Fallback: strip tags and convert to formatted plain text
        const plainText = stripHtmlTags(body);
        const formatted = plainText
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/\n/g, '<br />');
        return { __html: formatted };
      }
    } else {
      const formatted = body
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\n/g, '<br />');

      let cleanFormatted = formatted;
      try {
        const purifier = (DOMPurify as any).default || DOMPurify;
        if (purifier && typeof purifier.sanitize === 'function') {
          cleanFormatted = purifier.sanitize(formatted);
        }
      } catch (err) {
        // fallback
      }
      return { __html: cleanFormatted };
    }
  };

  return (
    <div className="flex-grow flex flex-col h-full min-h-0 overflow-hidden bg-theme-app/30">
      {/* Back & Actions Header Bar */}
      <div className="p-4 border-b border-theme-border flex justify-between items-center bg-theme-surface/50 flex-shrink-0">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-theme-primary transition-colors cursor-pointer"
            title="Back to inbox"
          >
            <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
          </button>

          <div className="h-6 w-px bg-theme-border" />

          {/* Modern Responsive Email Toolbar */}
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={handleReplyToggle}
              className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-theme-primary transition-colors cursor-pointer flex items-center justify-center"
              title="Reply"
            >
              <FontAwesomeIcon icon={CornerUpLeft} className="h-4.5 w-4.5" />
            </button>

            <button
              onClick={handleForward}
              className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-theme-primary transition-colors cursor-pointer flex items-center justify-center"
              title="Forward"
            >
              <FontAwesomeIcon icon={CornerUpRight} className="h-4.5 w-4.5" />
            </button>

            {activeFolder === 'inbox' && (
              <>
                <button
                  onClick={handleMarkRead}
                  className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-theme-primary transition-colors cursor-pointer flex items-center justify-center"
                  title="Mark as Read"
                >
                  <FontAwesomeIcon icon={MailOpen} className="h-4.5 w-4.5" />
                </button>

                <button
                  onClick={handleMarkUnread}
                  className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-theme-primary transition-colors cursor-pointer flex items-center justify-center"
                  title="Mark as Unread"
                >
                  <FontAwesomeIcon icon={Mail} className="h-4.5 w-4.5" />
                </button>

                <button
                  onClick={handleDelete}
                  className="p-2 hover:bg-theme-hover border border-theme-border rounded-none text-theme-secondary hover:text-red-500 hover:border-red-555/30 transition-colors cursor-pointer flex items-center justify-center"
                  title="Delete Conversation"
                >
                  <FontAwesomeIcon icon={Trash2} className="h-4.5 w-4.5" />
                </button>
              </>
            )}
          </div>

          <div className="h-6 w-px bg-theme-border" />

          {/* Assign Tag Dropdown Toggle */}
          {activeFolder === 'inbox' && (
            <div className="relative">
              <button
                onClick={() => setAssigningTagItemId(prev => prev === selectedItemId ? null : selectedItemId)}
                className="px-3.5 py-1.5 border border-theme-border hover:bg-theme-hover rounded-none text-theme-secondary hover:text-theme-primary transition-colors flex items-center gap-1.5 text-xs font-semibold"
                title="Add Label"
              >
                <FontAwesomeIcon icon={Tag} className="h-3.5 w-3.5" />
                <span>Label</span>
              </button>
              
              {assigningTagItemId === selectedItemId && (
                isMobile ? (
                  <>
                    <div 
                      className="fixed inset-0 bg-black/60 z-[10000] backdrop-blur-sm"
                      onClick={() => setAssigningTagItemId(null)}
                    />
                    <div className="fixed bottom-0 left-0 right-0 z-[10001] bg-theme-surface border-t border-theme-border p-5 rounded-t-xl space-y-4 max-h-[60vh] overflow-y-auto animate-slide-up text-left pb-10">
                      <div className="flex justify-between items-center pb-2 border-b border-theme-border/50">
                        <span className="text-xs font-bold uppercase tracking-wider text-theme-accent">Apply Label</span>
                        <button 
                          onClick={() => setAssigningTagItemId(null)}
                          className="px-3 py-1.5 border border-theme-border bg-theme-surface rounded-none hover:bg-theme-app text-xs font-semibold text-theme-secondary"
                        >
                          Close
                        </button>
                      </div>
                      <div className="space-y-1">
                        {tags.length === 0 ? (
                          <p className="text-xs text-theme-muted py-2 text-center">No custom labels found.</p>
                        ) : (
                          tags.map(t => {
                            const isAssigned = selectedItemData?.tags?.some((assigned: any) => assigned.id === t.id);
                            return (
                              <button
                                key={t.id}
                                onClick={() => {
                                  if (isAssigned) {
                                    handleUnassignTag(selectedItemId, t.id);
                                  } else {
                                    handleAssignTag(selectedItemId, t.id);
                                  }
                                }}
                                className={`w-full flex items-center justify-between p-3.5 rounded-none text-xs font-semibold hover:bg-theme-hover transition-colors ${
                                  isAssigned ? 'text-theme-accent bg-theme-accent/10 font-bold' : 'text-theme-secondary'
                                }`}
                              >
                                <div className="flex items-center gap-2">
                                  <div className="w-2.5 h-2.5 rounded-none" style={{ backgroundColor: t.color }} />
                                  <span>{t.name}</span>
                                </div>
                                {isAssigned && <span className="text-xs">✓</span>}
                              </button>
                            );
                          })
                        )}
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="absolute left-0 mt-2 z-50 w-48 bg-theme-surface border border-theme-border rounded-none shadow-2xl p-2.5 space-y-1.5 animate-fade-in text-left">
                    <p className="text-xs font-bold uppercase text-theme-muted px-2 mb-1">
                      Apply Label
                    </p>
                    {tags.length === 0 ? (
                      <p className="text-xs text-theme-muted px-2 py-1">No custom labels found.</p>
                    ) : (
                      tags.map(t => {
                        const isAssigned = selectedItemData?.tags?.some((assigned: any) => assigned.id === t.id);
                        return (
                          <button
                            key={t.id}
                            onClick={() => {
                              if (isAssigned) {
                                handleUnassignTag(selectedItemId, t.id);
                              } else {
                                handleAssignTag(selectedItemId, t.id);
                              }
                            }}
                            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-none text-xs font-semibold hover:bg-theme-hover transition-colors ${
                              isAssigned ? 'text-theme-accent bg-theme-accent/10 font-bold' : 'text-theme-secondary'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <div className="w-2.5 h-2.5 rounded-none" style={{ backgroundColor: t.color }} />
                              <span>{t.name}</span>
                            </div>
                            {isAssigned && <span className="text-xs">✓</span>}
                          </button>
                        );
                      })
                    )}
                  </div>
                )
              )}
            </div>
          )}

          {/* Active Tags rendering */}
          {activeFolder === 'inbox' && selectedItemData?.tags && (
            <div className="flex flex-wrap gap-1.5">
              {selectedItemData.tags.map((t: TagItem) => (
                <span 
                  key={t.id}
                  className="flex items-center gap-1.5 text-[10px] px-2.5 py-0.5 rounded-none font-bold border uppercase tracking-wider shadow-none"
                  style={{ backgroundColor: `${t.color}15`, color: t.color, borderColor: `${t.color}25` }}
                >
                  <span>{t.name}</span>
                  <button
                    onClick={() => handleUnassignTag(selectedItemId, t.id)}
                    className="hover:text-red-500 ml-1 font-bold text-xs cursor-pointer"
                    title="Remove label"
                  >
                    &times;
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>

        <div className="text-xs font-semibold text-theme-muted">
          {getThreadContactInfo().name}
        </div>
      </div>

      {/* Thread Info Banner */}
      <div className="px-6 py-5 border-b border-theme-border flex flex-col gap-2 bg-theme-surface/30">
        <h2 className="text-xl font-bold font-outfit text-theme-primary">
          {selectedItemData?.subject || '(No Subject)'}
        </h2>
        <div className="flex items-center gap-1.5 text-xs text-theme-secondary">
          <span className="font-semibold text-theme-primary">
            {getThreadContactInfo().name}
          </span>
          <span className="text-theme-muted">&lt;{getThreadContactInfo().email}&gt;</span>
        </div>
      </div>

      {/* Thread Message List scroll area */}
      <div className="flex-grow overflow-y-auto p-6 space-y-6">
        {activeFolder === 'inbox' && loadingThread ? (
          <div className="space-y-6 animate-pulse">
            {[...Array(3)].map((_, idx) => {
              const isIncoming = idx % 2 === 0;
              return (
                <div key={idx} className={`flex flex-col max-w-[75%] ${isIncoming ? 'mr-auto items-start' : 'ml-auto items-end'}`}>
                  {/* Sender details */}
                  <div className="flex items-center gap-2 mb-1.5">
                    <div className="h-3 bg-theme-border rounded w-16" />
                    <div className="h-2.5 bg-theme-border/60 rounded w-10" />
                  </div>

                  {/* Message box */}
                  <div
                    className={`p-5 rounded-none border border-theme-border w-64 sm:w-96 ${
                      isIncoming
                        ? 'bg-theme-surface text-theme-primary'
                        : 'bg-theme-accent/25 text-theme-primary'
                    }`}
                  >
                    <div className="space-y-2">
                      <div className="h-3 bg-theme-border rounded-none w-full" />
                      <div className="h-3 bg-theme-border rounded-none w-5/6" />
                      <div className="h-3 bg-theme-border/50 rounded-none w-2/3" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : activeFolder === 'inbox' ? (
          messages.map((msg, index) => {
            const isIncoming = msg.is_incoming;
            const isLatest = index === messages.length - 1;
            const isExpanded = expandedMessageIds.includes(msg.id) || isLatest;

            if (!isExpanded) {
              return (
                <div
                  key={msg.id}
                  onClick={() => toggleMessageExpanded(msg.id)}
                  className={`w-full flex items-center justify-between px-5 py-3 border border-theme-border/60 bg-theme-surface/40 hover:bg-theme-hover cursor-pointer transition-colors shadow-none text-left ${
                    isMobile ? 'mobile-card' : ''
                  } ${
                    !isIncoming ? 'border-l-4 border-l-theme-accent/50' : 'border-l-4 border-l-theme-border/50'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-6 h-6 rounded-none bg-theme-accent/10 text-theme-accent flex items-center justify-center font-bold text-[10px] shrink-0 uppercase border border-theme-border/60">
                      {isIncoming ? (msg.sender_name?.slice(0, 2) || msg.sender.slice(0, 2)) : 'Yo'}
                    </div>
                    <span className="text-xs font-bold text-theme-primary shrink-0 truncate max-w-[120px]">
                      {isIncoming ? (msg.sender_name || msg.sender.split('@')[0]) : 'You'}
                    </span>
                    <span className="text-xs text-theme-muted truncate hidden sm:inline">
                      {msg.body ? stripHtmlTags(removeUnsubscribeFooter(msg.body)).slice(0, 100) : '(No content)'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] font-semibold text-theme-muted">
                      {formatTime(msg.created_at)}
                    </span>
                  </div>
                </div>
              );
            }

            return (
              <div
                key={msg.id}
                onClick={() => toggleMessageExpanded(msg.id)}
                className={`w-full flex flex-col border border-theme-border bg-theme-surface p-5 rounded-none transition-colors hover:border-theme-border/80 cursor-pointer ${
                  isMobile ? 'mobile-card' : ''
                } ${
                  !isIncoming ? 'border-l-4 border-l-theme-accent' : 'border-l-4 border-l-theme-border'
                }`}
              >
                {/* Header row */}
                <div 
                  className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-theme-border/40 text-xs text-theme-muted font-semibold"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-theme-primary text-sm">
                      {isIncoming ? (msg.sender_name || msg.sender.split('@')[0]) : 'You'}
                    </span>
                    <span className="text-theme-muted font-normal">
                      &lt;{isIncoming ? msg.sender : msg.recipient}&gt;
                    </span>
                    {!isIncoming && (
                      <span className="text-[9px] font-extrabold px-1.5 py-0.5 bg-theme-accent/15 text-theme-accent border border-theme-accent/20 uppercase tracking-wide rounded-none">
                        You
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span>{formatTime(msg.created_at)}</span>
                  </div>
                </div>

                {/* Message body */}
                <div
                  className="text-sm text-theme-primary"
                  onClick={(e) => {
                    // Prevent toggling expansion if clicking inside the message box to copy/select text
                    e.stopPropagation();
                  }}
                >
                  <div
                    className="prose prose-sm max-w-none text-left dark:prose-invert text-theme-primary overflow-x-auto"
                    dangerouslySetInnerHTML={renderFormattedBody(removeUnsubscribeFooter(msg.body))}
                  />
                </div>
              </div>
            );
          })
        ) : (
          /* Single outbound detail for Sent/Scheduled/Drafts */
          <div className="mr-auto flex flex-col items-start w-full">
            <div className="flex items-center gap-1.5 text-xs text-theme-muted font-semibold mb-1">
              <span>Sender: {getActiveAccountName()}</span>
              <span>•</span>
              <span>{formatTime(selectedItemData?.sent_time || selectedItemData?.scheduled_time || selectedItemData?.created_at)}</span>
            </div>
 
            <div className={`p-6 bg-theme-surface border border-theme-border rounded-none text-sm shadow-none w-full ${isMobile ? 'mobile-card' : ''}`}>
              <div className="text-xs text-theme-muted font-semibold uppercase mb-2">Recipient</div>
              <div className="text-sm font-semibold mb-4 text-theme-primary">
                {selectedItemData?.recipient_email || selectedItemData?.recipients?.join(', ')}
              </div>
              
              <div className="text-xs text-theme-muted font-semibold uppercase mb-2">Subject</div>
              <div className="text-sm font-semibold mb-4 text-theme-primary">
                {selectedItemData?.subject}
              </div>
 
              <div className="text-xs text-theme-muted font-semibold uppercase mb-2">Body Message</div>
              <div
                className="prose prose-sm max-w-none text-left bg-white p-5 rounded-none border border-gray-200 text-slate-900 overflow-auto shadow-none"
                style={{ color: '#0f172a' }}
                dangerouslySetInnerHTML={renderFormattedBody(removeUnsubscribeFooter(selectedItemData?.body || ''))}
              />
            </div>
          </div>
        )}
      </div>

      {/* Bottom Quick Reply Editor (Only for Inbox Conversations) */}
      {activeFolder === 'inbox' && (
        <div className="p-4 border-t border-theme-border bg-theme-surface/50 flex-shrink-0">
          {!showReplyBox ? (
            <button
              onClick={() => setShowReplyBox(true)}
              className={`w-full flex items-center gap-2.5 px-4 py-3 bg-theme-app/50 hover:bg-theme-hover border border-theme-border rounded-none text-left text-theme-muted text-sm font-semibold transition-all ${isMobile ? 'mobile-card' : ''}`}
            >
              <FontAwesomeIcon icon={CornerUpLeft} className="h-4.5 w-4.5 text-theme-muted" />
              <span>Reply to {getThreadContactInfo().name}...</span>
            </button>
          ) : (
            <div id="reply-composer-area" className="space-y-3 animate-slide-in">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-theme-muted font-mono flex items-center gap-1.5">
                    <FontAwesomeIcon icon={CornerUpLeft} className="h-3 w-3" />
                    Reply Form
                  </span>
                  <button
                    onClick={() => setShowCopilotBar(prev => !prev)}
                    className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-none font-bold text-theme-accent bg-theme-accent/15 hover:bg-theme-accent/25 transition-colors border border-theme-border"
                    type="button"
                  >
                    <FontAwesomeIcon icon={Sparkles} className="h-3 w-3 text-theme-accent animate-pulse" />
                    <span>AI Copilot</span>
                  </button>
                </div>
                <button
                  onClick={() => {
                    setShowReplyBox(false);
                    setReplyBody('');
                    setShowCopilotBar(false);
                  }}
                  className="text-xs text-theme-muted hover:text-theme-primary font-medium transition-colors"
                >
                  Cancel
                </button>
              </div>

              {/* AI Copilot Panel */}
              {showCopilotBar && (
                <AiCopilotDrawer
                  token={token}
                  selectedItemId={selectedItemId}
                  copilotPrompt={copilotPrompt}
                  setCopilotPrompt={setCopilotPrompt}
                  copilotTone={copilotTone}
                  setCopilotTone={setCopilotTone}
                  copilotModel={copilotModel}
                  onDraftGenerated={setReplyBody}
                  onClose={() => setShowCopilotBar(false)}
                />
              )}

              <RichTextEditor
                value={replyBody}
                onChange={setReplyBody}
                placeholder="Write your email reply here..."
              />

              <div className="flex justify-end pt-1">
                <button
                  onClick={handleSendReply}
                  disabled={sendingReply}
                  className="flex items-center gap-2 px-5 py-2 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold text-xs transition-colors disabled:opacity-50 uppercase tracking-wider shadow-none"
                >
                  <FontAwesomeIcon icon={Send} className="h-3.5 w-3.5" />
                  <span>{sendingReply ? 'Sending...' : 'Send Reply'}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
