import React, { memo } from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faEnvelopeOpen as MailOpen, faEnvelope as Mail, faTrashCan as Trash2, 
  faReply as CornerUpLeft, faShare as CornerUpRight, faStar as Star 
} from '@fortawesome/free-solid-svg-icons';

interface TagItem {
  id: string;
  name: string;
  color: string;
}

interface MailItem {
  id: string;
  contact_name?: string;
  recipient_email?: string;
  recipients?: string[];
  subject: string;
  body?: string;
  latest_message_snippet?: string;
  latest_message_time?: string;
  sent_time?: string;
  scheduled_time?: string;
  updated_at?: string;
  unread_count?: number;
  tags?: TagItem[];
}

interface MailItemRowProps {
  item: MailItem;
  activeFolder: 'inbox' | 'sent' | 'scheduled' | 'drafts';
  onSelect: (id: string, item: any) => void;
  checked: boolean;
  onToggleChecked: (id: string, checked: boolean, e?: React.MouseEvent) => void;
  onDelete?: (id: string) => void;
  onToggleRead?: (id: string, isUnread: boolean) => void;
  onReply?: (id: string) => void;
  onForward?: (item: any) => void;
}

const MailItemRow = memo(function MailItemRow({
  item,
  activeFolder,
  onSelect,
  checked,
  onToggleChecked,
  onDelete,
  onToggleRead,
  onReply,
  onForward,
}: MailItemRowProps) {
  const { theme } = useTheme();

  const getThemeClass = (lightClass: string, darkClass: string) => {
    return theme === 'dark' ? darkClass : lightClass;
  };

  const formatTime = (timeStr?: string) => {
    if (!timeStr) return '';
    try {
      const date = new Date(timeStr);
      const now = new Date();
      if (date.toDateString() === now.toDateString()) {
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      }
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    } catch (e) {
      return '';
    }
  };

  let title = '';
  let subtitle = item.subject || '(No Subject)';
  let snippet = '';
  let timeStr = '';
  let isUnread = false;

  if (activeFolder === 'inbox') {
    title = item.contact_name || 'Unknown';
    snippet = item.latest_message_snippet 
      ? item.latest_message_snippet.replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>') 
      : '';
    timeStr = formatTime(item.latest_message_time);
    isUnread = (item.unread_count || 0) > 0;
  } else if (activeFolder === 'sent') {
    title = item.recipient_email || 'No Recipient';
    snippet = item.body ? item.body.replace(/<[^>]*>/g, '') : '';
    timeStr = formatTime(item.sent_time);
  } else if (activeFolder === 'scheduled') {
    title = item.recipient_email || 'No Recipient';
    snippet = item.body ? item.body.replace(/<[^>]*>/g, '') : '';
    timeStr = formatTime(item.scheduled_time);
  } else if (activeFolder === 'drafts') {
    title = item.recipients?.join(', ') || 'No Recipient';
    snippet = item.body ? item.body.replace(/<[^>]*>/g, '') : '';
    timeStr = formatTime(item.updated_at);
  }

  return (
    <div
      onClick={() => onSelect(item.id, item)}
      style={{
        paddingTop: 'var(--mailbox-row-py)',
        paddingBottom: 'var(--mailbox-row-py)',
        fontSize: 'var(--mailbox-font-size)'
      }}
      className={`flex items-center gap-2 sm:gap-4 px-3 sm:px-4 cursor-pointer text-left transition-colors relative border-l-4 group ${
        isUnread 
          ? 'bg-theme-surface border-l-theme-accent shadow-sm' 
          : 'bg-transparent border-l-transparent hover:bg-theme-hover/60'
      }`}
    >
      {/* Checkbox and Star placeholder */}
      <div className="hidden sm:flex items-center gap-3 shrink-0 text-theme-muted">
        <input 
          type="checkbox" 
          checked={checked}
          onClick={(e) => {
            e.stopPropagation();
            onToggleChecked(item.id, !checked, e);
          }}
          onChange={() => {}} 
          className="custom-checkbox"
        />
        <FontAwesomeIcon icon={Star} className="h-4 w-4 text-theme-muted hover:text-role-pending cursor-pointer transition-colors" />
      </div>

      {/* Sender Column */}
      <div className={`w-24 sm:w-44 shrink-0 truncate text-xs sm:text-sm flex items-center gap-2 ${
        isUnread ? 'font-bold text-theme-primary' : 'font-medium text-theme-muted'
      }`}>
        {isUnread && (
          <span className="h-2 w-2 rounded-none rotate-45 bg-theme-accent shrink-0 animate-pulse" title="Unread Message" />
        )}
        <span className="truncate">{title}</span>
      </div>

      {/* Subject & Snippet Column */}
      <div className="flex-1 min-w-0 flex items-center gap-1.5 text-xs sm:text-sm">
        <span className={`truncate shrink-0 ${
          isUnread ? 'font-bold text-theme-primary' : 'font-medium text-theme-secondary'
        }`}>
          {subtitle}
        </span>
        <span className="font-normal truncate hidden md:inline text-theme-muted">
          - {snippet}
        </span>
        {item.tags && item.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 ml-2 shrink-0">
            {item.tags.map((t: TagItem) => (
              <span 
                key={t.id}
                className="text-[10px] px-2 py-0.5 rounded-none font-bold border shrink-0 uppercase tracking-wider"
                style={{ backgroundColor: `${t.color}15`, color: t.color, borderColor: `${t.color}25` }}
              >
                {t.name}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Date/Time or Quick Actions Column */}
      <div className="w-16 sm:w-28 shrink-0 flex items-center justify-end relative h-full">
        {/* Date/Time (visible by default, hidden when parent is hovered) */}
        <span className="group-hover:hidden text-xs font-semibold whitespace-nowrap text-theme-muted">
          {timeStr}
        </span>

        {/* Hover Quick Actions Toolbar (hidden by default, flex layout when parent is hovered) */}
        <div className="hidden group-hover:flex items-center gap-1 bg-transparent pr-1">
          {activeFolder === 'inbox' && (
            <>
              {onReply && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onReply(item.id);
                  }}
                  className="p-1 hover:bg-theme-hover rounded-none text-theme-secondary hover:text-theme-accent transition-colors cursor-pointer"
                  title="Quick Reply"
                >
                  <FontAwesomeIcon icon={CornerUpLeft} className="h-4 w-4" />
                </button>
              )}
              {onForward && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onForward(item);
                  }}
                  className="p-1 hover:bg-theme-hover rounded-none text-theme-secondary hover:text-theme-accent transition-colors cursor-pointer"
                  title="Forward"
                >
                  <FontAwesomeIcon icon={CornerUpRight} className="h-4 w-4" />
                </button>
              )}
              {onToggleRead && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleRead(item.id, isUnread);
                  }}
                  className="p-1 hover:bg-theme-hover rounded-none text-theme-secondary hover:text-theme-accent transition-colors cursor-pointer"
                  title={isUnread ? "Mark as Read" : "Mark as Unread"}
                >
                  {isUnread ? <FontAwesomeIcon icon={MailOpen} className="h-4 w-4" /> : <FontAwesomeIcon icon={Mail} className="h-4 w-4" />}
                </button>
              )}
              {onDelete && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(item.id);
                  }}
                  className="p-1 hover:bg-red-500/10 rounded-none text-theme-secondary hover:text-red-500 transition-colors cursor-pointer"
                  title="Delete"
                >
                  <FontAwesomeIcon icon={Trash2} className="h-4 w-4" />
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}, (prevProps, nextProps) => {
  return (
    prevProps.checked === nextProps.checked &&
    prevProps.activeFolder === nextProps.activeFolder &&
    prevProps.item.id === nextProps.item.id &&
    prevProps.item.unread_count === nextProps.item.unread_count &&
    JSON.stringify(prevProps.item.tags || []) === JSON.stringify(nextProps.item.tags || []) &&
    prevProps.item.subject === nextProps.item.subject &&
    prevProps.item.latest_message_time === nextProps.item.latest_message_time
  );
});

export default MailItemRow;
