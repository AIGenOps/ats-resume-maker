import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faWandMagicSparkles as Sparkles } from '@fortawesome/free-solid-svg-icons';
import { API_BASE } from '../../config';
import { useToast } from '../../contexts/ToastContext';

interface AiCopilotDrawerProps {
  token: string;
  selectedItemId: string | null;
  copilotPrompt: string;
  setCopilotPrompt: (prompt: string) => void;
  copilotTone: string;
  setCopilotTone: (tone: string) => void;
  copilotModel: string;
  onDraftGenerated: (draft: string) => void;
  onClose: () => void;
}

export default function AiCopilotDrawer({
  token,
  selectedItemId,
  copilotPrompt,
  setCopilotPrompt,
  copilotTone,
  setCopilotTone,
  copilotModel,
  onDraftGenerated,
  onClose,
}: AiCopilotDrawerProps) {
  const { addToast } = useToast();
  const [generatingDraft, setGeneratingDraft] = useState(false);

  const handleGenerateAIDraft = async () => {
    if (!copilotPrompt.trim()) return;
    setGeneratingDraft(true);
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/copilot/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          conversation_id: selectedItemId,
          prompt: copilotPrompt.trim(),
          tone: copilotTone,
          model: copilotModel
        })
      });
      const data = await res.json();
      if (res.ok && data.status === 'success') {
        onDraftGenerated(data.draft);
        onClose();
        setCopilotPrompt('');
        addToast('AI Draft generated successfully!', 'success');
      } else {
        addToast(data.detail || 'Failed to generate AI draft', 'error');
      }
    } catch (err) {
      console.error(err);
      addToast('Network error when contacting Gemini API.', 'error');
    } finally {
      setGeneratingDraft(false);
    }
  };

  return (
    <div className="p-3 bg-theme-app/50 border border-theme-border rounded-xl space-y-2.5 animate-slide-in text-left">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase text-theme-muted font-mono flex items-center gap-1">
          <FontAwesomeIcon icon={Sparkles} className="h-3 w-3 text-theme-accent" />
          Describe your response or reply instructions
        </span>
        <div className="flex items-center gap-1">
          <select
            value={copilotTone}
            onChange={(e) => setCopilotTone(e.target.value)}
            className="px-2 py-0.5 bg-theme-surface border border-theme-input rounded-lg text-xs font-semibold text-theme-primary focus:outline-none focus:border-theme-accent focus:ring-1 focus:ring-theme-accent/20 cursor-pointer"
          >
            <option value="professional">Professional</option>
            <option value="friendly">Friendly</option>
            <option value="concise">Concise</option>
          </select>
        </div>
      </div>
      <div className="flex gap-2">
        <input
          type="text"
          value={copilotPrompt}
          onChange={(e) => setCopilotPrompt(e.target.value)}
          placeholder="e.g. Agree to meeting, suggest Wednesday 2pm, ask for their phone number"
          className="flex-grow px-3 py-1.5 bg-theme-surface border border-theme-input rounded-lg text-xs text-theme-primary focus:outline-none focus:border-theme-accent focus:ring-1 focus:ring-theme-accent/20"
        />
        <button
          type="button"
          onClick={handleGenerateAIDraft}
          disabled={generatingDraft || !copilotPrompt.trim()}
          className="px-3.5 py-1.5 bg-theme-accent hover:bg-theme-accentHover text-theme-btnText rounded-lg text-xs font-bold transition-all disabled:opacity-50 shadow-sm shrink-0"
        >
          {generatingDraft ? 'Drafting...' : 'AI Draft'}
        </button>
      </div>
    </div>
  );
}
