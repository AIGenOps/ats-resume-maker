import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faPlus as Plus, faInbox as Inbox, faPaperPlane as ArrowUpRight, 
  faClock as Clock, faFileLines as FileText, faTag as Tag, faXmark as X 
} from '@fortawesome/free-solid-svg-icons';
import { API_BASE } from '../../config';
import { useToast } from '../../contexts/ToastContext';

interface TagItem {
  id: string;
  name: string;
  color: string;
}

interface FolderSidebarProps {
  activeFolder: 'inbox' | 'sent' | 'scheduled' | 'drafts';
  setActiveFolder: (folder: 'inbox' | 'sent' | 'scheduled' | 'drafts') => void;
  activeTagId: string | null;
  setActiveTagId: (tagId: string | null) => void;
  items: any[];
  tags: TagItem[];
  setTags: React.Dispatch<React.SetStateAction<TagItem[]>>;
  token: string;
  onNavigate?: (page: string) => void;
  setSelectedItemId: (id: string | null) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

export default function FolderSidebar({
  activeFolder,
  setActiveFolder,
  activeTagId,
  setActiveTagId,
  items,
  tags,
  setTags,
  token,
  onNavigate,
  setSelectedItemId,
}: FolderSidebarProps) {
  const { addToast } = useToast();
  const [showCreateTagModal, setShowCreateTagModal] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState('#6366F1');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowCreateTagModal(false);
      }
    };
    if (showCreateTagModal) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => window.removeEventListener('keydown', handleEsc);
  }, [showCreateTagModal]);

  const handleCreateTagSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTagName.trim()) return;
    setCreating(true);
    try {
      const res = await fetch(`${API_BASE}/api/v1/mailbox/tags`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          name: newTagName.trim(),
          color: newTagColor
        })
      });
      const data = await res.json();
      if (res.ok) {
        setTags(prev => [...prev, data]);
        setNewTagName('');
        setShowCreateTagModal(false);
        addToast('Label created successfully!', 'success');
      } else {
        addToast(data.detail || 'Failed to create label', 'error');
      }
    } catch (err) {
      console.error(err);
      addToast('Error creating label', 'error');
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteTag = async (e: React.MouseEvent, tag: TagItem) => {
    e.stopPropagation();
    if (confirm(`Are you sure you want to delete label "${tag.name}"?`)) {
      try {
        const res = await fetch(`${API_BASE}/api/v1/mailbox/tags/${tag.id}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          setTags(prev => prev.filter(t => t.id !== tag.id));
          if (activeTagId === tag.id) setActiveTagId(null);
        }
      } catch (err) {
        console.error(err);
      }
    }
  };

  // Inbox unread count calculation
  const unreadCount = items.reduce((acc, i) => acc + ((i && i.unread_count) || 0), 0);

  // Labels unread counts calculation
  const getTagUnreadCount = (tagId: string) => {
    return items.reduce((acc, item) => {
      const hasTag = item.tags?.some((t: any) => t.id === tagId);
      const isUnread = (item.unread_count || 0) > 0;
      return acc + (hasTag && isUnread ? 1 : 0);
    }, 0);
  };

  return (
    <div className="flex-shrink-0 flex flex-col gap-1 select-none border-r border-theme-border h-full bg-[#0D0D0D] w-52 px-4">
      {/* Compose Button (Removed gradient, flat primary action style) */}
      <div className="pt-5 pb-3">
        {onNavigate && (
          <button
            onClick={() => onNavigate('compose_floating')}
            className="w-full py-3 gap-2.5 flex items-center justify-center bg-black border border-white hover:bg-white hover:text-black text-white font-bold rounded-none transition-all duration-300 cursor-pointer font-sans uppercase tracking-wider text-xs shadow-none"
            title="Compose"
          >
            <FontAwesomeIcon icon={Plus} className="h-4.5 w-4.5" />
            <span>Compose</span>
          </button>
        )}
      </div>

      {/* Inbox Folder */}
      <button
        onClick={() => { setActiveFolder('inbox'); setSelectedItemId(null); }}
        className={`flex items-center justify-between py-2.5 rounded-none font-semibold text-sm transition-all w-full px-4 ${
          activeFolder === 'inbox'
            ? 'bg-theme-accent/8 text-theme-accent border border-theme-accent/20'
            : 'hover:bg-theme-hover text-theme-secondary hover:text-theme-primary'
        }`}
        title="Inbox"
      >
        <div className="flex items-center gap-3 justify-start">
          <FontAwesomeIcon icon={Inbox} className="h-4.5 w-4.5 shrink-0" />
          <span>Inbox</span>
        </div>
        {unreadCount > 0 && (
          <span className="text-[10px] font-bold ml-auto px-1.5 py-0.5 rounded-none bg-role-signal/15 text-role-signal border border-role-signal/20">
            {unreadCount}
          </span>
        )}
      </button>

      {/* Sent Folder */}
      <button
        onClick={() => { setActiveFolder('sent'); setSelectedItemId(null); }}
        className={`flex items-center justify-between py-2.5 rounded-none font-semibold text-sm transition-all w-full px-4 ${
          activeFolder === 'sent'
            ? 'bg-theme-accent/8 text-theme-accent border border-theme-accent/20'
            : 'hover:bg-theme-hover text-theme-secondary hover:text-theme-primary'
        }`}
        title="Sent"
      >
        <div className="flex items-center gap-3 justify-start">
          <FontAwesomeIcon icon={ArrowUpRight} className="h-4.5 w-4.5 shrink-0" />
          <span>Sent</span>
        </div>
      </button>

      {/* Scheduled Folder */}
      <button
        onClick={() => { setActiveFolder('scheduled'); setSelectedItemId(null); }}
        className={`flex items-center justify-between py-2.5 rounded-none font-semibold text-sm transition-all w-full px-4 ${
          activeFolder === 'scheduled'
            ? 'bg-theme-accent/8 text-theme-accent border border-theme-accent/20'
            : 'hover:bg-theme-hover text-theme-secondary hover:text-theme-primary'
        }`}
        title="Scheduled"
      >
        <div className="flex items-center gap-3 justify-start">
          <FontAwesomeIcon icon={Clock} className="h-4.5 w-4.5 shrink-0" />
          <span>Scheduled</span>
        </div>
      </button>

      {/* Drafts Folder */}
      <button
        onClick={() => { setActiveFolder('drafts'); setSelectedItemId(null); }}
        className={`flex items-center justify-between py-2.5 rounded-none font-semibold text-sm transition-all w-full px-4 ${
          activeFolder === 'drafts'
            ? 'bg-theme-accent/8 text-theme-accent border border-theme-accent/20'
            : 'hover:bg-theme-hover text-theme-secondary hover:text-theme-primary'
        }`}
        title="Drafts"
      >
        <div className="flex items-center gap-3 justify-start">
          <FontAwesomeIcon icon={FileText} className="h-4.5 w-4.5 shrink-0" />
          <span>Drafts</span>
        </div>
      </button>

      {/* Custom Labels Section */}
      <div className="mt-6 pt-4 border-t border-theme-border w-full">
        <div className="flex justify-between items-center px-4 mb-2.5">
          <span className="text-[10px] font-bold uppercase tracking-wider text-theme-muted font-sans">
            Labels
          </span>
          <button
            onClick={() => setShowCreateTagModal(true)}
            className="text-theme-muted hover:text-theme-primary p-0.5 hover:bg-theme-hover rounded-none transition-colors cursor-pointer"
            title="Create custom label"
          >
            <FontAwesomeIcon icon={Plus} className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-1">
          <button
            onClick={() => setActiveTagId(null)}
            className={`flex items-center py-2.5 rounded-none font-semibold text-xs transition-all w-full px-4 gap-3 ${
              activeTagId === null
                ? 'bg-theme-accent/8 text-theme-accent border border-theme-accent/20'
                : 'text-theme-secondary hover:bg-theme-hover'
            }`}
            title="All Labels"
          >
            <div className="w-2 h-2 rounded-none border border-theme-border bg-theme-muted shrink-0" />
            <span>All Labels</span>
          </button>

          {tags.map(tag => {
            const tagUnread = getTagUnreadCount(tag.id);
            return (
              <div
                key={tag.id}
                className={`flex items-center justify-between rounded-none font-semibold text-xs transition-all group w-full px-4 py-2 ${
                  activeTagId === tag.id
                    ? 'bg-theme-accent/8 text-theme-accent border border-theme-accent/20'
                    : 'text-theme-secondary hover:bg-theme-hover'
                }`}
                title={tag.name}
              >
                <button
                  onClick={() => setActiveTagId(tag.id)}
                  className="flex items-center min-w-0 flex-grow text-left gap-2.5 cursor-pointer"
                >
                  <div 
                    className="w-2.5 h-2.5 rounded-none shrink-0" 
                    style={{ backgroundColor: tag.color }}
                  />
                  <span className="truncate">{tag.name}</span>
                </button>
                <div className="flex items-center gap-1.5 ml-auto">
                  {tagUnread > 0 && (
                    <span className="text-[9px] font-bold text-role-signal bg-role-signal/15 border border-role-signal/20 px-1.5 py-0.5 rounded-none shrink-0">
                      {tagUnread}
                    </span>
                  )}
                  <button
                    onClick={(e) => handleDeleteTag(e, tag)}
                    className="text-theme-muted hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity p-0.5 leading-none cursor-pointer text-xs"
                    title="Delete label"
                  >
                    &times;
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Create Label Modal Popup */}
      {showCreateTagModal && createPortal(
        <div className="modal-backdrop" onClick={() => setShowCreateTagModal(false)}>
          <div 
            className="modal-content w-full max-w-sm bg-theme-surface border border-theme-border rounded-none max-h-[90vh] flex flex-col overflow-hidden relative text-theme-primary shadow-2xl animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex justify-between items-center px-6 py-4 border-b border-theme-border shrink-0">
              <h3 className="text-base font-bold text-theme-primary flex items-center gap-2 font-sans">
                <FontAwesomeIcon icon={Tag} className="h-4.5 w-4.5 text-[#60A5FA]" />
                Create Custom Label
              </h3>
              <button 
                type="button"
                onClick={() => setShowCreateTagModal(false)}
                className="text-theme-muted hover:text-theme-primary p-1.5 rounded-none hover:bg-theme-hover transition-colors cursor-pointer"
              >
                <FontAwesomeIcon icon={X} className="h-4.5 w-4.5" />
              </button>
            </div>

            <form onSubmit={handleCreateTagSubmit} className="flex-1 flex flex-col min-h-0">
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-theme-muted mb-1.5 font-sans">Label Name</label>
                  <input 
                    type="text" 
                    value={newTagName} 
                    onChange={(e) => setNewTagName(e.target.value)} 
                    placeholder="e.g. Work, Urgent..."
                    className="w-full px-3.5 py-2.5 bg-black border border-theme-input rounded-none text-sm text-theme-primary placeholder-theme-muted focus:outline-none focus:border-theme-accent focus:ring-0"
                    required
                    autoFocus
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-theme-muted mb-1.5 font-sans">Label Color</label>
                  <div className="flex items-center gap-3">
                    <input 
                      type="color" 
                      value={newTagColor} 
                      onChange={(e) => setNewTagColor(e.target.value)} 
                      className="w-8 h-8 rounded-none border-0 bg-transparent cursor-pointer shrink-0"
                    />
                    <span className="text-xs text-theme-secondary uppercase font-mono font-bold">{newTagColor}</span>
                  </div>
                </div>
              </div>

              <div className="px-6 py-4 border-t border-theme-border bg-theme-app/30 flex justify-end gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setShowCreateTagModal(false)}
                  className="px-4 py-2 bg-theme-surface border border-theme-border hover:bg-theme-hover text-theme-primary rounded-none font-semibold transition-colors text-sm cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="px-4 py-2 bg-black border border-white hover:bg-white hover:text-black text-white rounded-none font-bold transition-colors shadow-none disabled:opacity-50 text-sm cursor-pointer uppercase tracking-wider"
                >
                  {creating ? 'Creating...' : 'Create Label'}
                </button>
              </div>
            </form>
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}
