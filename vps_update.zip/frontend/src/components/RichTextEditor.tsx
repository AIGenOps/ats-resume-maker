import React, { useRef, useState, useEffect } from 'react';
import { Bold, Italic, Link, Sparkles, Trash2, Code, Underline, List, ListOrdered, AlignLeft, AlignCenter, AlignRight } from 'lucide-react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export default function RichTextEditor({ value, onChange, placeholder = 'Write your message...' }: RichTextEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const [showSource, setShowSource] = useState(false);
  const [bubbleMenu, setBubbleMenu] = useState<{ show: boolean; top: number; left: number }>({
    show: false,
    top: 0,
    left: 0
  });

  const [activeFormats, setActiveFormats] = useState({
    bold: false,
    italic: false,
    underline: false,
    strikeThrough: false,
    insertUnorderedList: false,
    insertOrderedList: false,
    justifyLeft: false,
    justifyCenter: false,
    justifyRight: false,
  });

  const checkActiveFormats = () => {
    if (showSource) return;
    try {
      setActiveFormats({
        bold: document.queryCommandState('bold'),
        italic: document.queryCommandState('italic'),
        underline: document.queryCommandState('underline'),
        strikeThrough: document.queryCommandState('strikeThrough'),
        insertUnorderedList: document.queryCommandState('insertUnorderedList'),
        insertOrderedList: document.queryCommandState('insertOrderedList'),
        justifyLeft: document.queryCommandState('justifyLeft'),
        justifyCenter: document.queryCommandState('justifyCenter'),
        justifyRight: document.queryCommandState('justifyRight'),
      });
    } catch (e) {
      // Ignore
    }
  };

  // Sync value changes (like templates or AI draft updates) dynamically
  useEffect(() => {
    if (!showSource && editorRef.current && editorRef.current.innerHTML !== value) {
      editorRef.current.innerHTML = value || '';
    }
  }, [value, showSource]);

  const handleInput = () => {
    if (editorRef.current) {
      onChange(editorRef.current.innerHTML);
    }
  };

  const handleSelection = () => {
    if (showSource) return;
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !selection.toString().trim()) {
      setBubbleMenu((prev) => ({ ...prev, show: false }));
      return;
    }

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();
    
    // Check if selection is within our editor
    if (editorRef.current && editorRef.current.contains(range.commonAncestorContainer)) {
      // Position bubble menu centered above selection
      setBubbleMenu({
        show: true,
        top: window.scrollY + rect.top - 50, // 50px above selection
        left: window.scrollX + rect.left + rect.width / 2 - 80 // offset half bubble width
      });
    }
  };

  useEffect(() => {
    const handleDocumentSelection = () => {
      // Wrap in small timeout to ensure selection states are updated
      setTimeout(() => {
        handleSelection();
        checkActiveFormats();
      }, 10);
    };

    document.addEventListener('selectionchange', handleDocumentSelection);
    return () => {
      document.removeEventListener('selectionchange', handleDocumentSelection);
    };
  }, [showSource]);

  const execCmd = (command: string, value: string = '') => {
    if (showSource) return;
    document.execCommand(command, false, value);
    handleInput();
    checkActiveFormats();
  };

  const handleAddLink = () => {
    const url = prompt('Enter link URL (e.g., https://google.com):');
    if (url) {
      execCmd('createLink', url);
    }
  };

  const insertVariable = (variableName: string) => {
    if (showSource) {
      // In source code mode, insert variables as text at text cursor position
      const textarea = document.getElementById('raw-html-textarea') as HTMLTextAreaElement;
      if (textarea) {
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const text = textarea.value;
        const before = text.substring(0, start);
        const after = text.substring(end, text.length);
        const newValue = `${before}{{${variableName}}}${after}`;
        onChange(newValue);
        // Reset selection
        setTimeout(() => {
          textarea.focus();
          textarea.selectionStart = textarea.selectionEnd = start + variableName.length + 4;
        }, 10);
      }
      return;
    }

    if (editorRef.current) {
      editorRef.current.focus();
      const sel = window.getSelection();
      if (sel && sel.rangeCount > 0) {
        const range = sel.getRangeAt(0);
        range.deleteContents();
        const node = document.createTextNode(`{{${variableName}}}`);
        range.insertNode(node);
        // Move caret
        range.setStartAfter(node);
        range.setEndAfter(node);
        sel.removeAllRanges();
        sel.addRange(range);
        handleInput();
      }
    }
  };

  return (
    <div className="relative border border-theme-border rounded-xl bg-theme-surface transition-colors focus-within:border-theme-accent focus-within:ring-2 focus-within:ring-theme-accent/20">
      {/* Small top helper menu for templates variables insertion & Source Toggle */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-theme-border bg-theme-app/50 rounded-t-xl text-xs font-semibold text-theme-muted">
        <div className="flex items-center gap-1.5">
          <Sparkles className="h-3.5 w-3.5 text-theme-accent" />
          <span>Insert Variable:</span>
          <button
            type="button"
            onClick={() => insertVariable('name')}
            className="px-2 py-0.5 bg-theme-app hover:bg-theme-hover text-theme-secondary rounded transition-colors cursor-pointer"
          >
            &#123;&#123;name&#125;&#125;
          </button>
          <button
            type="button"
            onClick={() => insertVariable('company')}
            className="px-2 py-0.5 bg-theme-app hover:bg-theme-hover text-theme-secondary rounded transition-colors cursor-pointer"
          >
            &#123;&#123;company&#125;&#125;
          </button>
        </div>

        <button
          type="button"
          onClick={() => setShowSource(!showSource)}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded transition-all cursor-pointer text-xs font-bold ${
            showSource 
              ? 'bg-theme-accent/20 text-theme-accent' 
              : 'bg-theme-app hover:bg-theme-hover text-theme-secondary'
          }`}
          title="Toggle between WYSIWYG editor and raw HTML source code"
        >
          <Code className="h-3.5 w-3.5" />
          <span>{showSource ? 'Rich Text Editor' : 'HTML Source'}</span>
        </button>
      </div>

      {/* Static Formatting Toolbar */}
      {!showSource && (
        <div className="flex flex-wrap items-center gap-1 px-3 py-2 border-b border-theme-border bg-theme-surface/50 text-theme-secondary">
          <button
            type="button"
            onClick={() => execCmd('bold')}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              activeFormats.bold 
                ? 'bg-theme-accent/15 text-theme-accent ring-1 ring-theme-accent/30' 
                : 'hover:bg-theme-hover hover:text-theme-primary text-theme-muted'
            }`}
            title="Bold"
          >
            <Bold className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => execCmd('italic')}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              activeFormats.italic 
                ? 'bg-theme-accent/15 text-theme-accent ring-1 ring-theme-accent/30' 
                : 'hover:bg-theme-hover hover:text-theme-primary text-theme-muted'
            }`}
            title="Italic"
          >
            <Italic className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => execCmd('underline')}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              activeFormats.underline 
                ? 'bg-theme-accent/15 text-theme-accent ring-1 ring-theme-accent/30' 
                : 'hover:bg-theme-hover hover:text-theme-primary text-theme-muted'
            }`}
            title="Underline"
          >
            <Underline className="h-4 w-4" />
          </button>
          
          <div className="w-[1px] h-4 bg-theme-border mx-1" />
          
          <button
            type="button"
            onClick={() => execCmd('insertUnorderedList')}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              activeFormats.insertUnorderedList 
                ? 'bg-theme-accent/15 text-theme-accent ring-1 ring-theme-accent/30' 
                : 'hover:bg-theme-hover hover:text-theme-primary text-theme-muted'
            }`}
            title="Bullet List"
          >
            <List className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => execCmd('insertOrderedList')}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              activeFormats.insertOrderedList 
                ? 'bg-theme-accent/15 text-theme-accent ring-1 ring-theme-accent/30' 
                : 'hover:bg-theme-hover hover:text-theme-primary text-theme-muted'
            }`}
            title="Numbered List"
          >
            <ListOrdered className="h-4 w-4" />
          </button>

          <div className="w-[1px] h-4 bg-theme-border mx-1" />

          <button
            type="button"
            onClick={() => execCmd('justifyLeft')}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              activeFormats.justifyLeft 
                ? 'bg-theme-accent/15 text-theme-accent ring-1 ring-theme-accent/30' 
                : 'hover:bg-theme-hover hover:text-theme-primary text-theme-muted'
            }`}
            title="Align Left"
          >
            <AlignLeft className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => execCmd('justifyCenter')}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              activeFormats.justifyCenter 
                ? 'bg-theme-accent/15 text-theme-accent ring-1 ring-theme-accent/30' 
                : 'hover:bg-theme-hover hover:text-theme-primary text-theme-muted'
            }`}
            title="Align Center"
          >
            <AlignCenter className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => execCmd('justifyRight')}
            className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
              activeFormats.justifyRight 
                ? 'bg-theme-accent/15 text-theme-accent ring-1 ring-theme-accent/30' 
                : 'hover:bg-theme-hover hover:text-theme-primary text-theme-muted'
            }`}
            title="Align Right"
          >
            <AlignRight className="h-4 w-4" />
          </button>

          <div className="w-[1px] h-4 bg-theme-border mx-1" />

          <button
            type="button"
            onClick={handleAddLink}
            className="p-1.5 hover:bg-theme-hover hover:text-theme-primary rounded-lg transition-colors cursor-pointer"
            title="Add Link"
          >
            <Link className="h-4 w-4" />
          </button>
          
          <button
            type="button"
            onClick={() => execCmd('removeFormat')}
            className="p-1.5 hover:bg-theme-hover hover:text-theme-primary rounded-lg transition-colors cursor-pointer ml-auto"
            title="Clear Formatting"
          >
            <Trash2 className="h-4 w-4 text-red-500 hover:text-red-650" />
          </button>
        </div>
      )}

      {/* Editor Content Area */}
      {showSource ? (
        <textarea
          id="raw-html-textarea"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder="Paste or write raw HTML code here..."
          className="w-full px-4 py-3 min-h-[220px] max-h-[400px] outline-none font-mono text-xs bg-theme-app text-theme-primary border-0 rounded-b-xl resize-y"
          style={{
            lineHeight: '1.6',
          }}
        />
      ) : (
        <div
          ref={editorRef}
          contentEditable
          onInput={handleInput}
          onKeyUp={checkActiveFormats}
          onMouseUp={checkActiveFormats}
          data-placeholder={placeholder}
          className="w-full px-4 py-3 min-h-[220px] max-h-[400px] overflow-y-auto outline-none prose prose-slate dark:prose-invert max-w-none text-sm text-theme-primary"
          style={{
            lineHeight: '1.6',
          }}
        />
      )}

      {/* Floating Formatting Bubble Menu */}
      {bubbleMenu.show && !showSource && (
        <div
          className="absolute z-50 flex items-center gap-1 px-2 py-1.5 bg-theme-surface border border-theme-border rounded-xl shadow-2xl backdrop-blur-md animate-fade-in"
          style={{
            top: `${bubbleMenu.top}px`,
            left: `${bubbleMenu.left}px`,
            transform: 'translateY(-100%)',
          }}
        >
          <button
            type="button"
            onClick={() => execCmd('bold')}
            className="p-1.5 hover:bg-theme-hover rounded-lg text-theme-secondary hover:text-theme-primary transition-colors"
            title="Bold"
          >
            <Bold className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => execCmd('italic')}
            className="p-1.5 hover:bg-theme-hover rounded-lg text-theme-secondary hover:text-theme-primary transition-colors"
            title="Italic"
          >
            <Italic className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={handleAddLink}
            className="p-1.5 hover:bg-theme-hover rounded-lg text-theme-secondary hover:text-theme-primary transition-colors"
            title="Add Link"
          >
            <Link className="h-3.5 w-3.5" />
          </button>
          <div className="w-[1px] h-4 bg-theme-border mx-1" />
          <button
            type="button"
            onClick={() => execCmd('removeFormat')}
            className="p-1.5 hover:bg-theme-hover rounded-lg text-theme-secondary hover:text-theme-primary transition-colors"
            title="Clear Formatting"
          >
            <Trash2 className="h-3.5 w-3.5 text-red-400" />
          </button>
        </div>
      )}
    </div>
  );
}
