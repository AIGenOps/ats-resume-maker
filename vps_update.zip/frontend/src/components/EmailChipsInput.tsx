import React, { useState, useRef, useEffect } from 'react';
import type { KeyboardEvent } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser as User, faXmark as X } from '@fortawesome/free-solid-svg-icons';
import { API_BASE } from '../config';

interface EmailChipsInputProps {
  emails: string[];
  onChange: (emails: string[]) => void;
  placeholder?: string;
  icon?: React.ReactNode;
  baseBgClass?: string;
}

export default function EmailChipsInput({
  emails,
  onChange,
  placeholder = 'Type email and press Enter...',
  icon,
  baseBgClass = "bg-theme-surface border border-theme-input text-theme-primary focus-within:border-theme-accent focus-within:ring-2 focus-within:ring-theme-accent/20"
}: EmailChipsInputProps) {
  const [inputValue, setInputValue] = useState('');
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [activeSuggestion, setActiveSuggestion] = useState(0);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const isValidEmail = (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handleContainerClick = () => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  };

  const fetchSuggestions = async (query: string) => {
    if (!query.trim()) {
      setSuggestions([]);
      setShowSuggestions(false);
      return;
    }
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`${API_BASE}/api/v1/contacts/?search=${encodeURIComponent(query)}&limit=10`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        const list = data.contacts || [];
        setSuggestions(list);
        setShowSuggestions(list.length > 0);
        setActiveSuggestion(0);
      }
    } catch (e) {
      console.error('Error fetching autocomplete suggestions:', e);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setInputValue(val);
    fetchSuggestions(val);
  };

  const addEmail = (emailStr: string) => {
    const trimmed = emailStr.trim();
    if (!trimmed) return;
    
    // Support pasting multiple emails separated by comma or semicolon
    const parts = trimmed.split(/[\s,;]+/).filter(p => p.length > 0);
    
    // Filter duplicates
    const uniqueNew = parts.filter(p => !emails.includes(p));
    if (uniqueNew.length > 0) {
      onChange([...emails, ...uniqueNew]);
    }
    setInputValue('');
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const removeEmail = (index: number) => {
    const updated = emails.filter((_, i) => i !== index);
    onChange(updated);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (suggestions.length > 0) {
        setActiveSuggestion(prev => Math.min(prev + 1, suggestions.length - 1));
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (suggestions.length > 0) {
        setActiveSuggestion(prev => Math.max(prev - 1, 0));
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      setShowSuggestions(false);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (showSuggestions && suggestions.length > 0) {
        const selected = suggestions[activeSuggestion];
        addEmail(selected.email);
      } else {
        addEmail(inputValue);
      }
    } else if (e.key === ',') {
      e.preventDefault();
      addEmail(inputValue);
    } else if (e.key === 'Tab') {
      if (showSuggestions && suggestions.length > 0) {
        e.preventDefault();
        const selected = suggestions[activeSuggestion];
        addEmail(selected.email);
      } else if (inputValue.trim()) {
        e.preventDefault();
        addEmail(inputValue);
      }
    } else if (e.key === 'Backspace' && !inputValue && emails.length > 0) {
      e.preventDefault();
      removeEmail(emails.length - 1);
    }
  };

  const handleBlur = () => {
    // Timeout gives onMouseDown suggestions click handler time to fire before blur closes them
    setTimeout(() => {
      setShowSuggestions(false);
      if (inputValue.trim()) {
        addEmail(inputValue);
      }
    }, 200);
  };

  return (
    <div className="relative w-full">
      <div
        onClick={handleContainerClick}
        className={`flex flex-wrap items-center gap-2 px-3.5 py-2 rounded-xl text-xs transition-colors w-full cursor-text min-h-[40px] ${baseBgClass}`}
      >
        {icon && <div className="text-theme-muted pl-0.5 shrink-0">{icon}</div>}
        
        <div className="flex flex-wrap items-center gap-1.5">
          {emails.map((email, idx) => {
            const valid = isValidEmail(email);
            return (
              <div
                key={idx}
                className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border text-xs font-semibold select-none ${
                  valid
                    ? 'bg-theme-app border-theme-border text-theme-secondary font-semibold'
                    : 'bg-red-500/10 border-red-500/30 text-red-500 dark:text-red-400'
                }`}
              >
                <div className={`w-3.5 h-3.5 rounded-full flex items-center justify-center shrink-0 ${valid ? 'bg-theme-accent/20 text-theme-accent' : 'bg-red-500/20 text-red-500'}`}>
                  <FontAwesomeIcon icon={User} className="h-2 w-2" />
                </div>
                <span className="max-w-[200px] truncate">{email}</span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeEmail(idx);
                  }}
                  className="hover:text-red-500 dark:hover:text-red-400 transition-colors cursor-pointer shrink-0"
                >
                  <FontAwesomeIcon icon={X} className="h-2.5 w-2.5" />
                </button>
              </div>
            );
          })}
        </div>

        <input
          ref={inputRef}
          type="text"
          value={inputValue}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onBlur={handleBlur}
          placeholder={emails.length === 0 ? placeholder : ''}
          className="flex-1 bg-transparent border-0 outline-none p-0.5 text-xs text-theme-primary placeholder-theme-muted min-w-[120px] focus:ring-0 focus:outline-none focus:border-none shadow-none font-semibold"
        />
      </div>

      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute left-0 right-0 mt-1 bg-theme-surface border border-theme-border rounded-xl shadow-2xl z-[999] max-h-56 overflow-y-auto overflow-x-hidden backdrop-blur-md animate-fade-in">
          {suggestions.map((s, idx) => (
            <div
              key={s.id}
              onMouseDown={(e) => {
                e.preventDefault(); // Prevents input blur before selection
                addEmail(s.email);
              }}
              onMouseEnter={() => setActiveSuggestion(idx)}
              className={`px-4 py-2.5 cursor-pointer text-left transition-colors flex items-center justify-between border-b border-theme-border/20 last:border-0 ${
                idx === activeSuggestion ? 'bg-theme-accent/20 text-theme-primary font-bold' : 'text-theme-secondary font-semibold'
              }`}
            >
              <div>
                <div className="font-bold text-xs">{s.full_name}</div>
                <div className="text-[10px] text-theme-muted mt-0.5">{s.email}</div>
              </div>
              {s.company && (
                <div className="text-[10px] text-theme-muted italic font-medium bg-theme-app/50 px-2.5 py-0.5 rounded-full border border-theme-border/30">{s.company}</div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
