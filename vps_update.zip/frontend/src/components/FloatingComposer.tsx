import React, { useState, useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { API_BASE } from '../config';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faPaperPlane as Send, faEye as Eye, faRotate as RefreshCw, 
  faFileLines as FileText, faShieldHalved as ShieldCheck, faEnvelope as Mail, faWandMagicSparkles as Sparkles, faXmark as X, 
  faCalendarDays as Calendar, faClock as Clock, faCaretUp as ChevronUp, faCaretDown as ChevronDown, 
  faExpand as Maximize2, faCompress as Minimize2, faTrashCan as Trash2 
} from '@fortawesome/free-solid-svg-icons';
import RichTextEditor from './RichTextEditor';
import EmailChipsInput from './EmailChipsInput';
import { useToast } from '../contexts/ToastContext';

interface FloatingComposerProps {
  token: string;
  onClose: () => void;
  minimized: boolean;
  setMinimized: (min: boolean) => void;
  onNavigate?: (page: string) => void;
}

export default function FloatingComposer({
  token,
  onClose,
  minimized,
  setMinimized,
  onNavigate
}: FloatingComposerProps) {
  const { addToast } = useToast();
  const [isMobile, setIsMobile] = useState(typeof window !== 'undefined' ? window.innerWidth < 768 : false);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [templates, setTemplates] = useState<any[]>([]);
  const [smtpAccounts, setSmtpAccounts] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCc, setShowCc] = useState(false);
  const [showBcc, setShowBcc] = useState(false);

  // Form Fields
  const [smtpId, setSmtpId] = useState('');
  const [recipients, setRecipients] = useState<string[]>([]);
  const [cc, setCc] = useState<string[]>([]);
  const [bcc, setBcc] = useState<string[]>([]);
  const [subject, setSubject] = useState('');
  const [bodyHtml, setBodyHtml] = useState('');
  const [selectedTemplateId, setSelectedTemplateId] = useState('');
  const [attachments, setAttachments] = useState<any[]>([]);
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledTime, setScheduledTime] = useState('');
  const [isRippling, setIsRippling] = useState(false);
  const dateInputRef = useRef<HTMLInputElement>(null);

  const triggerDatePicker = () => {
    setIsScheduled(true);
    setTimeout(() => {
      if (dateInputRef.current) {
        if (typeof dateInputRef.current.showPicker === 'function') {
          dateInputRef.current.showPicker();
        } else {
          dateInputRef.current.focus();
          dateInputRef.current.click();
        }
      }
    }, 50);
  };

  // AI Copilot States
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiTone, setAiTone] = useState(localStorage.getItem('setting_default_tone') || 'professional');
  const [aiModel] = useState(localStorage.getItem('setting_ai_model') || 'gemini-2.5-flash');
  const [generatingAi, setGeneratingAi] = useState(false);
  const [aiError, setAiError] = useState('');

  const handleAiGenerate = async () => {
    if (!aiPrompt.trim()) return;
    setGeneratingAi(true);
    setAiError('');
    try {
      const response = await fetch(`${API_BASE}/api/v1/mailbox/copilot/generate`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          prompt: aiPrompt,
          tone: aiTone,
          model: aiModel
        })
      });
      if (!response.ok) {
        throw new Error('Failed to generate draft with AI');
      }
      const data = await response.json();
      if (data.draft) {
        setBodyHtml(data.draft);
        if (!subject) {
          const words = aiPrompt.split(' ').slice(0, 4).join(' ');
          setSubject(`Outreach regarding: ${words}...`);
        }
      }
    } catch (err: any) {
      setAiError(err.message || 'AI generation failed');
    } finally {
      setGeneratingAi(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const files = Array.from(e.target.files);
    
    files.forEach((file) => {
      if (file.size > 2 * 1024 * 1024) {
        addToast(`File "${file.name}" exceeds the maximum limit of 2 MB.`, 'error');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string)
          .replace("data:", "")
          .replace(/^.+,/, "");
          
        setAttachments((prev) => [
          ...prev,
          {
            filename: file.name,
            content: base64String,
            mime_type: file.type || "application/octet-stream",
            formattedSize: formatFileSize(file.size)
          }
        ]);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  };

  const removeAttachment = (index: number) => {
    setAttachments((prev) => prev.filter((_, i) => i !== index));
  };
  
  // Preview State
  const [previewSubject, setPreviewSubject] = useState('');
  const [previewBody, setPreviewBody] = useState('');
  const [showPreview, setShowPreview] = useState(false);
  
  // Validation status
  const [smtpStatus, setSmtpStatus] = useState<string | null>(null);
  const [testingSmtp, setTestingSmtp] = useState(false);

  useEffect(() => {
    fetchTemplates();
    fetchSmtpAccounts();
  }, []);

  // Load draft from localStorage on mount
  useEffect(() => {
    const savedDraft = localStorage.getItem('mailai_composer_draft');
    if (savedDraft) {
      try {
        const parsed = JSON.parse(savedDraft);
        if (parsed.recipients) setRecipients(parsed.recipients);
        if (parsed.cc) setCc(parsed.cc);
        if (parsed.bcc) setBcc(parsed.bcc);
        if (parsed.subject) setSubject(parsed.subject);
        if (parsed.bodyHtml) setBodyHtml(parsed.bodyHtml);
        if (parsed.smtpId) setSmtpId(parsed.smtpId);
        if (parsed.showCc) setShowCc(parsed.showCc);
        if (parsed.showBcc) setShowBcc(parsed.showBcc);
      } catch (err) {
        console.error("Error restoring draft:", err);
      }
    }
  }, []);

  // Save draft dynamically (autosave)
  useEffect(() => {
    const draftData = {
      recipients,
      cc,
      bcc,
      subject,
      bodyHtml,
      smtpId,
      showCc,
      showBcc
    };
    if (recipients.length > 0 || subject.trim() || bodyHtml.trim()) {
      localStorage.setItem('mailai_composer_draft', JSON.stringify(draftData));
    }
  }, [recipients, cc, bcc, subject, bodyHtml, smtpId, showCc, showBcc]);

  // Load prepopulated reply/forward session data on mount
  useEffect(() => {
    const prepopulated = sessionStorage.getItem('compose_prepopulated');
    if (prepopulated) {
      try {
        const parsed = JSON.parse(prepopulated);
        if (parsed.recipients) setRecipients(parsed.recipients);
        if (parsed.subject) setSubject(parsed.subject);
        if (parsed.body) setBodyHtml(parsed.body);
        sessionStorage.removeItem('compose_prepopulated');
      } catch (err) {
        console.error("Error restoring prepopulated compose:", err);
      }
    }
  }, []);

  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowPreview(false);
      }
    };
    if (showPreview) {
      window.addEventListener('keydown', handleEsc);
    }
    return () => window.removeEventListener('keydown', handleEsc);
  }, [showPreview]);

  const fetchTemplates = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/templates/`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      setTemplates(data || []);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchSmtpAccounts = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/v1/smtp/`, {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      setSmtpAccounts(data || []);
      if (data.length > 0) setSmtpId(data[0].id);
    } catch (e) {
      console.error(e);
    }
  };

  const handleTemplateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const tplId = e.target.value;
    setSelectedTemplateId(tplId);
    if (!tplId) return;

    const tpl = templates.find((t) => t.id === tplId);
    if (tpl) {
      setSubject(tpl.subject);
      setBodyHtml(tpl.body_html);
    }
  };

  const testSmtp = async () => {
    if (!smtpId) {
      addToast("Please configure and select an SMTP account first.", 'error');
      return;
    }
    setTestingSmtp(true);
    setSmtpStatus(null);
    try {
      const response = await fetch(`${API_BASE}/api/v1/smtp/${smtpId}/test`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const data = await response.json();
      if (response.ok) {
        setSmtpStatus("Verified Connection");
      } else {
        setSmtpStatus(`Failed: ${data.detail}`);
      }
    } catch (err: any) {
      setSmtpStatus(`Connection error: ${err.message}`);
    } finally {
      setTestingSmtp(false);
    }
  };

  const handleRenderPreview = () => {
    const mockVals = {
      name: 'Grace Harper',
      company: 'Google DeepMind',
    };
    
    let renderedSubject = subject;
    let renderedBody = bodyHtml;

    Object.entries(mockVals).forEach(([key, val]) => {
      const regex = new RegExp(`\\{\\{\\s*${key}\\s*\\}\\}`, 'g');
      renderedSubject = renderedSubject.replace(regex, val);
      renderedBody = renderedBody.replace(regex, val);
    });

    setPreviewSubject(renderedSubject);
    setPreviewBody(renderedBody);
    setShowPreview(true);
  };

  const handleDirectSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (recipients.length === 0 || !subject.trim() || !bodyHtml.trim()) {
      addToast("Please fill in Recipients, Subject, and Email Body.", 'error');
      return;
    }

    setIsRippling(true);
    await new Promise((resolve) => setTimeout(resolve, 600));
    setIsRippling(false);

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/v1/campaigns/send-direct`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          recipient_email: recipients.join(','),
          subject,
          body: bodyHtml,
          smtp_id: smtpId || null,
          cc: cc.length > 0 ? cc.join(',') : null,
          bcc: bcc.length > 0 ? bcc.join(',') : null,
          attachments: attachments.length > 0 ? attachments.map(({ filename, content, mime_type }) => ({ filename, content, mime_type })) : null,
          scheduled_time: isScheduled && scheduledTime ? new Date(scheduledTime).toISOString() : null,
          sender_name: localStorage.getItem('setting_sender_name') || null,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || 'Failed to dispatch email.');
      }

      localStorage.removeItem('mailai_composer_draft');
      addToast(
        isScheduled 
          ? 'Outreach email scheduled successfully!' 
          : 'Outreach email dispatched successfully!', 
        'success'
      );
      
      onClose();
    } catch (err: any) {
      addToast(`Outreach send failed: ${err.message}`, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleMaximizeToPage = () => {
    const composeData = {
      recipients,
      cc,
      bcc,
      subject,
      body: bodyHtml,
      smtpId
    };
    sessionStorage.setItem('compose_prepopulated', JSON.stringify(composeData));
    localStorage.removeItem('mailai_composer_draft');
    if (onNavigate) {
      onNavigate('compose');
    }
    onClose();
  };

  return (
    <>
      {/* Focused dark semi-transparent backdrop with slight blur behind the active compose window */}
      {!minimized && (
        <div 
          className="fixed inset-0 bg-[#000]/60 backdrop-blur-[2px] z-[9990] transition-all duration-300"
          onClick={onClose}
        />
      )}

      <div
        className={`fixed z-[9999] bg-[#0E0E12] border border-[#1D1D22] shadow-2xl overflow-hidden flex flex-col transition-all duration-300 text-theme-primary ${
          isMobile
            ? minimized 
              ? 'bottom-0 right-4 h-12 w-[280px] rounded-none' 
              : 'inset-0 h-full w-full max-w-none pt-safe pb-safe rounded-none'
            : minimized 
              ? 'bottom-0 right-10 h-12 w-[350px] rounded-none' 
              : 'bottom-0 right-10 h-[670px] w-[680px] max-w-[calc(100vw-60px)] rounded-none'
        }`}
        style={isMobile && !minimized ? { bottom: '0px', height: '100%', top: '0px' } : undefined}
      >
        {/* Title Bar Header */}
        <div className="h-12 flex justify-between items-center px-4 bg-[#121216]/80 border-b border-[#1D1D22] flex-shrink-0 select-none">
          <div className="flex items-center gap-2">
            <FontAwesomeIcon icon={Mail} className="h-4 w-4 text-role-creative" />
            <span className="text-xs font-bold font-sans uppercase tracking-wider">New Outreach Message</span>
          </div>
          
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleMaximizeToPage}
              className="p-1 hover:bg-theme-hover rounded-none transition-colors text-theme-muted hover:text-theme-primary cursor-pointer"
              title="Maximize to Full Screen Page"
            >
              <FontAwesomeIcon icon={Maximize2} className="h-3.5 w-3.5" />
            </button>
            <button
              type="button"
              onClick={() => {
                setMinimized(!minimized);
              }}
              className="p-1 hover:bg-theme-hover rounded-none transition-colors text-theme-muted hover:text-theme-primary cursor-pointer"
              title={minimized ? "Restore Window" : "Minimize Window"}
            >
              {minimized ? <FontAwesomeIcon icon={ChevronUp} className="h-4 w-4" /> : <FontAwesomeIcon icon={ChevronDown} className="h-4 w-4" />}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-1 hover:bg-red-500/10 hover:text-red-500 rounded-none transition-colors text-theme-muted cursor-pointer"
              title="Close Draft"
            >
              <FontAwesomeIcon icon={X} className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Main Composer Form Panel */}
        {!minimized && (
          <div className="flex-grow overflow-y-auto p-5 space-y-5 flex flex-col justify-between">
            <form onSubmit={handleDirectSend} className="space-y-4">
              <div className="flex flex-col gap-4">
                {/* SMTP Account (Clean stack to prevent badges overlap) */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-theme-muted mb-1.5 font-sans">SMTP Account</label>
                  <div className="flex flex-wrap sm:flex-nowrap gap-2 items-center">
                    <select
                      value={smtpId}
                      onChange={(e) => {
                        setSmtpId(e.target.value);
                        setSmtpStatus(null);
                      }}
                      className="flex-grow px-3.5 py-2.5 bg-[#0A0A0D] border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent transition-colors text-theme-primary cursor-pointer"
                    >
                      {smtpAccounts.map((acc) => (
                        <option key={acc.id} value={acc.id} className="text-theme-primary bg-theme-surface">
                          {acc.name} ({acc.from_email})
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      onClick={testSmtp}
                      disabled={testingSmtp}
                      className="px-4 py-2.5 bg-[#121216] border border-[#1D1D22] hover:bg-theme-hover rounded-none text-[10px] font-bold transition-all text-theme-secondary shrink-0 cursor-pointer flex items-center gap-1.5"
                    >
                      <FontAwesomeIcon icon={ShieldCheck} className="h-4 w-4 text-role-signal" />
                      <span>{testingSmtp ? 'Checking...' : 'Test SMTP'}</span>
                    </button>
                    {smtpStatus && (
                      <span className={`px-2.5 py-1.5 border rounded-none text-[10px] font-bold uppercase tracking-wider shrink-0 ${
                        smtpStatus.includes('Verified') 
                          ? 'text-role-signal bg-role-signal/10 border-role-signal/20' 
                          : 'text-role-danger bg-role-danger/10 border-role-danger/20'
                      }`}>{smtpStatus}</span>
                    )}
                  </div>
                </div>

                {/* Template selection */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-theme-muted mb-1.5 font-sans">Load Template</label>
                  <select
                    value={selectedTemplateId}
                    onChange={handleTemplateChange}
                    className="w-full px-3.5 py-2.5 bg-[#0A0A0D] border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent transition-colors text-theme-primary cursor-pointer"
                  >
                    <option value="">Choose a template...</option>
                    {templates.map((tpl) => (
                      <option key={tpl.id} value={tpl.id} className="text-theme-primary bg-theme-surface">
                        {tpl.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

            {/* Recipient */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="block text-xs font-semibold uppercase text-theme-muted">Recipient Email(s)</label>
                <div className="flex gap-2 text-xs font-semibold text-theme-muted">
                  <button
                    type="button"
                    onClick={() => setShowCc(!showCc)}
                    className={`hover:text-theme-accent transition-colors cursor-pointer ${showCc ? 'text-theme-accent font-bold' : ''}`}
                  >
                    {showCc ? 'Remove Cc' : '+ Cc'}
                  </button>
                  <span>|</span>
                  <button
                    type="button"
                    onClick={() => setShowBcc(!showBcc)}
                    className={`hover:text-theme-accent transition-colors cursor-pointer ${showBcc ? 'text-theme-accent font-bold' : ''}`}
                  >
                    {showBcc ? 'Remove Bcc' : '+ Bcc'}
                  </button>
                </div>
              </div>
              <EmailChipsInput
                emails={recipients}
                onChange={setRecipients}
                placeholder="name@company.com or comma separated list"
                icon={<FontAwesomeIcon icon={Mail} className="h-4 w-4" />}
              />
            </div>

            {/* CC / BCC fields */}
            {(showCc || showBcc) && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-slide-in">
                {showCc ? (
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Cc</label>
                    <EmailChipsInput
                      emails={cc}
                      onChange={setCc}
                      placeholder="cc@company.com or list"
                    />
                  </div>
                ) : <div />}
                
                {showBcc ? (
                  <div>
                    <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Bcc</label>
                    <EmailChipsInput
                      emails={bcc}
                      onChange={setBcc}
                      placeholder="bcc@company.com or list"
                    />
                  </div>
                ) : <div />}
              </div>
            )}

            {/* Subject */}
            <div>
              <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Subject Line</label>
              <input
                type="text"
                required
                placeholder="Partnership Proposal with ThunderCipher Mailer"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-4 py-2.5 bg-theme-surface border border-theme-input rounded-none text-xs font-semibold focus:outline-none focus:border-theme-accent focus:ring-2 focus:ring-theme-accent/20 transition-colors text-theme-primary"
              />
            </div>

            {/* Editor */}
            <div>
              <label className="block text-xs font-semibold uppercase text-theme-muted mb-1.5">Email Body</label>
              <RichTextEditor value={bodyHtml} onChange={setBodyHtml} placeholder="Write your outreach text here..." />
            </div>

            {/* Attachments Section */}
            <div className="border border-theme-border bg-theme-app/50 p-4 rounded-none space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-semibold uppercase text-theme-muted">File Attachments (Max 2MB)</span>
                <label className="px-3 py-1.5 bg-theme-surface border border-theme-border hover:bg-theme-hover rounded-none text-xs font-bold cursor-pointer transition-colors text-theme-secondary">
                  <span>Add File</span>
                  <input
                    type="file"
                    multiple
                    onChange={handleFileChange}
                    className="hidden"
                  />
                </label>
              </div>
              {attachments.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {attachments.map((att, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-2 rounded-none bg-theme-surface border border-theme-border text-xs text-theme-secondary animate-slide-in"
                    >
                      <div className="flex items-center gap-2 truncate">
                        <FontAwesomeIcon icon={FileText} className="h-4 w-4 text-role-creative shrink-0" />
                        <span className="text-xs truncate font-semibold">{att.filename}</span>
                        <span className="text-[10px] text-theme-muted">({(att.size / 1024).toFixed(1)} KB)</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeAttachment(idx)}
                        className="text-theme-muted hover:text-red-500 cursor-pointer transition-colors p-0.5"
                      >
                        <FontAwesomeIcon icon={X} className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Bottom Actions Row */}
            <div className="flex justify-between items-center border-t border-theme-border pt-4 mt-2">
              {/* Left Side: Schedule */}
              <div>
                <button
                  type="button"
                  onClick={triggerDatePicker}
                  className="flex items-center gap-1.5 px-3 py-2 bg-theme-surface border border-theme-input hover:bg-theme-hover rounded-none text-xs font-semibold transition-all text-theme-secondary cursor-pointer"
                  title="Schedule email delivery for later"
                >
                  <FontAwesomeIcon icon={Calendar} className="h-4 w-4" />
                  <span>{isScheduled && scheduledTime ? 'Scheduled outreach' : 'Schedule Send'}</span>
                </button>

                {isScheduled && (
                  <div className="flex items-center gap-1.5 mt-2 animate-slide-in">
                    <input
                      ref={dateInputRef}
                      type="datetime-local"
                      required
                      value={scheduledTime}
                      onChange={(e) => setScheduledTime(e.target.value)}
                      className="px-2.5 py-1.5 bg-theme-surface border border-theme-input focus:border-theme-accent focus:ring-0 rounded-none text-xs font-semibold focus:outline-none text-theme-primary"
                    />
                    <span className="text-xs font-semibold text-theme-muted">{new Date(scheduledTime).toLocaleString()}</span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsScheduled(false);
                        setScheduledTime('');
                      }}
                      className="p-1 text-theme-muted hover:text-red-500 hover:bg-red-500/10 rounded-none cursor-pointer"
                      title="Remove schedule"
                    >
                      <FontAwesomeIcon icon={X} className="h-3.5 w-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Right Side: Preview & Submit */}
              <div className="flex gap-2 w-full justify-between items-center">
                <button
                  type="button"
                  onClick={() => {
                    if (confirm("Are you sure you want to discard this draft?")) {
                      localStorage.removeItem('mailai_composer_draft');
                      setRecipients([]);
                      setCc([]);
                      setBcc([]);
                      setSubject('');
                      setBodyHtml('');
                      onClose();
                    }
                  }}
                  className="p-2 hover:bg-red-500/10 text-theme-muted hover:text-red-500 rounded-none transition-all cursor-pointer mr-auto"
                  title="Discard Draft"
                >
                  <FontAwesomeIcon icon={Trash2} className="h-4.5 w-4.5" />
                </button>

                <button
                  type="button"
                  onClick={handleRenderPreview}
                  className="flex items-center gap-1.5 px-4 py-2 bg-theme-surface border border-theme-input hover:bg-theme-hover rounded-none text-xs font-semibold transition-all text-theme-secondary cursor-pointer"
                >
                  <FontAwesomeIcon icon={Eye} className="h-4 w-4" />
                  <span>Preview</span>
                </button>

                <button
                  type="submit"
                  disabled={loading}
                  className={`flex items-center gap-1.5 px-5 py-2 bg-black border border-white hover:bg-white hover:text-black text-white font-bold rounded-none text-xs transition-all disabled:opacity-50 cursor-pointer relative uppercase tracking-wider ${isRippling ? 'animate-send-ripple' : ''}`}
                >
                  {isScheduled ? <FontAwesomeIcon icon={Clock} className="h-4 w-4" /> : <FontAwesomeIcon icon={Send} className="h-4 w-4" />}
                  <span>{loading ? 'Sending...' : isScheduled ? 'Schedule' : 'Send'}</span>
                </button>
              </div>
            </div>
          </form>

          {/* Render Preview Modal Overlay insidecomposer */}
          {showPreview && createPortal(
            <div className="modal-backdrop !z-[10005]" onClick={() => setShowPreview(false)}>
              <div 
                className="modal-content w-full max-w-xl max-h-[90vh] flex flex-col overflow-hidden relative text-left rounded-none bg-theme-surface border border-theme-border text-theme-primary shadow-2xl"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="flex justify-between items-center px-6 py-4 border-b border-theme-border shrink-0">
                  <h3 className="text-sm font-bold font-outfit uppercase tracking-wider text-theme-accent">Outreach Message Preview</h3>
                  <button
                    onClick={() => setShowPreview(false)}
                    className="p-1.5 rounded-none hover:bg-theme-hover transition-colors text-theme-muted cursor-pointer"
                  >
                    <FontAwesomeIcon icon={X} className="h-5 w-5" />
                  </button>
                </div>
                
                <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs">
                  <div>
                    <span className="font-bold text-theme-muted block uppercase text-xs mb-1">Subject</span>
                    <p className="text-theme-primary font-semibold">{previewSubject || '(Empty Subject)'}</p>
                  </div>
                  
                  <div className="border-t border-theme-border pt-3">
                    <span className="font-bold text-theme-muted block uppercase text-xs mb-2">Message Body</span>
                    <div 
                      className="prose dark:prose-invert max-w-none text-theme-secondary bg-theme-app/50 border border-theme-border p-4 rounded-none text-xs min-h-[150px] leading-relaxed"
                      dangerouslySetInnerHTML={{ __html: previewBody || '<p class="text-theme-muted italic">No Body Content Written</p>' }}
                    />
                  </div>
                </div>

                <div className="px-6 py-4 border-t border-theme-border bg-theme-app/30 flex justify-end shrink-0">
                  <button
                    onClick={() => setShowPreview(false)}
                    className="px-5 py-2 bg-theme-surface border border-theme-border hover:bg-theme-hover rounded-none text-xs font-bold transition-all text-theme-secondary cursor-pointer"
                  >
                    Close Preview
                  </button>
                </div>
              </div>
            </div>,
            document.body
          )}
        </div>
      )}
    </div>
    </>
  );
}
