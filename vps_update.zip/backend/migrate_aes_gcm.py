import asyncio
import os
import sys
import base64
import hashlib
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from sqlalchemy.future import select

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.database import SessionLocal
from app.models import SMTPAccount
from app.services.crypto import encrypt_password, decrypt_password

def legacy_decrypt_cbc(ciphertext_b64: str, key_str: str) -> str:
    """Decryption handler to recover legacy AES-256-CBC encrypted passwords."""
    if not ciphertext_b64:
        return ""
    try:
        key = hashlib.sha256(key_str.encode('utf-8')).digest()
        encrypted_bytes = base64.b64decode(ciphertext_b64.encode('utf-8'), validate=True)
        if len(encrypted_bytes) < 32:
            return ciphertext_b64
        iv = encrypted_bytes[:16]
        ciphertext = encrypted_bytes[16:]
        cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        padded_data = decryptor.update(ciphertext) + decryptor.finalize()
        pad_len = padded_data[-1]
        if pad_len < 1 or pad_len > 16:
            return ciphertext_b64
        if any(b != pad_len for b in padded_data[-pad_len:]):
            return ciphertext_b64
        return padded_data[:-pad_len].decode('utf-8')
    except Exception:
        return ciphertext_b64

async def main():
    key_str = os.environ.get("ENCRYPTION_KEY")
    if not key_str:
        print("CRITICAL SECURITY ERROR: The ENCRYPTION_KEY environment variable is not configured!")
        sys.exit(1)
        
    print("Starting database credential migration to AES-256-GCM...")
    async with SessionLocal() as session:
        smtp_query = await session.execute(select(SMTPAccount))
        smtp_accounts = smtp_query.scalars().all()
        
        migrated = 0
        for smtp in smtp_accounts:
            val = smtp.password_encrypted
            if not val:
                continue
                
            # Try to decrypt using GCM (checks if already migrated)
            decrypted = None
            try:
                decrypted = decrypt_password(val)
            except Exception:
                pass
                
            # If GCM decryption returned the raw string or failed, try legacy CBC decrypt
            if decrypted == val or decrypted is None:
                decrypted_cbc = legacy_decrypt_cbc(val, key_str)
                if decrypted_cbc != val:
                    print(f"Migrating CBC encrypted password for SMTP config '{smtp.name}'...")
                    smtp.password_encrypted = encrypt_password(decrypted_cbc)
                    session.add(smtp)
                    migrated += 1
                else:
                    # Treat as plaintext
                    print(f"Migrating plaintext password for SMTP config '{smtp.name}'...")
                    smtp.password_encrypted = encrypt_password(val)
                    session.add(smtp)
                    migrated += 1
            else:
                print(f"Password for SMTP config '{smtp.name}' is already AES-256-GCM encrypted. Skipping.")
                
        if migrated > 0:
            await session.commit()
            print(f"Successfully migrated {migrated} SMTP account passwords to AES-256-GCM.")
        else:
            print("No passwords needed migration.")

if __name__ == "__main__":
    asyncio.run(main())
