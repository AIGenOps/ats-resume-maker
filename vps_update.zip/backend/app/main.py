import logging
import asyncio
import httpx
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query, status
from fastapi.middleware.cors import CORSMiddleware

from sqlalchemy import text
from jose import jwt
from app.config import settings
from app.database import engine, Base
from app.routers import auth, contacts, templates, campaigns, smtp, dashboard, mailbox, settings_api

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Backend API for Enterprise Email Outreach CRM",
    version="1.0"
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        settings.FRONTEND_URL,
        "http://localhost:777",
        "http://localhost:5173",
        "http://127.0.0.1:777",
        "http://127.0.0.1:5173"
    ] if settings.FRONTEND_URL else [
        "http://localhost:777",
        "http://localhost:5173",
        "http://127.0.0.1:777",
        "http://127.0.0.1:5173"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API Routers
app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(contacts.router, prefix=settings.API_V1_STR)
app.include_router(templates.router, prefix=settings.API_V1_STR)
app.include_router(campaigns.router, prefix=settings.API_V1_STR)
app.include_router(smtp.router, prefix=settings.API_V1_STR)
app.include_router(dashboard.router, prefix=settings.API_V1_STR)
app.include_router(mailbox.router, prefix=settings.API_V1_STR)
app.include_router(settings_api.router, prefix=settings.API_V1_STR)

from app.services.websocket import manager

@app.websocket("/api/v1/mailbox/ws")
async def websocket_endpoint(websocket: WebSocket, token: str = Query(...)):
    # Authenticate handshake requests
    try:
        from jose import JWTError
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=["HS256"])
        user_id = payload.get("sub")
        if user_id is None:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
            return
    except JWTError:
        await websocket.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    await manager.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.warning(f"WebSocket connection error: {e}")
        manager.disconnect(websocket)

@app.on_event("shutdown")
async def on_shutdown():
    logger.info("Closing persistent HTTP connection client...")
    if hasattr(app.state, "client"):
        await app.state.client.aclose()

@app.on_event("startup")
async def on_startup():
    logger.info("Initializing persistent HTTP client pool...")
    app.state.client = httpx.AsyncClient()
    logger.info("Initializing database tables...")
    # This automatically creates database tables in SQLite/PostgreSQL on startup!
    # A very convenient feature for onboarding without manual migration commands.
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        
        # Auto-migration: check and alter table for campaigns new columns
        try:
            is_sqlite = "sqlite" in str(engine.url)
            if is_sqlite:
                cursor = await conn.execute(text("PRAGMA table_info(campaigns)"))
                columns = [row[1] for row in cursor.fetchall()]
            else:
                cursor = await conn.execute(
                    text("SELECT column_name FROM information_schema.columns WHERE table_name='campaigns'")
                )
                columns = [row[0] for row in cursor.fetchall()]
                
            new_cols = {
                "send_delay_seconds": ("INTEGER", "1"),
                "batch_size": ("INTEGER", "50"),
                "stop_on_reply": ("BOOLEAN", "1"),
                "max_retries": ("INTEGER", "3"),
                "track_opens": ("BOOLEAN", "0"),
                "weekdays_only": ("BOOLEAN", "1"),
                "send_window_start": ("VARCHAR(5)", "'09:00'"),
                "send_window_end": ("VARCHAR(5)", "'17:00'"),
                "warmup_enabled": ("BOOLEAN", "0"),
                "warmup_start_limit": ("INTEGER", "10"),
                "warmup_increment": ("INTEGER", "5"),
                "target_tag_id": ("VARCHAR(36)", "NULL")
            }
            
            for col_name, (col_type, default_val) in new_cols.items():
                if col_name not in columns:
                    logger.info(f"Adding column '{col_name}' to table 'campaigns'...")
                    await conn.execute(text(f"ALTER TABLE campaigns ADD COLUMN {col_name} {col_type} DEFAULT {default_val}"))
                    
            # Auto-migration for email_queue table (opened / opened_at)
            if is_sqlite:
                eq_cursor = await conn.execute(text("PRAGMA table_info(email_queue)"))
                eq_columns = [row[1] for row in eq_cursor.fetchall()]
            else:
                eq_cursor = await conn.execute(
                    text("SELECT column_name FROM information_schema.columns WHERE table_name='email_queue'")
                )
                eq_columns = [row[0] for row in eq_cursor.fetchall()]
                
            eq_new_cols = {
                "opened": ("BOOLEAN", "0"),
                "opened_at": ("TIMESTAMP", "NULL"),
                "smtp_id": ("VARCHAR(36)", "NULL")
            }
            
            for col_name, (col_type, default_val) in eq_new_cols.items():
                if col_name not in eq_columns:
                    logger.info(f"Adding column '{col_name}' to table 'email_queue'...")
                    await conn.execute(text(f"ALTER TABLE email_queue ADD COLUMN {col_name} {col_type} DEFAULT {default_val}"))
                    
        except Exception as migration_err:
            logger.error(f"Auto-migration check warning: {migration_err}")
            
    logger.info("Database initialized successfully.")
    
    # Auto-seed default administrators if no user accounts exist
    try:
        from app.database import SessionLocal
        from app.models import User
        from sqlalchemy.future import select
        async with SessionLocal() as session:
            user_query = await session.execute(select(User))
            if not user_query.scalars().first():
                logger.info("No user accounts found in database. Seeding default administrators...")
                admin1 = User(
                    id="733e48e9-ccb4-43bf-8e0f-79ea83f14271",
                    full_name="Grace Harper",
                    username="apokrypth",
                    email="teams@thundercipher.in",
                    hashed_password="$2b$12$bGxWh5.bhvI1WB0SBvqgCe83Mq1eNCyECy2SpXsePAeZeHCUi5PeG",
                    role="super_admin",
                    status="active"
                )
                admin2 = User(
                    id="0f465247-4b69-46b2-9495-330ceb6d6f76",
                    full_name="Anoop",
                    username="anoop",
                    email="anoop@thundercipher.in",
                    hashed_password="$2b$12$84YksASyIcfR2CdE6wb0Ue9FN/RWqL2PM5HlCx9.STHwcWXlRzZ9W",
                    role="super_admin",
                    status="active"
                )
                session.add_all([admin1, admin2])
                await session.commit()
                logger.info("Default administrators (apokrypth, anoop) seeded successfully.")
    except Exception as seed_err:
        logger.error(f"Error seeding default administrators: {seed_err}")

    # Auto-migrate existing plaintext SMTP passwords to AES-256
    try:
        from app.database import SessionLocal
        from app.models import SMTPAccount
        from app.services.crypto import encrypt_password, decrypt_password
        async with SessionLocal() as session:
            smtp_query = await session.execute(select(SMTPAccount))
            smtp_accounts = smtp_query.scalars().all()
            for smtp in smtp_accounts:
                raw_val = smtp.password_encrypted
                if raw_val and decrypt_password(raw_val) == raw_val:
                    # Password is currently plaintext, encrypt it!
                    smtp.password_encrypted = encrypt_password(raw_val)
                    session.add(smtp)
            await session.commit()
            logger.info("SMTP password encryption migration completed successfully.")
    except Exception as migration_err:
        logger.error(f"Failed to migrate SMTP passwords: {migration_err}")

    asyncio.create_task(scheduled_email_sender_loop())

async def check_imap_replies_main(db):
    try:
        from app.models import SMTPAccount, Contact, ContactReply, Conversation, Message, ContactNote
        from app.worker import poll_imap_inbox_sync
        from app.services.discord import send_discord_reply_notification
        from app.services.websocket import manager
        from app.database import get_ist_time
        from sqlalchemy.future import select
        
        # Get active gateways with IMAP settings configured
        smtp_res = await db.execute(
            select(SMTPAccount).where(
                SMTPAccount.is_active == True,
                SMTPAccount.imap_host != None,
                SMTPAccount.imap_host != ""
            )
        )
        gateways = smtp_res.scalars().all()
        if not gateways:
            return

        for gw in gateways:
            try:
                from app.services.crypto import decrypt_password
                decrypted_pw = decrypt_password(gw.password_encrypted)
                loop = asyncio.get_event_loop()
                replies = await loop.run_in_executor(
                    None,
                    poll_imap_inbox_sync,
                    gw.imap_host,
                    gw.imap_port or 993,
                    gw.username,
                    decrypted_pw
                )
                
                for from_addr, subject, snippet, body_content in replies:
                    if not from_addr:
                        continue
                    
                    contact_res = await db.execute(
                        select(Contact).where(Contact.email.ilike(from_addr.strip()))
                    )
                    contact = contact_res.scalars().first()
                    
                    if not contact:
                        continue
                    else:
                        contact.status = "replied"
                        
                    # Check duplicate reply
                    dup_res = await db.execute(
                        select(ContactReply).where(
                            ContactReply.contact_id == contact.id,
                            ContactReply.subject == subject,
                            ContactReply.snippet == snippet
                        )
                    )
                    if dup_res.scalars().first():
                        continue
                        
                    reply_obj = ContactReply(
                        contact_id=contact.id,
                        subject=subject,
                        snippet=snippet,
                        received_at=get_ist_time()
                    )
                    db.add(reply_obj)

                    # Match thread by clean subject
                    clean_subj = subject
                    for prefix in ["Re: ", "re: ", "RE: ", "Fwd: ", "fwd: ", "FWD: ", "Re:", "re:", "RE:", "Fwd:", "fwd:", "FWD:"]:
                        clean_subj = clean_subj.replace(prefix, "")
                    clean_subj = clean_subj.strip()

                    conv_res = await db.execute(
                        select(Conversation).where(
                            Conversation.contact_id == contact.id,
                            Conversation.subject.ilike(clean_subj)
                        )
                    )
                    conversation = conv_res.scalars().first()
                    if not conversation:
                        conversation = Conversation(
                            contact_id=contact.id,
                            subject=clean_subj,
                            status="replied"
                        )
                        db.add(conversation)
                        await db.flush()
                    else:
                        conversation.status = "replied"
                        conversation.updated_at = get_ist_time()

                    msg_obj = Message(
                        conversation_id=conversation.id,
                        sender=from_addr.strip(),
                        recipient=gw.from_email,
                        subject=subject,
                        body=body_content,
                        is_incoming=True,
                        is_unread=True,
                        created_at=get_ist_time()
                    )
                    db.add(msg_obj)
                    
                    note = ContactNote(
                        contact_id=contact.id,
                        author_name="System IMAP Poller",
                        content=f"Received reply via IMAP: '{subject}'. Body: {snippet[:150]}..."
                    )
                    db.add(note)
                    
                    # Dispatch Discord notification
                    try:
                        await send_discord_reply_notification(
                            contact_name=contact.full_name or "Unknown Contact",
                            contact_email=contact.email,
                            subject=subject,
                            snippet=snippet
                        )
                    except Exception:
                        pass
                    
                    # Dispatch Websocket notification
                    try:
                        asyncio.create_task(manager.broadcast({
                            "type": "new_email",
                            "contact_name": contact.full_name or "Unknown Contact",
                            "contact_email": contact.email,
                            "subject": subject,
                            "snippet": snippet[:150]
                        }))
                    except Exception:
                        pass
                        
                await db.commit()
            except Exception as e:
                logger.error(f"IMAP check failed for gateway {gw.name}: {e}")
    except Exception as e:
        logger.error(f"IMAP loop checking error: {e}")


async def scheduled_email_sender_loop():
    logger.info("Starting local scheduled email sender background loop...")
    await asyncio.sleep(10)
    from datetime import datetime, timezone, timedelta, time
    from sqlalchemy.future import select
    from sqlalchemy import func
    from app.database import SessionLocal, get_ist_time
    from app.models import EmailQueue, SMTPAccount, Campaign, Contact, Conversation, Message, ContactNote
    from app.services.email_provider import SmtpEmailProvider
    
    provider = SmtpEmailProvider()
    imap_counter = 0
    while True:
        try:
            async with SessionLocal() as db:
                now = get_ist_time()
                
                # Check IMAP replies every 60 seconds (every 4 loops of 15 seconds)
                imap_counter += 1
                if imap_counter >= 4:
                    imap_counter = 0
                    await check_imap_replies_main(db)
                
                # 1. Process Direct scheduled emails (campaign_id == None)
                direct_res = await db.execute(
                    select(EmailQueue)
                    .where(
                        (EmailQueue.status == "pending") & 
                        (EmailQueue.scheduled_time != None) & 
                        (EmailQueue.scheduled_time <= now) &
                        (EmailQueue.campaign_id == None)
                    )
                )
                direct_items = direct_res.scalars().all()
                for item in direct_items:
                    logger.info(f"Processing scheduled direct email ID {item.id} to {item.recipient_email}...")
                    
                    host = settings.SMTP_HOST
                    port = settings.SMTP_PORT
                    username = settings.SMTP_USER
                    password = settings.SMTP_PASSWORD
                    from_email = settings.SMTP_FROM_EMAIL
                    smtp_name = "Default config"
                    
                    if item.smtp_id:
                        smtp_res = await db.execute(select(SMTPAccount).where(SMTPAccount.id == item.smtp_id))
                        smtp = smtp_res.scalars().first()
                        if smtp:
                            from app.services.crypto import decrypt_password
                            host = smtp.host
                            port = smtp.port
                            username = smtp.username
                            password = decrypt_password(smtp.password_encrypted)
                            from_email = smtp.from_email
                            smtp_name = smtp.name
                            
                    try:
                        item.status = "sending"
                        await db.commit()
                        
                        unsub_token = jwt.encode({"sub": item.recipient_email, "type": "unsubscribe"}, settings.JWT_SECRET, algorithm="HS256")
                        unsub_url = f"{settings.BACKEND_URL}/api/v1/campaigns/unsubscribe?token={unsub_token}"
                        
                        await provider.send_email(
                            recipient_email=item.recipient_email,
                            subject=item.subject,
                            body=item.body,
                            sender_email=from_email,
                            host=host,
                            port=port,
                            username=username,
                            password=password,
                            validate_certs=False,
                            sender_name=smtp_name,
                            list_unsubscribe=unsub_url
                        )
                        
                        item.status = "sent"
                        item.sent_time = get_ist_time()
                        
                        contact_res = await db.execute(
                            select(Contact).where(Contact.email.ilike(item.recipient_email.strip()))
                        )
                        contact = contact_res.scalars().first()
                        if not contact:
                            contact = Contact(
                                full_name=item.recipient_email.split("@")[0].capitalize(),
                                email=item.recipient_email.strip(),
                                status="active",
                                source="incoming"
                            )
                            db.add(contact)
                            await db.flush()
                        
                        clean_subj = item.subject
                        for prefix in ["Re: ", "re: ", "RE: ", "Fwd: ", "fwd: ", "FWD: ", "Re:", "re:", "RE:", "Fwd:", "fwd:", "FWD:"]:
                            clean_subj = clean_subj.replace(prefix, "")
                        clean_subj = clean_subj.strip()
                        
                        conv_res = await db.execute(
                            select(Conversation).where(
                                Conversation.contact_id == contact.id,
                                Conversation.subject.ilike(clean_subj)
                            )
                        )
                        conversation = conv_res.scalars().first()
                        if not conversation:
                            conversation = Conversation(
                                contact_id=contact.id,
                                subject=clean_subj,
                                status="waiting"
                            )
                            db.add(conversation)
                            await db.flush()
                        else:
                            conversation.status = "waiting"
                            conversation.updated_at = get_ist_time()
                            
                        msg_obj = Message(
                            conversation_id=conversation.id,
                            sender=from_email,
                            recipient=item.recipient_email,
                            subject=item.subject,
                            body=item.body,
                            is_incoming=False,
                            is_unread=False,
                            created_at=get_ist_time()
                        )
                        db.add(msg_obj)
                        
                        await db.commit()
                        logger.info(f"Scheduled direct email ID {item.id} successfully sent.")
                    except Exception as send_err:
                        item.status = "failed"
                        item.error_message = str(send_err)
                        await db.commit()
                        logger.error(f"Failed to send scheduled direct email ID {item.id}: {send_err}")
                
                # 2. Process Running Campaign emails (campaign_id != None where campaign status is "running")
                campaigns_res = await db.execute(
                    select(Campaign).where(Campaign.status == "running")
                )
                running_campaigns = campaigns_res.scalars().all()
                
                for campaign in running_campaigns:
                    IST = timezone(timedelta(hours=5, minutes=30))
                    now_ist = datetime.now(IST)
                    
                    # A. Weekdays only constraint
                    if campaign.weekdays_only and now_ist.weekday() >= 5:
                        logger.info(f"Campaign {campaign.id} ({campaign.name}): Weekend detected and weekdays_only is enabled. Skipping.")
                        continue
                        
                    # B. Hour window constraint
                    if campaign.send_window_start and campaign.send_window_end:
                        current_time_str = now_ist.strftime("%H:%M")
                        if not (campaign.send_window_start <= current_time_str <= campaign.send_window_end):
                            logger.info(f"Campaign {campaign.id} ({campaign.name}): Current time ({current_time_str} IST) outside window ({campaign.send_window_start} - {campaign.send_window_end}). Skipping.")
                            continue
                            
                    # C. Warmup daily limit constraint
                    if campaign.warmup_enabled:
                        ist_today_start = datetime.combine(now_ist.date(), time.min).replace(tzinfo=IST)
                        today_start = ist_today_start.astimezone(timezone.utc).replace(tzinfo=None)
                        sent_today_res = await db.execute(
                            select(func.count(EmailQueue.id)).where(
                                EmailQueue.campaign_id == campaign.id,
                                EmailQueue.status == "sent",
                                EmailQueue.sent_time >= today_start
                            )
                        )
                        sent_today = sent_today_res.scalar() or 0
                        
                        days_elapsed = 0
                        if campaign.start_date:
                            start_date_ist = campaign.start_date.replace(tzinfo=timezone.utc).astimezone(IST).date()
                            days_elapsed = (now_ist.date() - start_date_ist).days
                            if days_elapsed < 0:
                                days_elapsed = 0
                        
                        limit_today = campaign.warmup_start_limit + (days_elapsed * campaign.warmup_increment)
                        if sent_today >= limit_today:
                            logger.info(f"Campaign {campaign.id} ({campaign.name}): Warmup daily limit reached ({sent_today}/{limit_today}). Skipping.")
                            continue
                            
                    # D. Delay since last sent constraint
                    if campaign.send_delay_seconds is not None and campaign.send_delay_seconds > 0:
                        last_sent_res = await db.execute(
                            select(EmailQueue.sent_time)
                            .where(
                                EmailQueue.campaign_id == campaign.id,
                                EmailQueue.status == "sent"
                            )
                            .order_by(EmailQueue.sent_time.desc())
                            .limit(1)
                        )
                        last_sent_time = last_sent_res.scalar()
                        if last_sent_time:
                            elapsed = (now - last_sent_time).total_seconds()
                            if elapsed < campaign.send_delay_seconds:
                                logger.info(f"Campaign {campaign.id} ({campaign.name}): Send delay check failed ({elapsed:.1f}s < {campaign.send_delay_seconds}s). Skipping.")
                                continue
                                
                    # If all constraints passed, retrieve ONE pending email for this campaign
                    item_res = await db.execute(
                        select(EmailQueue)
                        .where(
                            (EmailQueue.campaign_id == campaign.id) &
                            (EmailQueue.status == "pending")
                        )
                        .limit(1)
                    )
                    item = item_res.scalars().first()
                    if not item:
                        # Check if campaign is completely processed
                        remaining_q = select(func.count(EmailQueue.id)).where(
                            EmailQueue.campaign_id == campaign.id,
                            EmailQueue.status.in_(["pending", "sending"])
                        )
                        remaining_res = await db.execute(remaining_q)
                        remaining_count = remaining_res.scalar() or 0
                        
                        if remaining_count == 0:
                            campaign.status = "completed"
                            campaign.end_date = get_ist_time()
                            
                            # Fetch summary counts
                            sent_q = select(func.count(EmailQueue.id)).where(
                                EmailQueue.campaign_id == campaign.id,
                                EmailQueue.status == "sent"
                            )
                            failed_q = select(func.count(EmailQueue.id)).where(
                                EmailQueue.campaign_id == campaign.id,
                                EmailQueue.status == "failed"
                            )
                            sent_res = await db.execute(sent_q)
                            failed_res = await db.execute(failed_q)
                            sent_val = sent_res.scalar() or 0
                            failed_val = failed_res.scalar() or 0
                            
                            try:
                                from app.services.discord import dispatch_campaign_summary_notification
                                # Find campaign sender to determine gateway name
                                smtp_name = "Default config"
                                if campaign.sender:
                                    smtp_res = await db.execute(select(SMTPAccount).where(SMTPAccount.id == campaign.sender))
                                    smtp = smtp_res.scalars().first()
                                    if smtp:
                                        smtp_name = smtp.name
                                await dispatch_campaign_summary_notification(
                                    campaign_name=campaign.name,
                                    sent_count=sent_val,
                                    failed_count=failed_val,
                                    gateway_name=smtp_name,
                                    subject=campaign.name  # fallback subject
                                )
                            except Exception as notify_err:
                                logger.error(f"Failed to dispatch Discord campaign summary: {str(notify_err)}")
                                
                            await db.commit()
                            logger.info(f"Campaign {campaign.id} ({campaign.name}) completed.")
                        continue
                        
                    logger.info(f"Processing campaign email ID {item.id} to {item.recipient_email}...")
                    
                    # Fetch SMTP details
                    host = settings.SMTP_HOST
                    port = settings.SMTP_PORT
                    username = settings.SMTP_USER
                    password = settings.SMTP_PASSWORD
                    from_email = settings.SMTP_FROM_EMAIL
                    smtp_name = "Default config"
                    
                    if campaign.sender:
                        smtp_res = await db.execute(select(SMTPAccount).where(SMTPAccount.id == campaign.sender))
                        smtp = smtp_res.scalars().first()
                        if smtp:
                            from app.services.crypto import decrypt_password
                            host = smtp.host
                            port = smtp.port
                            username = smtp.username
                            password = decrypt_password(smtp.password_encrypted)
                            from_email = smtp.from_email
                            smtp_name = smtp.name
                            
                    # Check unsubscribe and stop_on_reply status
                    contact_res = await db.execute(
                        select(Contact).where(Contact.email.ilike(item.recipient_email.strip()))
                    )
                    contact = contact_res.scalars().first()
                    if contact:
                        if contact.status == "unsubscribed":
                            logger.info(f"Recipient {item.recipient_email} unsubscribed. Skipping queue item {item.id}.")
                            item.status = "failed"
                            item.error_message = "Recipient unsubscribed"
                            await db.commit()
                            continue
                        if contact.status == "replied" and campaign.stop_on_reply:
                            logger.info(f"Recipient {item.recipient_email} has replied and stop_on_reply is enabled. Skipping queue item {item.id}.")
                            item.status = "failed"
                            item.error_message = "Recipient replied"
                            await db.commit()
                            continue
                        
                    try:
                        item.status = "sending"
                        await db.commit()
                        
                        unsub_token = jwt.encode({"sub": item.recipient_email, "type": "unsubscribe"}, settings.JWT_SECRET, algorithm="HS256")
                        unsub_url = f"{settings.BACKEND_URL}/api/v1/campaigns/unsubscribe?token={unsub_token}"
                        
                        body_html = item.body
                        unsub_link_html = f'<br/><br/><hr style="border:0;border-top:1px solid rgba(255,255,255,0.08);margin:20px 0;"/><p style="font-size:11px;color:#8a93a6;text-align:center;">If you no longer wish to receive these communications, you can <a href="{unsub_url}" style="color:#00b5ad;text-decoration:underline;">unsubscribe here</a>.</p>'
                        if "</body>" in body_html:
                            body_html = body_html.replace("</body>", f"{unsub_link_html}</body>")
                        else:
                            body_html += unsub_link_html
                            
                        if campaign.track_opens:
                            pixel_url = f"{settings.BACKEND_URL}/api/v1/campaigns/track/{item.id}"
                            pixel_img = f'<img src="{pixel_url}" width="1" height="1" style="display:none !important;" alt="" />'
                            if "</body>" in body_html:
                                body_html = body_html.replace("</body>", f"{pixel_img}</body>")
                            else:
                                body_html += pixel_img
                                
                        await provider.send_email(
                            recipient_email=item.recipient_email,
                            subject=item.subject,
                            body=body_html,
                            sender_email=from_email,
                            host=host,
                            port=port,
                            username=username,
                            password=password,
                            validate_certs=False,
                            sender_name=smtp_name,
                            list_unsubscribe=unsub_url
                        )
                        
                        item.status = "sent"
                        item.sent_time = get_ist_time()
                        
                        if contact:
                            clean_subj = item.subject
                            for prefix in ["Re: ", "re: ", "RE: ", "Fwd: ", "fwd: ", "FWD: ", "Re:", "re:", "RE:", "Fwd:", "fwd:", "FWD:"]:
                                clean_subj = clean_subj.replace(prefix, "")
                            clean_subj = clean_subj.strip()
                            
                            conv_res = await db.execute(
                                select(Conversation).where(
                                    Conversation.contact_id == contact.id,
                                    Conversation.subject.ilike(clean_subj)
                                )
                            )
                            conversation = conv_res.scalars().first()
                            if not conversation:
                                conversation = Conversation(
                                    contact_id=contact.id,
                                    subject=clean_subj,
                                    status="waiting"
                                )
                                db.add(conversation)
                                await db.flush()
                            else:
                                conversation.updated_at = get_ist_time()
                                
                            msg_obj = Message(
                                conversation_id=conversation.id,
                                sender=from_email,
                                recipient=item.recipient_email,
                                subject=item.subject,
                                body=item.body,
                                is_incoming=False,
                                is_unread=False,
                                created_at=get_ist_time()
                            )
                            db.add(msg_obj)
                            
                            note = ContactNote(
                                contact_id=contact.id,
                                author_name="System Scheduler",
                                content=f"Campaign email successfully delivered via gateway '{smtp_name}': {item.subject}"
                            )
                            db.add(note)
                            
                        await db.commit()
                        logger.info(f"Campaign email ID {item.id} successfully sent.")
                    except Exception as send_err:
                        item.status = "failed"
                        item.error_message = str(send_err)
                        
                        from app.models import AuditLog
                        audit = AuditLog(
                            user_id=campaign.owner_id if campaign else None,
                            action="SMTP Scheduler Failure",
                            details=f"Queue send failed to {item.recipient_email} using gateway '{smtp_name}'. Error: {str(send_err)}"
                        )
                        db.add(audit)
                        await db.commit()
                        logger.error(f"Failed to send campaign email ID {item.id}: {send_err}")
                        
        except Exception as e:
            logger.error(f"Scheduled email loop error: {e}")
        await asyncio.sleep(15)

@app.get("/")
async def root():
    return {
        "message": f"Welcome to {settings.PROJECT_NAME} API. Access API docs at /docs."
    }

@app.get("/health")
async def health_check():
    return {
        "status": "online",
        "service": settings.PROJECT_NAME,
        "database": "connected"
    }
