import os
import base64
import hashlib
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

def get_encryption_key() -> bytes:
    """
    Retrieves the encryption key from the ENCRYPTION_KEY environment variable.
    Raises ValueError if the environment variable is missing.
    """
    key_str = os.environ.get("ENCRYPTION_KEY")
    if not key_str:
        raise ValueError("CRITICAL SECURITY ERROR: The ENCRYPTION_KEY environment variable is not configured!")
    return hashlib.sha256(key_str.encode('utf-8')).digest()

def encrypt_password(plaintext: str) -> str:
    """
    Encrypts a plaintext string using AES-256-GCM.
    Returns a Base64 encoded string containing the 12-byte random Nonce, 
    the 16-byte authentication Tag, and the ciphertext.
    """
    if not plaintext:
        return ""
    
    key = get_encryption_key()
    nonce = os.urandom(12)  # GCM standard nonce size
    cipher = Cipher(algorithms.AES(key), modes.GCM(nonce), backend=default_backend())
    encryptor = cipher.encryptor()
    
    ciphertext = encryptor.update(plaintext.encode('utf-8')) + encryptor.finalize()
    tag = encryptor.tag
    
    # Store combined format: nonce + tag + ciphertext
    encrypted_bytes = nonce + tag + ciphertext
    return base64.b64encode(encrypted_bytes).decode('utf-8')

def decrypt_password(ciphertext_b64: str) -> str:
    """
    Decrypts a Base64 encoded AES-256-GCM ciphertext string.
    If decryption fails or input is invalid (e.g. if the input is 
    unencrypted plaintext), the raw input string is returned.
    """
    if not ciphertext_b64:
        return ""
    
    try:
        # Check if the string is valid Base64
        encrypted_bytes = base64.b64decode(ciphertext_b64.encode('utf-8'), validate=True)
        if len(encrypted_bytes) < 28:  # 12 bytes Nonce + 16 bytes Tag
            return ciphertext_b64
            
        nonce = encrypted_bytes[:12]
        tag = encrypted_bytes[12:28]
        ciphertext = encrypted_bytes[28:]
        
        key = get_encryption_key()
        cipher = Cipher(algorithms.AES(key), modes.GCM(nonce, tag), backend=default_backend())
        decryptor = cipher.decryptor()
        
        plaintext_bytes = decryptor.update(ciphertext) + decryptor.finalize()
        return plaintext_bytes.decode('utf-8')
    except Exception:
        # Fallback to returning raw string if any error occurs (e.g. plaintext fallback)
        return ciphertext_b64
