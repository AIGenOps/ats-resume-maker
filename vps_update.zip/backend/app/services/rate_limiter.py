import time
from fastapi import Request, HTTPException, status

class InMemoryRateLimiter:
    def __init__(self, requests_limit: int = 5, window_seconds: int = 60):
        self.requests_limit = requests_limit
        self.window_seconds = window_seconds
        # Dictionary mapping IP -> list of timestamps
        self.history = {}

    def check_rate_limit(self, request: Request):
        client_ip = request.client.host if request.client else "unknown"
        now = time.time()
        
        # Initialize or clean history for this IP
        if client_ip not in self.history:
            self.history[client_ip] = []
            
        # Keep only timestamps within the current window
        self.history[client_ip] = [t for t in self.history[client_ip] if now - t < self.window_seconds]
        
        if len(self.history[client_ip]) >= self.requests_limit:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many login attempts. Please try again later."
            )
            
        # Log this attempt
        self.history[client_ip].append(now)

login_rate_limiter = InMemoryRateLimiter(requests_limit=5, window_seconds=60)
