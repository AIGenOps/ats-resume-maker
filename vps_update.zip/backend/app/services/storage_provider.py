from abc import ABC, abstractmethod
import os
import aiofiles
from app.config import settings

class StorageProvider(ABC):
    @abstractmethod
    async def save_file(self, file_name: str, file_content: bytes) -> str:
        """Saves file content and returns local path or access URL."""
        pass

class LocalStorageProvider(StorageProvider):
    def __init__(self):
        os.makedirs(settings.LOCAL_STORAGE_DIR, exist_ok=True)

    async def save_file(self, file_name: str, file_content: bytes) -> str:
        # Prevent directory traversal attacks
        base_name = os.path.basename(file_name)
        target_path = os.path.join(settings.LOCAL_STORAGE_DIR, base_name)
        
        async with aiofiles.open(target_path, "wb") as f:
            await f.write(file_content)
            
        return target_path
