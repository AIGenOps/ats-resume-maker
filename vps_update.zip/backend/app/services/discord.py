import httpx
import logging
from datetime import datetime, timezone, timedelta
from app.config import settings

logger = logging.getLogger("app.services.discord")

async def send_discord_post(url: str, payload: dict) -> None:
    if not url:
        return
    try:
        async with httpx.AsyncClient() as client:
            res = await client.post(url, json=payload)
            if res.status_code >= 400:
                logger.error(f"Failed to post to Discord Webhook. Status: {res.status_code}, Body: {res.text}")
    except Exception as e:
        logger.error(f"Exception during Discord Webhook push: {str(e)}")

def resolve_webhook_and_category(subject: str, default_suffix: str) -> tuple:
    """
    Looks up custom categories to match keywords in the subject.
    Falls back to the general mails webhook.
    """
    subject_lower = (subject or "").lower()
    custom_cats = getattr(settings, "CUSTOM_CATEGORIES", [])
    
    for cat in custom_cats:
        cat_name = cat.get("name", "")
        # Remove common words and check keywords
        clean_name = cat_name.replace("mails", "").replace("outreach", "").replace("sent", "").replace("received", "")
        keywords = [kw.strip().lower() for kw in clean_name.split() if len(kw.strip()) > 2]
        if not keywords:
            keywords = [cat_name.lower()]
            
        if any(kw in subject_lower for kw in keywords if kw) and cat.get("url"):
            return cat.get("url"), f"{cat_name} {default_suffix}"
            
    return settings.GENERAL_MAILS_WEBHOOK, f"General {default_suffix}"

async def dispatch_email_sent_notification(
    recipient_email: str,
    subject: str,
    gateway_name: str
) -> None:
    """
    Routes and dispatches a notification when an email is successfully sent.
    Matches keywords in the subject line to direct notifications to the correct channel.
    """
    url, category = resolve_webhook_and_category(subject, "Sent")
    if not url:
        logger.info(f"No specific Discord webhook matched or configured for subject: '{subject}'. Skipping notification.")
        return

    payload = {
        "embeds": [
            {
                "title": f"🚀 {category}",
                "color": 3066993,  # Green: #2ECC71 -> Decimal: 3066993
                "fields": [
                    {"name": "Recipient Email", "value": recipient_email, "inline": True},
                    {"name": "SMTP Gateway", "value": gateway_name, "inline": True},
                    {"name": "Subject Line", "value": subject or "(No Subject)", "inline": False}
                ],
                "timestamp": datetime.now(timezone(timedelta(hours=5, minutes=30))).isoformat(),
                "footer": {
                    "text": "ThunderCipher Mailer Notification Agent"
                }
            }
        ]
    }
    await send_discord_post(url, payload)

async def dispatch_email_failed_notification(
    recipient_email: str,
    subject: str,
    error_msg: str,
    gateway_name: str
) -> None:
    """
    Dispatches a notification to the failed mails webhook when a sending transaction fails.
    """
    url = settings.FAILED_MAILS_WEBHOOK
    if not url:
        logger.warning("FAILED_MAILS_WEBHOOK not configured. Skipping failure alert.")
        return

    payload = {
        "embeds": [
            {
                "title": "🚨 Outreach Send Failed!",
                "color": 15158332,  # Red: #E74C3C -> Decimal: 15158332
                "fields": [
                    {"name": "Recipient Email", "value": recipient_email, "inline": True},
                    {"name": "SMTP Gateway", "value": gateway_name, "inline": True},
                    {"name": "Subject Line", "value": subject or "(No Subject)", "inline": False},
                    {"name": "Error Details", "value": error_msg[:1000] or "Unknown Error", "inline": False}
                ],
                "timestamp": datetime.now(timezone(timedelta(hours=5, minutes=30))).isoformat(),
                "footer": {
                    "text": "ThunderCipher Mailer Alert System"
                }
            }
        ]
    }
    await send_discord_post(url, payload)

async def send_discord_reply_notification(
    contact_name: str,
    contact_email: str,
    subject: str,
    snippet: str
) -> None:
    """
    Routes and dispatches a notification when a reply is received from a contact.
    Matches keywords in the subject line to direct notifications to the correct channel.
    """
    url, category = resolve_webhook_and_category(subject, "Reply Received")
    if not url:
        logger.info(f"No Discord webhook configured for reply subject: '{subject}'. Skipping.")
        return

    payload = {
        "embeds": [
            {
                "title": f"📥 {category}",
                "color": 3447003,  # Blue: #3498DB -> Decimal: 3447003
                "fields": [
                    {"name": "Contact Name", "value": contact_name, "inline": True},
                    {"name": "Contact Email", "value": contact_email, "inline": True},
                    {"name": "Subject Line", "value": subject or "(No Subject)", "inline": False},
                    {"name": "Snippet", "value": snippet[:1000] or "(Empty)", "inline": False}
                ],
                "timestamp": datetime.now(timezone(timedelta(hours=5, minutes=30))).isoformat(),
                "footer": {
                    "text": "ThunderCipher Mailer Reply Detector"
                }
            }
        ]
    }
    await send_discord_post(url, payload)

async def dispatch_campaign_summary_notification(
    campaign_name: str,
    sent_count: int,
    failed_count: int,
    gateway_name: str,
    subject: str
) -> None:
    """
    Dispatches a single summary notification for a batch campaign delivery.
    """
    url, category = resolve_webhook_and_category(subject, "Campaign Summary")
    if not url:
        logger.info(f"No Discord webhook configured for summary subject: '{subject}'. Skipping.")
        return

    payload = {
        "embeds": [
            {
                "title": f"📊 {category}",
                "color": 3447003,  # Blue: #3498DB
                "fields": [
                    {"name": "Campaign Name", "value": campaign_name, "inline": True},
                    {"name": "SMTP Gateway", "value": gateway_name, "inline": True},
                    {"name": "Total Target Contacts", "value": str(sent_count + failed_count), "inline": False},
                    {"name": "Sent Successfully", "value": f"🟢 {sent_count}", "inline": True},
                    {"name": "Failed Sends", "value": f"🔴 {failed_count}", "inline": True}
                ],
                "timestamp": datetime.now(timezone(timedelta(hours=5, minutes=30))).isoformat(),
                "footer": {
                    "text": "ThunderCipher Mailer Campaign Manager"
                }
            }
        ]
    }
    await send_discord_post(url, payload)

async def dispatch_direct_send_summary_notification(
    sent_count: int,
    failed_count: int,
    gateway_name: str,
    subject: str,
    recipients_list: list
) -> None:
    """
    Dispatches a single summary notification for a direct send execution.
    """
    url, category = resolve_webhook_and_category(subject, "Direct Dispatch")
    if not url:
        logger.info(f"No Discord webhook configured for direct summary: '{subject}'. Skipping.")
        return

    recipients_str = ", ".join(recipients_list)
    if len(recipients_str) > 1024:
        recipients_str = recipients_str[:1020] + "..."

    payload = {
        "embeds": [
            {
                "title": f"⚡ {category}",
                "color": 3066993,  # Green: #2ECC71
                "fields": [
                    {"name": "Subject Line", "value": subject or "(No Subject)", "inline": False},
                    {"name": "SMTP Gateway", "value": gateway_name, "inline": True},
                    {"name": "Total Target Recipients", "value": str(sent_count + failed_count), "inline": True},
                    {"name": "Sent Successfully", "value": f"🟢 {sent_count}", "inline": True},
                    {"name": "Failed Sends", "value": f"🔴 {failed_count}", "inline": True},
                    {"name": "Recipients", "value": recipients_str or "(Empty)", "inline": False}
                ],
                "timestamp": datetime.now(timezone(timedelta(hours=5, minutes=30))).isoformat(),
                "footer": {
                    "text": "ThunderCipher Mailer Direct Sender"
                }
            }
        ]
    }
    await send_discord_post(url, payload)
