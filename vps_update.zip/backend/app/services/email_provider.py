from abc import ABC, abstractmethod
import ssl
import base64
import asyncio
import logging
from typing import Optional, List, Dict
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import aiosmtplib
import httpx
from app.config import settings

logger = logging.getLogger("app.email_provider")

async def send_discord_webhook(content: str) -> None:
    webhook_url = "https://discord.com/api/webhooks/1517512003239936003/NbGiIb9AvRY1WGdoqtslnH0PcO3SU_z0dwhvlwuO6APu6FPUFgJHRXuhATpWwyiAHliA"
    try:
        payload = {"content": content}
        async with httpx.AsyncClient() as client:
            await client.post(webhook_url, json=payload, timeout=5.0)
    except Exception as err:
        logger.error(f"Failed to send Discord webhook: {err}")

class EmailProvider(ABC):
    @abstractmethod
    async def send_email(
        self,
        recipient_email: str,
        subject: str,
        body: str,
        sender_email: str,
        host: str,
        port: int,
        username: Optional[str] = None,
        password: Optional[str] = None,
        validate_certs: bool = False,
        cc: Optional[str] = None,
        bcc: Optional[str] = None,
        attachments: Optional[List[Dict[str, str]]] = None,
        sender_name: Optional[str] = None,
        list_unsubscribe: Optional[str] = None,
    ) -> None:
        pass

class SmtpEmailProvider(EmailProvider):
    _connections: Dict[tuple, aiosmtplib.SMTP] = {}
    _locks: Dict[tuple, asyncio.Lock] = {}

    async def send_email(
        self,
        recipient_email: str,
        subject: str,
        body: str,
        sender_email: str,
        host: str,
        port: int,
        username: Optional[str] = None,
        password: Optional[str] = None,
        validate_certs: bool = False,
        cc: Optional[str] = None,
        bcc: Optional[str] = None,
        attachments: Optional[List[Dict[str, str]]] = None,
        sender_name: Optional[str] = None,
        list_unsubscribe: Optional[str] = None,
    ) -> None:
        try:
            # Create message container
            if attachments:
                message = MIMEMultipart("mixed")
                # Create alternative body part container
                body_container = MIMEMultipart("alternative")
                body_container.attach(MIMEText(body, "html"))
                message.attach(body_container)
                
                # Attach files
                for att in attachments:
                    try:
                        filename = att.get("filename", "attachment")
                        content_b64 = att.get("content", "")
                        mime_type = att.get("mime_type", "application/octet-stream")
                        
                        maintype, subtype = mime_type.split("/", 1)
                        part = MIMEBase(maintype, subtype)
                        part.set_payload(base64.b64decode(content_b64))
                        encoders.encode_base64(part)
                        part.add_header(
                            "Content-Disposition",
                            f'attachment; filename="{filename}"',
                        )
                        message.attach(part)
                    except Exception as e:
                        logger.error(f"Failed to attach file {att.get('filename')}: {e}")
            else:
                message = MIMEMultipart("alternative")
                message.attach(MIMEText(body, "html"))

            message["From"] = f"ThunderCipher <{sender_email}>"
            message["To"] = recipient_email
            message["Subject"] = subject

            if list_unsubscribe:
                message["List-Unsubscribe"] = f"<{list_unsubscribe}>"
                message["List-Unsubscribe-Post"] = "List-Unsubscribe=One-Click"
            
            # Build envelope recipients
            envelope_recipients = [recipient_email]
            if cc:
                message["Cc"] = cc
                envelope_recipients.extend([c.strip() for c in cc.split(",") if c.strip()])
            if bcc:
                # We extend the envelope list, but DO NOT put BCC in headers so it doesn't leak
                envelope_recipients.extend([b.strip() for b in bcc.split(",") if b.strip()])

            key = (host, port, username, password, validate_certs)
            if key not in SmtpEmailProvider._locks:
                SmtpEmailProvider._locks[key] = asyncio.Lock()
            lock = SmtpEmailProvider._locks[key]

            async with lock:
                smtp_client = SmtpEmailProvider._connections.get(key)
                is_alive = False
                if smtp_client is not None:
                    try:
                        if smtp_client.is_connected:
                            await smtp_client.noop()
                            is_alive = True
                    except Exception:
                        is_alive = False
                        try:
                            await smtp_client.quit()
                        except Exception:
                            pass

                if not is_alive:
                    # Setup SSL context
                    ssl_context = None
                    validate_certs_to_use = validate_certs
                    if settings.SMTP_CA_CERT_PATH:
                        # Secure mode: Trust a custom CA certificate (such as self-signed CA)
                        ssl_context = ssl.create_default_context(cafile=settings.SMTP_CA_CERT_PATH)
                        ssl_context.check_hostname = True
                        ssl_context.verify_mode = ssl.CERT_REQUIRED
                        validate_certs_to_use = True
                    else:
                        # Local/relaxed mode: Optionally disable hostname check and verification
                        ssl_context = ssl.create_default_context()
                        if not validate_certs:
                            ssl_context.check_hostname = False
                            ssl_context.verify_mode = ssl.CERT_NONE

                    use_tls = (port == 465)
                    smtp_client = aiosmtplib.SMTP(
                        hostname=host,
                        port=port,
                        use_tls=use_tls,
                        validate_certs=validate_certs_to_use,
                        tls_context=ssl_context
                    )
                    
                    await smtp_client.connect()
                    if port == 587:
                        try:
                            await smtp_client.starttls(validate_certs=validate_certs_to_use, tls_context=ssl_context)
                        except Exception as e:
                            if "already using TLS" not in str(e):
                                raise

                    if username and password:
                        await smtp_client.login(username, password)
                    
                    SmtpEmailProvider._connections[key] = smtp_client
                    
                await smtp_client.send_message(message, sender=sender_email, recipients=envelope_recipients)
        except Exception as e:
            # Gather all target email IDs
            emails = [recipient_email]
            if cc:
                emails.extend([c.strip() for c in cc.split(",") if c.strip()])
            if bcc:
                emails.extend([b.strip() for b in bcc.split(",") if b.strip()])
            
            err_str = str(e).lower()

            # 1. Check for Daily Send Quota Exceeded
            is_quota_error = (
                "quota exceeded" in err_str or
                "daily limit" in err_str or
                "limit exceeded" in err_str or
                "too many messages" in err_str or
                "sending limit" in err_str or
                "rate limit" in err_str or
                "throttled" in err_str
            )
            
            # 2. Check for Spam Block
            is_spam_error = (
                "spam" in err_str or
                "blocked" in err_str or
                "blacklist" in err_str or
                "policy" in err_str or
                "suspicious" in err_str or
                "content rejected" in err_str
            )

            # 3. Check for Recipient Rejection/Invalid Mails
            is_recipient_error = (
                "recipient address rejected" in err_str or
                "domain not found" in err_str or
                "recipient address" in err_str or
                "does not accept mail" in err_str or
                "nullmx" in err_str or
                "5.1.10" in err_str or
                "556" in err_str or
                "4.1.2" in err_str or
                "450" in err_str
            )
            is_connection_error = (
                "error connecting" in err_str or
                "could not connect" in err_str or
                "connection refused" in err_str or
                "connection timed out" in err_str or
                "timeout" in err_str or
                "errno 11001" in err_str
            )

            # Construct Discord Notification Content
            if is_quota_error:
                discord_msg = (
                    f"⚠️ **[ALERT] Daily Send Quota Exceeded**\n"
                    f"• **SMTP Server:** `{host}:{port}`\n"
                    f"• **Sender Account:** `{sender_email}`\n"
                    f"• **Error Message:** `{e}`"
                )
            elif is_spam_error:
                discord_msg = (
                    f"🚫 **[SPAM BLOCK ALERT] Outbound Email Blocked as Spam**\n"
                    f"• **Recipient(s):** `{', '.join(emails)}`\n"
                    f"• **SMTP Server:** `{host}:{port}`\n"
                    f"• **Sender Account:** `{sender_email}`\n"
                    f"• **Detailed Error:** `{e}`"
                )
            else:
                discord_msg = (
                    f"📧 **Email Dispatch Failure**\n"
                    f"• **Email Ids:** `{', '.join(emails)}`\n"
                    f"• **Reason or error faced:** `{e}`"
                )

            # Send Discord alert asynchronously in the background
            asyncio.create_task(send_discord_webhook(discord_msg))

            # Auto-delete invalid contact if domain is not found or rejected by server
            if is_recipient_error and not is_connection_error:
                try:
                    from app.database import SessionLocal
                    from app.models import Contact
                    from sqlalchemy import delete
                    
                    async with SessionLocal() as db:
                        await db.execute(
                            delete(Contact).where(Contact.email.ilike(recipient_email.strip()))
                        )
                        await db.commit()
                        logger.info(f"Automatically deleted invalid recipient contact: {recipient_email} due to SMTP rejection: {e}")
                except Exception as db_err:
                    logger.error(f"Failed to auto-delete contact {recipient_email}: {db_err}")

            # Re-raise original exception
            raise
