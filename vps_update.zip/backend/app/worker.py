import asyncio
import logging
import imaplib
import email
from email.header import decode_header
from datetime import datetime, timezone, timedelta, time
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from arq.connections import RedisSettings
from arq import cron

from app.database import SessionLocal, engine, get_ist_time
from app.models import Campaign, Contact, EmailQueue, SMTPAccount, User, ContactNote, AuditLog, ContactReply, Conversation, Message
from app.services.email_provider import SmtpEmailProvider
from app.config import settings
from jose import jwt

logger = logging.getLogger("arq.worker")
email_provider = SmtpEmailProvider()

async def startup(ctx):
    logger.info("Initializing database connection in background worker...")
    ctx["db_session"] = SessionLocal
    ctx["email_provider"] = email_provider

async def shutdown(ctx):
    logger.info("Closing database connection in background worker...")

def poll_imap_inbox_sync(host: str, port: int, user: str, password: str):
    """
    Synchronous IMAP polling routine run inside a thread pool executor.
    """
    replies = []
    try:
        # Connect to IMAP server using SSL
        mail = imaplib.IMAP4_SSL(host, int(port))
        mail.login(user, password)
        mail.select("INBOX")
        
        # Search unseen messages
        status, response_data = mail.search(None, "UNSEEN")
        if status != "OK":
            return replies
            
        for num in response_data[0].split():
            # Fetch email
            status, msg_data = mail.fetch(num, "(RFC822)")
            if status != "OK":
                continue
                
            raw_email = msg_data[0][1]
            msg = email.message_from_bytes(raw_email)
            
            # Parse sender
            from_header = msg.get("From", "")
            from_addr = email.utils.parseaddr(from_header)[1]
            
            # Parse subject
            subject_header = msg.get("Subject", "")
            subject = ""
            if subject_header:
                decoded_parts = decode_header(subject_header)
                for part, encoding in decoded_parts:
                    if isinstance(part, bytes):
                        subject += part.decode(encoding or "utf-8", errors="ignore")
                    else:
                        subject += str(part)
                        
            # Parse body payload
            body_html = ""
            body_plain = ""
            if msg.is_multipart():
                for part in msg.walk():
                    content_type = part.get_content_type()
                    content_disposition = str(part.get("Content-Disposition"))
                    if "attachment" not in content_disposition:
                        if content_type == "text/html":
                            payload = part.get_payload(decode=True)
                            if payload:
                                body_html = payload.decode(errors="ignore")
                        elif content_type == "text/plain":
                            payload = part.get_payload(decode=True)
                            if payload:
                                body_plain = payload.decode(errors="ignore")
            else:
                content_type = msg.get_content_type()
                payload = msg.get_payload(decode=True)
                if payload:
                    decoded = payload.decode(errors="ignore")
                    if content_type == "text/html":
                        body_html = decoded
                    else:
                        body_plain = decoded
                
            body_content = body_html if body_html else body_plain
            snippet = body_plain.strip()[:300] if body_plain else body_html.strip()[:300]
            replies.append((from_addr, subject, snippet, body_content))
            
            # Mark message as read
            mail.store(num, "+FLAGS", "\\Seen")
            
        mail.logout()
    except Exception as e:
        logger.error(f"IMAP sync check failed for host {host}: {str(e)}")
        raise
        
    return replies

async def check_for_replies_cron(ctx):
    """
    Periodic cron task to poll active IMAP gateways and match new replies.
    """
    logger.info("Worker: Checking IMAP inboxes for campaign replies...")
    db_session_factory = ctx["db_session"]
    
    async with db_session_factory() as db:
        # Get active gateways with IMAP settings configured
        smtp_res = await db.execute(
            select(SMTPAccount).where(
                SMTPAccount.is_active == True,
                SMTPAccount.imap_host != None,
                SMTPAccount.imap_host != ""
            )
        )
        gateways = smtp_res.scalars().all()
        if not gateways:
            logger.info("No active gateways configured with IMAP setup.")
            return

        for gw in gateways:
            logger.info(f"Checking IMAP inbox for {gw.name} ({gw.imap_host})...")
            try:
                # Poll inbox inside executor thread pool to prevent async loop blocks
                loop = asyncio.get_event_loop()
                from app.services.crypto import decrypt_password
                decrypted_pw = decrypt_password(gw.password_encrypted)
                replies = await loop.run_in_executor(
                    None,
                    poll_imap_inbox_sync,
                    gw.imap_host,
                    gw.imap_port or 993,
                    gw.username,
                    decrypted_pw
                )
                
                for from_addr, subject, snippet, body_content in replies:
                    if not from_addr:
                        continue
                    
                    # Match sender email to contact in database
                    contact_res = await db.execute(
                        select(Contact).where(Contact.email.ilike(from_addr.strip()))
                    )
                    contact = contact_res.scalars().first()
                    
                    if not contact:
                        continue
                    else:
                        contact.status = "replied"
                        
                        # 2. Check duplicate reply to prevent log cluttering
                        dup_res = await db.execute(
                            select(ContactReply).where(
                                ContactReply.contact_id == contact.id,
                                ContactReply.subject == subject,
                                ContactReply.snippet == snippet
                            )
                        )
                        if dup_res.scalars().first():
                            continue
                            
                        # 3. Create ContactReply record
                        reply_obj = ContactReply(
                            contact_id=contact.id,
                            subject=subject,
                            snippet=snippet,
                            received_at=get_ist_time()
                        )
                        db.add(reply_obj)

                        # Match thread by clean subject
                        clean_subj = subject
                        for prefix in ["Re: ", "re: ", "RE: ", "Fwd: ", "fwd: ", "FWD: ", "Re:", "re:", "RE:", "Fwd:", "fwd:", "FWD:"]:
                            clean_subj = clean_subj.replace(prefix, "")
                        clean_subj = clean_subj.strip()

                        conv_res = await db.execute(
                            select(Conversation).where(
                                Conversation.contact_id == contact.id,
                                Conversation.subject.ilike(clean_subj)
                            )
                        )
                        conversation = conv_res.scalars().first()
                        if not conversation:
                            conversation = Conversation(
                                contact_id=contact.id,
                                subject=clean_subj,
                                status="replied"
                            )
                            db.add(conversation)
                            await db.flush()
                        else:
                            conversation.status = "replied"
                            conversation.updated_at = get_ist_time()

                        # Create Message entry (incoming reply)
                        msg_obj = Message(
                            conversation_id=conversation.id,
                            sender=from_addr.strip(),
                            recipient=gw.from_email,
                            subject=subject,
                            body=body_content,
                            is_incoming=True,
                            is_unread=True,
                            created_at=get_ist_time()
                        )
                        db.add(msg_obj)
                        
                        # 4. Log ContactNote event
                        note = ContactNote(
                            contact_id=contact.id,
                            author_name="System IMAP Poller",
                            content=f"Received reply via IMAP: '{subject}'. Body: {snippet[:150]}..."
                        )
                        db.add(note)
                        
                        # 5. Dispatch Discord notification
                        from app.services.discord import send_discord_reply_notification
                        await send_discord_reply_notification(
                            contact_name=contact.full_name or "Unknown Contact",
                            contact_email=contact.email,
                            subject=subject,
                            snippet=snippet
                        )
                        
                        try:
                            from app.services.websocket import manager
                            asyncio.create_task(manager.broadcast({
                                "type": "new_email",
                                "contact_name": contact.full_name or "Unknown Contact",
                                "contact_email": contact.email,
                                "subject": subject,
                                "snippet": snippet[:150]
                            }))
                        except Exception:
                            pass
                        
                await db.commit()
            except Exception as e:
                logger.error(f"Error checking IMAP gateway '{gw.name}': {str(e)}")

async def process_campaign_queue(ctx, campaign_id: str):
    logger.info(f"Worker: Processing campaign queue for campaign: {campaign_id}")
    db_session_factory = ctx["db_session"]
    
    async with db_session_factory() as db:
        camp_res = await db.execute(select(Campaign).where(Campaign.id == campaign_id))
        campaign = camp_res.scalars().first()
        if not campaign:
            logger.error(f"Campaign {campaign_id} not found.")
            return
            
        contact_res = await db.execute(select(Contact).where(Contact.status == "active"))
        contacts = contact_res.scalars().all()
        if not contacts:
            logger.warning("No active contacts to target.")
            campaign.status = "completed"
            await db.commit()
            return
            
        from app.models import Template
        temp_res = await db.execute(select(Template).where(Template.id == campaign.template_id))
        template = temp_res.scalars().first()
        if not template:
            logger.error(f"Template {campaign.template_id} not found.")
            campaign.status = "failed"
            await db.commit()
            return
            
        # Check if queue items already exist for this campaign
        existing_queue_res = await db.execute(
            select(EmailQueue).where(EmailQueue.campaign_id == campaign_id)
        )
        existing_items = existing_queue_res.scalars().all()
        
        if not existing_items:
            for contact in contacts:
                subject_rendered = template.subject.replace("{{name}}", contact.full_name or "").replace("{{company}}", contact.company or "")
                body_rendered = template.body_html.replace("{{name}}", contact.full_name or "").replace("{{company}}", contact.company or "")
                
                queue_item = EmailQueue(
                    campaign_id=campaign.id,
                    recipient_email=contact.email,
                    subject=subject_rendered,
                    body=body_rendered,
                    status="pending"
                )
                db.add(queue_item)
                
            campaign.status = "running"
            await db.commit()
        else:
            campaign.status = "running"
            await db.commit()
        
        queue_res = await db.execute(
            select(EmailQueue).where(EmailQueue.campaign_id == campaign_id, EmailQueue.status == "pending")
        )
        queue_items = queue_res.scalars().all()
        
        redis_connection = ctx.get("redis")
        if redis_connection:
            import random
            delay = campaign.send_delay_seconds if campaign.send_delay_seconds is not None else 1
            current_defer = 0
            for item in queue_items:
                # Add randomized jitter to the interval (-25% to +50% of the delay)
                jitter = random.uniform(-0.25 * delay, 0.5 * delay)
                step = max(0.1, delay + jitter)
                current_defer += step
                await redis_connection.enqueue_job("send_queued_email", item.id, _defer_by=int(current_defer))
            logger.info(f"Successfully enqueued {len(queue_items)} sending tasks in Redis staggered with progressive jitter.")
        else:
            logger.error("Redis connection is not available in context; cannot enqueue tasks.")

async def send_queued_email(ctx, queue_item_id: str):
    logger.info(f"Worker: Sending queued email: {queue_item_id}")
    db_session_factory = ctx["db_session"]
    provider = ctx["email_provider"]
    
    async with db_session_factory() as db:
        res = await db.execute(select(EmailQueue).where(EmailQueue.id == queue_item_id))
        item = res.scalars().first()
        if not item:
            logger.error(f"Queue item {queue_item_id} not found.")
            return
            
        if item.status == "sent":
            logger.info(f"Queue item {queue_item_id} already marked as sent.")
            return

        item.status = "sending"
        await db.commit()

        camp_res = await db.execute(select(Campaign).where(Campaign.id == item.campaign_id))
        campaign = camp_res.scalars().first()

        if campaign:
            IST = timezone(timedelta(hours=5, minutes=30))
            now_ist = datetime.now(IST)

            # Check weekdays_only constraint
            if campaign.weekdays_only and now_ist.weekday() >= 5:
                logger.info(f"Worker: Weekend detected and weekdays_only is enabled. Deferring queue item {queue_item_id}.")
                item.status = "pending"
                await db.commit()
                return
                
            # Check sending window constraint
            if campaign.send_window_start and campaign.send_window_end:
                current_time_str = now_ist.strftime("%H:%M")
                if not (campaign.send_window_start <= current_time_str <= campaign.send_window_end):
                    logger.info(f"Worker: Current time ({current_time_str} IST) is outside sending window ({campaign.send_window_start} - {campaign.send_window_end}). Deferring queue item {queue_item_id}.")
                    item.status = "pending"
                    await db.commit()
                    return

            # Check warmup limit constraints
            if campaign.warmup_enabled:
                from sqlalchemy import func
                ist_today_start = datetime.combine(now_ist.date(), time.min).replace(tzinfo=IST)
                today_start = ist_today_start.astimezone(timezone.utc).replace(tzinfo=None)
                sent_today_res = await db.execute(
                    select(func.count(EmailQueue.id)).where(
                        EmailQueue.campaign_id == campaign.id,
                        EmailQueue.status == "sent",
                        EmailQueue.sent_time >= today_start
                    )
                )
                sent_today = sent_today_res.scalar() or 0
                
                days_elapsed = 0
                if campaign.start_date:
                    start_date_ist = campaign.start_date.replace(tzinfo=timezone.utc).astimezone(IST).date()
                    days_elapsed = (now_ist.date() - start_date_ist).days
                    if days_elapsed < 0:
                        days_elapsed = 0
                
                limit_today = campaign.warmup_start_limit + (days_elapsed * campaign.warmup_increment)
                if sent_today >= limit_today:
                    logger.info(f"Worker: Warmup daily limit reached ({sent_today}/{limit_today}). Rescheduling queue item {queue_item_id} for tomorrow.")
                    
                    # Defer this email to tomorrow at window start in IST
                    tomorrow_ist = now_ist.date() + timedelta(days=1)
                    hour, minute = 9, 0
                    if campaign.send_window_start:
                        try:
                            parts = campaign.send_window_start.split(":")
                            hour = int(parts[0])
                            minute = int(parts[1])
                        except Exception:
                            pass
                    
                    defer_time_ist = datetime.combine(tomorrow_ist, time(hour, minute)).replace(tzinfo=IST)
                    defer_until = defer_time_ist.astimezone(timezone.utc).replace(tzinfo=None)
                    
                    # Revert to pending
                    item.status = "pending"
                    await db.commit()
                    
                    # Reschedule the job in Redis to run tomorrow
                    redis_connection = ctx.get("redis")
                    if redis_connection:
                        await redis_connection.enqueue_job("send_queued_email", item.id, _defer_until=defer_until)
                        logger.info(f"Worker: Successfully rescheduled queue item {queue_item_id} for {defer_until}.")
                    return
        
        host = settings.SMTP_HOST
        port = settings.SMTP_PORT
        username = settings.SMTP_USER
        password = settings.SMTP_PASSWORD
        from_email = settings.SMTP_FROM_EMAIL
        smtp_name = "Default config"

        if campaign and campaign.sender:
            smtp_res = await db.execute(select(SMTPAccount).where(SMTPAccount.id == campaign.sender))
            smtp = smtp_res.scalars().first()
            if smtp:
                from app.services.crypto import decrypt_password
                host = smtp.host
                port = smtp.port
                username = smtp.username
                password = decrypt_password(smtp.password_encrypted)
                from_email = smtp.from_email
                smtp_name = smtp.name

        # Check if contact is still active (not unsubscribed) - only for campaigns
        contact_res = await db.execute(select(Contact).where(Contact.email.ilike(item.recipient_email)))
        contact = contact_res.scalars().first()
        if item.campaign_id is not None and contact and contact.status == "unsubscribed":
            logger.info(f"Recipient {item.recipient_email} has unsubscribed. Skipping queue item.")
            item.status = "failed"
            await db.commit()
            return


        # Generate secure unsubscribe token & url
        unsub_token = jwt.encode({"sub": item.recipient_email, "type": "unsubscribe"}, settings.JWT_SECRET, algorithm="HS256")
        unsub_url = f"{settings.BACKEND_URL}/api/v1/campaigns/unsubscribe?token={unsub_token}"

        body_html = item.body
        
        # Append Unsubscribe Footer Link
        unsub_link_html = f'<br/><br/><hr style="border:0;border-top:1px solid rgba(255,255,255,0.08);margin:20px 0;"/><p style="font-size:11px;color:#8a93a6;text-align:center;">If you no longer wish to receive these communications, you can <a href="{unsub_url}" style="color:#00b5ad;text-decoration:underline;">unsubscribe here</a>.</p>'
        if "</body>" in body_html:
            body_html = body_html.replace("</body>", f"{unsub_link_html}</body>")
        else:
            body_html += unsub_link_html

        if campaign and campaign.track_opens:
            pixel_url = f"{settings.BACKEND_URL}/api/v1/campaigns/track/{item.id}"
            pixel_img = f'<img src="{pixel_url}" width="1" height="1" style="display:none !important;" alt="" />'
            if "</body>" in body_html:
                body_html = body_html.replace("</body>", f"{pixel_img}</body>")
            else:
                body_html += pixel_img

        try:
            await provider.send_email(
                recipient_email=item.recipient_email,
                subject=item.subject,
                body=body_html,
                sender_email=from_email,
                host=host,
                port=port,
                username=username,
                password=password,
                validate_certs=False,
                sender_name=smtp_name,
                list_unsubscribe=unsub_url
            )
            
            item.status = "sent"
            item.sent_time = get_ist_time()
            
            contact_res = await db.execute(select(Contact).where(Contact.email == item.recipient_email))
            contact = contact_res.scalars().first()
            if contact:
                # Group under Conversation by matching clean subject
                clean_subj = item.subject
                for prefix in ["Re: ", "re: ", "RE: ", "Fwd: ", "fwd: ", "FWD: ", "Re:", "re:", "RE:", "Fwd:", "fwd:", "FWD:"]:
                    clean_subj = clean_subj.replace(prefix, "")
                clean_subj = clean_subj.strip()

                conv_res = await db.execute(
                    select(Conversation).where(
                        Conversation.contact_id == contact.id,
                        Conversation.subject.ilike(clean_subj)
                    )
                )
                conversation = conv_res.scalars().first()
                if not conversation:
                    conversation = Conversation(
                        contact_id=contact.id,
                        subject=clean_subj,
                        status="waiting"
                    )
                    db.add(conversation)
                    await db.flush()
                else:
                    conversation.updated_at = get_ist_time()

                # Add Message log (outbound sent email)
                msg_obj = Message(
                    conversation_id=conversation.id,
                    sender=from_email,
                    recipient=item.recipient_email,
                    subject=item.subject,
                    body=item.body,
                    is_incoming=False,
                    is_unread=False,
                    created_at=get_ist_time()
                )
                db.add(msg_obj)

                note = ContactNote(
                    contact_id=contact.id,
                    author_name="System Worker",
                    content=f"Campaign email successfully delivered via gateway '{smtp_name}': {item.subject}"
                )
                db.add(note)

            await db.commit()
            logger.info(f"Queue item {queue_item_id} sent successfully.")
            
        except Exception as e:
            logger.error(f"Failed to send email {queue_item_id}: {str(e)}")
            item.status = "failed"
            item.error_message = str(e)
            
            audit = AuditLog(
                user_id=campaign.owner_id if campaign else None,
                action="SMTP Worker Failure",
                details=f"Queue send failed to {item.recipient_email} using gateway '{smtp_name}'. Error: {str(e)}"
            )
            db.add(audit)

            await db.commit()

        # Check if campaign is completed
        if item.campaign_id:
            from sqlalchemy import func
            remaining_q = select(func.count(EmailQueue.id)).where(
                EmailQueue.campaign_id == item.campaign_id,
                EmailQueue.status.in_(["pending", "sending"])
            )
            remaining_res = await db.execute(remaining_q)
            remaining_count = remaining_res.scalar() or 0
            
            if remaining_count == 0:
                camp_res = await db.execute(select(Campaign).where(Campaign.id == item.campaign_id))
                campaign = camp_res.scalars().first()
                if campaign and campaign.status != "completed":
                    campaign.status = "completed"
                    campaign.end_date = get_ist_time()
                    
                    sent_q = select(func.count(EmailQueue.id)).where(
                        EmailQueue.campaign_id == campaign.id,
                        EmailQueue.status == "sent"
                    )
                    failed_q = select(func.count(EmailQueue.id)).where(
                        EmailQueue.campaign_id == campaign.id,
                        EmailQueue.status == "failed"
                    )
                    sent_res = await db.execute(sent_q)
                    failed_res = await db.execute(failed_q)
                    sent_val = sent_res.scalar() or 0
                    failed_val = failed_res.scalar() or 0
                    
                    try:
                        from app.services.discord import dispatch_campaign_summary_notification
                        await dispatch_campaign_summary_notification(
                            campaign_name=campaign.name,
                            sent_count=sent_val,
                            failed_count=failed_val,
                            gateway_name=smtp_name,
                            subject=item.subject
                        )
                    except Exception as notify_err:
                        logger.error(f"Failed to dispatch Discord campaign summary: {str(notify_err)}")
                    
                    await db.commit()

# ARQ worker settings
redis_host_port = settings.REDIS_URL.replace("redis://", "").split("/")[0].split(":")
redis_host = redis_host_port[0]
redis_port = int(redis_host_port[1]) if len(redis_host_port) > 1 else 6379

class WorkerSettings:
    functions = [process_campaign_queue, send_queued_email, check_for_replies_cron]
    # Poll for replies every minute on the 0th second
    cron_jobs = [
        cron(check_for_replies_cron, second=0, run_at_startup=True)
    ]
    on_startup = startup
    on_shutdown = shutdown
    redis_settings = RedisSettings(host=redis_host, port=redis_port)
