import uuid
from datetime import datetime
from typing import List, Optional, Dict, Any
from sqlalchemy import String, Integer, Boolean, DateTime, ForeignKey, Text, Table, Column, JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base, get_ist_time

# Association table for Contact <-> Tag
contact_tags = Table(
    "contact_tags",
    Base.metadata,
    Column("contact_id", String(36), ForeignKey("contacts.id", ondelete="CASCADE"), primary_key=True),
    Column("tag_id", String(36), ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
)

# Association table for Conversation <-> Tag
conversation_tags = Table(
    "conversation_tags",
    Base.metadata,
    Column("conversation_id", String(36), ForeignKey("conversations.id", ondelete="CASCADE"), primary_key=True),
    Column("tag_id", String(36), ForeignKey("tags.id", ondelete="CASCADE"), primary_key=True),
)

class User(Base):
    __tablename__ = "users"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    full_name: Mapped[str] = mapped_column(String(100))
    username: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default="operator")  # super_admin, admin, manager, operator, viewer
    status: Mapped[str] = mapped_column(String(20), default="active")  # active, suspended, disabled, pending
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time, onupdate=get_ist_time)
    last_login: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    # Relationships
    campaigns = relationship("Campaign", back_populates="owner")
    audit_logs = relationship("AuditLog", back_populates="user")
    notifications = relationship("Notification", back_populates="user")

class Tag(Base):
    __tablename__ = "tags"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    color: Mapped[str] = mapped_column(String(10), default="#6366F1") # Hex color

class Contact(Base):
    __tablename__ = "contacts"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    full_name: Mapped[str] = mapped_column(String(100))
    email: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    company: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    designation: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    website: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    linkedin: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active")  # active, archived, unsubscribed
    source: Mapped[Optional[str]] = mapped_column(String(50), nullable=True) # csv, manual, website
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time, onupdate=get_ist_time)
    
    # Custom fields as JSON for flexibility
    custom_fields: Mapped[Optional[dict]] = mapped_column(JSON, default=dict, nullable=True)
    
    # Relationships
    tags = relationship("Tag", secondary=contact_tags, backref="contacts")
    conversations = relationship("Conversation", back_populates="contact", cascade="all, delete-orphan", passive_deletes=True)
    notes = relationship("ContactNote", back_populates="contact", cascade="all, delete-orphan", passive_deletes=True)
    replies = relationship("ContactReply", back_populates="contact", cascade="all, delete-orphan", passive_deletes=True)

class ContactNote(Base):
    __tablename__ = "contact_notes"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    contact_id: Mapped[str] = mapped_column(String(36), ForeignKey("contacts.id", ondelete="CASCADE"))
    author_name: Mapped[str] = mapped_column(String(100))
    content: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    
    contact = relationship("Contact", back_populates="notes")

class Template(Base):
    __tablename__ = "templates"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(100), unique=True)
    folder: Mapped[str] = mapped_column(String(50), default="General") # General, Sponsorship, Recruitment, etc.
    subject: Mapped[str] = mapped_column(String(255))
    body_html: Mapped[str] = mapped_column(Text)
    body_text: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    variables: Mapped[Optional[list]] = mapped_column(JSON, default=list, nullable=True) # List of variables used e.g. ["name", "company"]
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time, onupdate=get_ist_time)

class Attachment(Base):
    __tablename__ = "attachments"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(255))
    filepath: Mapped[str] = mapped_column(String(500))
    file_size: Mapped[int] = mapped_column(Integer) # In bytes
    mime_type: Mapped[str] = mapped_column(String(100))
    upload_date: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    usage_count: Mapped[int] = mapped_column(Integer, default=0)

class Draft(Base):
    __tablename__ = "drafts"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    sender: Mapped[str] = mapped_column(String(100))
    recipients: Mapped[list] = mapped_column(JSON, default=list) # List of emails
    cc: Mapped[Optional[list]] = mapped_column(JSON, default=list, nullable=True)
    bcc: Mapped[Optional[list]] = mapped_column(JSON, default=list, nullable=True)
    subject: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    body: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    template_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    variables: Mapped[Optional[dict]] = mapped_column(JSON, default=dict, nullable=True)
    attachments: Mapped[Optional[list]] = mapped_column(JSON, default=list, nullable=True) # List of attachment UUIDs
    schedule: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time, onupdate=get_ist_time)

class Campaign(Base):
    __tablename__ = "campaigns"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(100))
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    owner_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id"))
    status: Mapped[str] = mapped_column(String(20), default="draft")  # draft, scheduled, running, paused, completed, cancelled, failed
    template_id: Mapped[str] = mapped_column(String(36), ForeignKey("templates.id"))
    sender: Mapped[str] = mapped_column(String(100))
    start_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    end_date: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time, onupdate=get_ist_time)
    
    # Advanced settings
    send_delay_seconds: Mapped[int] = mapped_column(Integer, default=1)
    batch_size: Mapped[int] = mapped_column(Integer, default=50)
    stop_on_reply: Mapped[bool] = mapped_column(Boolean, default=True)
    max_retries: Mapped[int] = mapped_column(Integer, default=3)
    track_opens: Mapped[bool] = mapped_column(Boolean, default=False)
    weekdays_only: Mapped[bool] = mapped_column(Boolean, default=True)
    send_window_start: Mapped[Optional[str]] = mapped_column(String(5), default="09:00", nullable=True)
    send_window_end: Mapped[Optional[str]] = mapped_column(String(5), default="17:00", nullable=True)
    warmup_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    warmup_start_limit: Mapped[int] = mapped_column(Integer, default=10)
    warmup_increment: Mapped[int] = mapped_column(Integer, default=5)
    
    owner = relationship("User", back_populates="campaigns")
    template = relationship("Template")
    target_tag_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("tags.id"), nullable=True)
    target_tag = relationship("Tag")

class EmailQueue(Base):
    __tablename__ = "email_queue"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    campaign_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("campaigns.id", ondelete="SET NULL"), nullable=True, index=True)
    smtp_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("smtp_accounts.id", ondelete="SET NULL"), nullable=True, index=True)
    recipient_email: Mapped[str] = mapped_column(String(100), index=True)
    subject: Mapped[str] = mapped_column(String(255))
    body: Mapped[str] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(20), default="pending")  # pending, validating, waiting, sending, sent, failed, retrying, cancelled
    retry_count: Mapped[int] = mapped_column(Integer, default=0)
    scheduled_time: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    sent_time: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    opened: Mapped[bool] = mapped_column(Boolean, default=False)
    opened_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    
    campaign = relationship("Campaign")

class SMTPAccount(Base):
    __tablename__ = "smtp_accounts"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name: Mapped[str] = mapped_column(String(100), unique=True)
    host: Mapped[str] = mapped_column(String(255))
    port: Mapped[int] = mapped_column(Integer, default=587)
    username: Mapped[str] = mapped_column(String(100))
    password_encrypted: Mapped[str] = mapped_column(String(500))  # AES or encrypted value
    from_email: Mapped[str] = mapped_column(String(100))
    rate_limit_daily: Mapped[int] = mapped_column(Integer, default=500)
    rate_limit_hourly: Mapped[int] = mapped_column(Integer, default=50)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    
    # IMAP Configuration for replies tracking
    imap_host: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    imap_port: Mapped[Optional[int]] = mapped_column(Integer, default=993, nullable=True)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    action: Mapped[str] = mapped_column(String(100), index=True) # e.g. Login Success, Template Edited
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    details: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    
    user = relationship("User", back_populates="audit_logs")

class Conversation(Base):
    __tablename__ = "conversations"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    contact_id: Mapped[str] = mapped_column(String(36), ForeignKey("contacts.id", ondelete="CASCADE"), index=True)
    subject: Mapped[str] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(20), default="new")  # new, waiting, replied, closed, archived
    assigned_user_id: Mapped[Optional[str]] = mapped_column(String(36), ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time, onupdate=get_ist_time)
    
    contact = relationship("Contact", back_populates="conversations")
    assigned_user = relationship("User")
    messages = relationship("Message", back_populates="conversation", cascade="all, delete-orphan")
    tags = relationship("Tag", secondary=conversation_tags, backref="conversations")

class Message(Base):
    __tablename__ = "messages"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    conversation_id: Mapped[str] = mapped_column(String(36), ForeignKey("conversations.id", ondelete="CASCADE"), index=True)
    sender: Mapped[str] = mapped_column(String(100)) # Email address
    recipient: Mapped[str] = mapped_column(String(100)) # Email address
    subject: Mapped[str] = mapped_column(String(255))
    body: Mapped[str] = mapped_column(Text)
    is_incoming: Mapped[bool] = mapped_column(Boolean, default=False)
    is_unread: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    
    conversation = relationship("Conversation", back_populates="messages")

class Notification(Base):
    __tablename__ = "notifications"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(36), ForeignKey("users.id", ondelete="CASCADE"))
    title: Mapped[str] = mapped_column(String(100))
    message: Mapped[str] = mapped_column(String(255))
    type: Mapped[str] = mapped_column(String(20), default="info") # info, success, warning, error
    is_read: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    
    user = relationship("User", back_populates="notifications")

class ContactReply(Base):
    __tablename__ = "contact_replies"
    
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    contact_id: Mapped[str] = mapped_column(String(36), ForeignKey("contacts.id", ondelete="CASCADE"))
    subject: Mapped[str] = mapped_column(String(255))
    snippet: Mapped[str] = mapped_column(Text)
    received_at: Mapped[datetime] = mapped_column(DateTime, default=get_ist_time)
    
    contact = relationship("Contact", back_populates="replies")
