from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload, defer
from sqlalchemy import desc, func, or_
from pydantic import BaseModel
from typing import Optional, List

from app.database import get_db, get_ist_time
from app.models import Conversation, Message, EmailQueue, Draft, Contact, SMTPAccount, User, ContactNote, AuditLog, ContactReply, Campaign
from app.auth import get_current_user
from app.services.email_provider import SmtpEmailProvider

router = APIRouter(prefix="/mailbox", tags=["mailbox"])
email_provider = SmtpEmailProvider()

import re
import time

class SimpleRamCache:
    def __init__(self, default_ttl=300):
        self._cache = {}
        self.default_ttl = default_ttl
        
    def get(self, key):
        if key in self._cache:
            val, expiry = self._cache[key]
            if time.time() < expiry:
                return val
            else:
                del self._cache[key]
        return None
        
    def set(self, key, value, ttl=None):
        ttl = ttl or self.default_ttl
        self._cache[key] = (value, time.time() + ttl)
        
    def invalidate(self, prefix):
        keys_to_del = [k for k in self._cache.keys() if k.startswith(prefix)]
        for k in keys_to_del:
            del self._cache[k]

ram_cache = SimpleRamCache()

def clean_html(raw_html: str) -> str:
    if not raw_html:
        return ""
    text = re.sub(r'<(script|style)[^>]*>[\s\S]*?</\1>', ' ', raw_html)
    text = re.sub(r'<[^>]+>', ' ', text)
    text = re.sub(r'&nbsp;', ' ', text)
    text = re.sub(r'&amp;', '&', text)
    text = re.sub(r'&lt;', '<', text)
    text = re.sub(r'&gt;', '>', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

# Pydantic Schemas
class MessageResponse(BaseModel):
    id: str
    conversation_id: str
    sender: str
    recipient: str
    subject: str
    body: str
    is_incoming: bool
    is_unread: bool
    created_at: datetime

    class Config:
        from_attributes = True

class TagResponse(BaseModel):
    id: str
    name: str
    color: str

    class Config:
        from_attributes = True

class TagCreate(BaseModel):
    name: str
    color: str

class TagAssignIn(BaseModel):
    tag_id: str

class CopilotGenerateIn(BaseModel):
    conversation_id: Optional[str] = None
    prompt: str
    tone: Optional[str] = "professional"
    model: Optional[str] = "gemini-2.5-flash"

class ConversationResponse(BaseModel):
    id: str
    subject: str
    status: str
    contact_id: str
    contact_name: str
    contact_email: str
    latest_message_time: datetime
    latest_message_snippet: str
    unread_count: int
    tags: List[TagResponse] = []

    class Config:
        from_attributes = True

class SentItemResponse(BaseModel):
    id: str
    recipient_email: str
    subject: str
    body: str
    sent_time: datetime
    status: str

    class Config:
        from_attributes = True

class ScheduledItemResponse(BaseModel):
    id: str
    recipient_email: str
    subject: str
    body: str
    scheduled_time: Optional[datetime] = None
    created_at: datetime
    status: str

    class Config:
        from_attributes = True

class DraftResponse(BaseModel):
    id: str
    recipients: List[str]
    cc: Optional[List[str]] = None
    bcc: Optional[List[str]] = None
    subject: Optional[str] = None
    body: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

class ReplyIn(BaseModel):
    body: str
    sender_name: Optional[str] = None

@router.get("/conversations", response_model=List[ConversationResponse])
async def get_conversations(
    smtp_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Fetch SMTP account to get its email address
    smtp = None
    from_email = None
    if smtp_id is not None:
        smtp_res = await db.execute(select(SMTPAccount).where(SMTPAccount.id == smtp_id))
        smtp = smtp_res.scalars().first()
        if not smtp:
            raise HTTPException(status_code=404, detail="SMTP account not found")
        from_email = smtp.from_email.lower().strip()

    # Trigger real-time IMAP poll for this specific account to fetch replies on refresh
    if smtp and smtp.imap_host:
        try:
            from app.worker import poll_imap_inbox_sync
            import asyncio
            from app.services.crypto import decrypt_password
            decrypted_pw = decrypt_password(smtp.password_encrypted)
            loop = asyncio.get_event_loop()
            replies = await loop.run_in_executor(
                None,
                poll_imap_inbox_sync,
                smtp.imap_host,
                smtp.imap_port or 993,
                smtp.username,
                decrypted_pw
            )
            
            for from_addr, subject, snippet in replies:
                if not from_addr:
                    continue
                # Match sender email to contact in database
                contact_res = await db.execute(
                    select(Contact).where(Contact.email.ilike(from_addr.strip()))
                )
                contact = contact_res.scalars().first()
                
                if not contact:
                    contact = Contact(
                        full_name=from_addr.split("@")[0].capitalize(),
                        email=from_addr.strip(),
                        status="replied",
                        source="incoming"
                    )
                    db.add(contact)
                    await db.flush()
                else:
                    contact.status = "replied"
                    
                    # Check duplicate
                    dup_res = await db.execute(
                        select(ContactReply).where(
                            ContactReply.contact_id == contact.id,
                            ContactReply.subject == subject,
                            ContactReply.snippet == snippet
                        )
                    )
                    if dup_res.scalars().first():
                        continue
                        
                    # Create ContactReply record
                    reply_obj = ContactReply(
                        contact_id=contact.id,
                        subject=subject,
                        snippet=snippet,
                        received_at=get_ist_time()
                    )
                    db.add(reply_obj)

                    # Match thread by clean subject
                    clean_subj = subject
                    for prefix in ["Re: ", "re: ", "RE: ", "Fwd: ", "fwd: ", "FWD: ", "Re:", "re:", "RE:", "Fwd:", "fwd:", "FWD:"]:
                        clean_subj = clean_subj.replace(prefix, "")
                    clean_subj = clean_subj.strip()

                    conv_res = await db.execute(
                        select(Conversation).where(
                            Conversation.contact_id == contact.id,
                            Conversation.subject.ilike(clean_subj)
                        )
                    )
                    conversation = conv_res.scalars().first()
                    if not conversation:
                        conversation = Conversation(
                            contact_id=contact.id,
                            subject=clean_subj,
                            status="replied"
                        )
                        db.add(conversation)
                        await db.flush()
                    else:
                        conversation.status = "replied"
                        conversation.updated_at = get_ist_time()

                    # Create Message entry (incoming reply)
                    msg_obj = Message(
                        conversation_id=conversation.id,
                        sender=from_addr.strip(),
                        recipient=smtp.from_email,
                        subject=subject,
                        body=snippet,
                        is_incoming=True,
                        is_unread=True,
                        created_at=get_ist_time()
                    )
                    db.add(msg_obj)
                    
                    # Log ContactNote event
                    note = ContactNote(
                        contact_id=contact.id,
                        author_name="Real-time IMAP Poller",
                        content=f"Received reply via real-time IMAP: '{subject}'. Body: {snippet[:150]}..."
                    )
                    db.add(note)
                    
                    # Dispatch Discord notification
                    try:
                        from app.services.discord import send_discord_reply_notification
                        await send_discord_reply_notification(
                            contact_name=contact.full_name or "Unknown Contact",
                            contact_email=contact.email,
                            subject=subject,
                            snippet=snippet
                        )
                    except Exception:
                        pass
                    
                    try:
                        from app.services.websocket import manager
                        import asyncio
                        asyncio.create_task(manager.broadcast({
                            "type": "new_email",
                            "contact_name": contact.full_name or "Unknown Contact",
                            "contact_email": contact.email,
                            "subject": subject,
                            "snippet": snippet[:150]
                        }))
                    except Exception:
                        pass
            await db.commit()
        except Exception as e:
            import logging
            logging.getLogger("app.mailbox").warning(f"Real-time IMAP poll warning: {e}")

    # Fetch all conversations with messages, contact, and tags loaded
    query = select(Conversation).options(
        selectinload(Conversation.messages),
        selectinload(Conversation.contact),
        selectinload(Conversation.tags)
    )
    result = await db.execute(query)
    all_conversations = result.scalars().all()

    response = []
    clean_email = from_email.strip().lower() if from_email else None

    for conv in all_conversations:
        if not conv.messages:
            continue

        # Check if conversation belongs to the active SMTP account
        belongs = False
        if not clean_email:
            belongs = True
        else:
            for msg in conv.messages:
                sender_clean = (msg.sender or "").strip().lower()
                recipient_clean = (msg.recipient or "").strip().lower()
                if clean_email in sender_clean or clean_email in recipient_clean:
                    belongs = True
                    break

        if not belongs:
            continue


        # Sort messages locally by created_at to find latest
        sorted_messages = sorted(conv.messages, key=lambda m: m.created_at)
        latest_msg = sorted_messages[-1]
        
        # Calculate unread count (incoming messages that are unread)
        unread_cnt = sum(1 for m in conv.messages if m.is_incoming and m.is_unread)

        # Single fetch the body of ONLY the latest message to build the snippet
        latest_body_query = select(Message.body).where(Message.id == latest_msg.id)
        latest_body_res = await db.execute(latest_body_query)
        latest_body = latest_body_res.scalar() or ""

        # Determine contact name and email
        contact_name = "Unknown Contact"
        contact_email = "unknown@unknown.com"
        if conv.contact:
            contact_name = conv.contact.full_name or "Unknown Contact"
            contact_email = conv.contact.email or "unknown@unknown.com"
        else:
            # Fallback directly to the email from the conversation messages
            incoming_msgs = [m for m in sorted_messages if m.is_incoming]
            if incoming_msgs:
                contact_email = incoming_msgs[0].sender
            else:
                contact_email = latest_msg.recipient
            contact_name = contact_email.split("@")[0].capitalize()

        response.append(ConversationResponse(
            id=conv.id,
            subject=conv.subject,
            status=conv.status,
            contact_id=conv.contact_id,
            contact_name=contact_name,
            contact_email=contact_email,
            latest_message_time=latest_msg.created_at,
            latest_message_snippet=clean_html(latest_body)[:150],
            unread_count=unread_cnt,
            tags=[TagResponse(id=t.id, name=t.name, color=t.color) for t in conv.tags]
        ))

    # Sort conversations by latest message time descending
    response.sort(key=lambda c: c.latest_message_time, reverse=True)
    return response

@router.get("/conversations/{id}", response_model=List[MessageResponse])
async def get_conversation_thread(
    id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Fetch all messages in conversation
    msg_res = await db.execute(
        select(Message)
        .where(Message.conversation_id == id)
        .order_by(Message.created_at.asc())
    )
    messages = msg_res.scalars().all()

    # Mark incoming messages as read
    updated = False
    for msg in messages:
        if msg.is_incoming and msg.is_unread:
            msg.is_unread = False
            updated = True
    
    if updated:
        await db.commit()

    return messages

@router.post("/conversations/{id}/reply")
async def reply_to_conversation(
    id: str,
    payload: ReplyIn,
    db: AsyncSession = Depends(get_db),
    # Support replies via direct send
    current_user: User = Depends(get_current_user)
):
    # Fetch conversation and contact
    conv_res = await db.execute(
        select(Conversation)
        .where(Conversation.id == id)
        .options(selectinload(Conversation.contact), selectinload(Conversation.messages))
    )
    conversation = conv_res.scalars().first()
    if not conversation:
        raise HTTPException(status_code=404, detail="Conversation not found")

    if not conversation.contact:
        # Resolve email address from messages
        sorted_messages = sorted(conversation.messages, key=lambda m: m.created_at)
        latest_msg = sorted_messages[-1]
        email_addr = latest_msg.sender if latest_msg.is_incoming else latest_msg.recipient
        
        # Check if the contact exists in the database under this email
        from app.models import Contact
        contact_res = await db.execute(select(Contact).where(Contact.email.ilike(email_addr.strip())))
        contact = contact_res.scalars().first()
        if not contact:
            contact = Contact(
                full_name=email_addr.split("@")[0].capitalize(),
                email=email_addr.strip(),
                status="active",
                source="mailbox"
            )
            db.add(contact)
            await db.flush()
        conversation.contact_id = contact.id
        conversation.contact = contact
        await db.commit()

    if not conversation.messages:
        raise HTTPException(status_code=400, detail="Cannot reply to an empty conversation thread")

    # Find the sender account to use
    # We look at the latest message; whoever received it should reply
    sorted_messages = sorted(conversation.messages, key=lambda m: m.created_at)
    latest_msg = sorted_messages[-1]
    
    sender_email = latest_msg.recipient if latest_msg.is_incoming else latest_msg.sender
    
    # Fetch SMTPAccount credentials for this email
    smtp_res = await db.execute(
        select(SMTPAccount).where(SMTPAccount.from_email.ilike(sender_email.strip()))
    )
    smtp = smtp_res.scalars().first()
    if not smtp:
        # Fall back to first active SMTP gateway if specific sender is missing
        backup_res = await db.execute(select(SMTPAccount).where(SMTPAccount.is_active == True))
        smtp = backup_res.scalars().first()
        if not smtp:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No active SMTP gateway configured for replies.")

    # Determine credentials
    from app.services.crypto import decrypt_password
    host = smtp.host
    port = smtp.port
    username = smtp.username
    password = decrypt_password(smtp.password_encrypted)
    from_email = smtp.from_email
    smtp_name = payload.sender_name or smtp.name

    # Send SMTP Email
    subject_line = f"Re: {conversation.subject}"
    try:
        await email_provider.send_email(
            recipient_email=conversation.contact.email,
            subject=subject_line,
            body=payload.body,
            sender_email=from_email,
            host=host,
            port=port,
            username=username,
            password=password,
            validate_certs=False,
            sender_name=smtp_name
        )
    except Exception as smtp_err:
        raise HTTPException(status_code=500, detail=f"Failed to dispatch SMTP reply: {smtp_err}")

    # Add message log to database
    msg_obj = Message(
        conversation_id=conversation.id,
        sender=from_email,
        recipient=conversation.contact.email,
        subject=subject_line,
        body=payload.body,
        is_incoming=False,
        is_unread=False,
        created_at=get_ist_time()
    )
    db.add(msg_obj)

    # Update conversation updated_at and status
    conversation.updated_at = get_ist_time()
    conversation.status = "waiting"

    # Log timeline note
    note = ContactNote(
        contact_id=conversation.contact_id,
        author_name=current_user.full_name,
        content=f"Sent inline email reply: '{subject_line}'"
    )
    db.add(note)

    # Audit log
    audit = AuditLog(
        user_id=current_user.id,
        action="Mailbox Reply Sent",
        details=f"Replied to contact {conversation.contact.email} from {from_email}."
    )
    db.add(audit)

    await db.commit()
    return {"status": "success", "message": "Reply sent successfully."}

@router.get("/sent", response_model=List[SentItemResponse])
async def get_sent_messages(
    smtp_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Fetch SMTP account to get its email address
    from_email = None
    if smtp_id is not None:
        smtp_res = await db.execute(select(SMTPAccount).where(SMTPAccount.id == smtp_id))
        smtp = smtp_res.scalars().first()
        if not smtp:
            raise HTTPException(status_code=404, detail="SMTP account not found")
        from_email = smtp.from_email.lower().strip()

    # Query all outbound messages from the Message table
    query = select(Message).where(Message.is_incoming == False)
    if from_email:
        query = query.where(Message.sender.ilike(from_email))
    msg_res = await db.execute(
        query.order_by(Message.created_at.desc())
    )
    messages = msg_res.scalars().all()

    response = []
    for msg in messages:
        response.append(SentItemResponse(
            id=msg.id,
            recipient_email=msg.recipient,
            subject=msg.subject,
            body=msg.body,
            sent_time=msg.created_at,
            status="sent"
        ))
    return response

@router.get("/scheduled", response_model=List[ScheduledItemResponse])
async def get_scheduled_messages(
    smtp_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Fetch pending/sending queue items associated with this SMTP config
    # Join with Campaign where Campaign.sender matches smtp_id
    query = select(EmailQueue).outerjoin(Campaign).where(
        EmailQueue.status.in_(["pending", "sending"])
    )
    if smtp_id is not None:
        query = query.where(
            (EmailQueue.smtp_id == smtp_id) |
            ((EmailQueue.campaign_id != None) & (Campaign.sender == smtp_id))
        )
    query = query.order_by(EmailQueue.created_at.desc())
    result = await db.execute(query)
    queue_items = result.scalars().all()

    response = []
    for item in queue_items:
        response.append(ScheduledItemResponse(
            id=item.id,
            recipient_email=item.recipient_email,
            subject=item.subject,
            body=item.body,
            scheduled_time=item.scheduled_time or item.created_at,
            created_at=item.created_at,
            status=item.status
        ))
    return response

@router.get("/drafts", response_model=List[DraftResponse])
async def get_drafts(
    smtp_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Fetch SMTP account to get its email address
    from_email = None
    if smtp_id is not None:
        smtp_res = await db.execute(select(SMTPAccount).where(SMTPAccount.id == smtp_id))
        smtp = smtp_res.scalars().first()
        if not smtp:
            raise HTTPException(status_code=404, detail="SMTP account not found")
        from_email = smtp.from_email.lower().strip()

    # Query drafts matching this sender address
    query = select(Draft)
    if from_email:
        query = query.where(Draft.sender.ilike(from_email))
    drafts_res = await db.execute(
        query.order_by(Draft.updated_at.desc())
    )
    drafts = drafts_res.scalars().all()
    return drafts

@router.get("/tags", response_model=List[TagResponse])
async def list_tags(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Check simple in-memory RAM cache first
    cached = ram_cache.get("tags_list")
    if cached is not None:
        return cached

    from app.models import Tag
    res = await db.execute(select(Tag).order_by(Tag.name))
    tags = res.scalars().all()
    ram_cache.set("tags_list", tags, ttl=300) # cache for 5 minutes
    return tags

@router.post("/tags", response_model=TagResponse)
async def create_tag(
    payload: TagCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    from app.models import Tag
    # Check if duplicate name
    dup_res = await db.execute(select(Tag).where(Tag.name.ilike(payload.name.strip())))
    if dup_res.scalars().first():
        raise HTTPException(status_code=400, detail="Tag with this name already exists.")

    tag = Tag(
        name=payload.name.strip(),
        color=payload.color.strip()
    )
    db.add(tag)
    await db.commit()
    await db.refresh(tag)
    
    # Invalidate cache
    ram_cache.invalidate("tags_list")
    return tag

@router.delete("/tags/{tag_id}")
async def delete_tag(
    tag_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    from app.models import Tag
    res = await db.execute(select(Tag).where(Tag.id == tag_id))
    tag = res.scalars().first()
    if not tag:
        raise HTTPException(status_code=404, detail="Tag not found.")
    await db.delete(tag)
    await db.commit()
    
    # Invalidate cache
    ram_cache.invalidate("tags_list")
    return {"status": "success", "message": "Tag deleted successfully."}

@router.post("/conversations/{id}/tags", response_model=List[TagResponse])
async def assign_tag_to_conversation(
    id: str,
    payload: TagAssignIn,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    from app.models import Tag
    conv_res = await db.execute(
        select(Conversation)
        .where(Conversation.id == id)
        .options(selectinload(Conversation.tags))
    )
    conv = conv_res.scalars().first()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found.")

    tag_res = await db.execute(select(Tag).where(Tag.id == payload.tag_id))
    tag = tag_res.scalars().first()
    if not tag:
        raise HTTPException(status_code=404, detail="Tag not found.")

    if tag not in conv.tags:
        conv.tags.append(tag)
        await db.commit()
        await db.refresh(conv)

    return conv.tags

@router.delete("/conversations/{id}/tags/{tag_id}", response_model=List[TagResponse])
async def unassign_tag_from_conversation(
    id: str,
    tag_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    conv_res = await db.execute(
        select(Conversation)
        .where(Conversation.id == id)
        .options(selectinload(Conversation.tags))
    )
    conv = conv_res.scalars().first()
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found.")

    target_tag = next((t for t in conv.tags if t.id == tag_id), None)
    if target_tag:
        conv.tags.remove(target_tag)
        await db.commit()
        await db.refresh(conv)

    return conv.tags

@router.post("/copilot/generate")
async def generate_copilot_draft(
    payload: CopilotGenerateIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    import os
    from app.config import settings, resolve_gemini_model
    
    gemini_key = settings.GEMINI_API_KEY or os.getenv("GEMINI_API_KEY")
    if not gemini_key:
        raise HTTPException(
            status_code=400, 
            detail="Gemini API Key is not configured. Please add GEMINI_API_KEY to your environment or .env file."
        )

    # 1. Build thread context if conversation_id is provided
    context = ""
    if payload.conversation_id:
        conv_res = await db.execute(
            select(Conversation)
            .where(Conversation.id == payload.conversation_id)
            .options(selectinload(Conversation.messages))
        )
        conv = conv_res.scalars().first()
        if conv and conv.messages:
            # Sort messages chronologically
            sorted_msgs = sorted(conv.messages, key=lambda m: m.created_at)
            # Take last 8 messages
            last_msgs = sorted_msgs[-8:]
            msg_strings = []
            for m in last_msgs:
                sender_label = "Recipient (Customer)" if m.is_incoming else "Sender (Us)"
                msg_strings.append(f"{sender_label}: {m.body}")
            context = "\n".join(msg_strings)

    # 2. Formulate prompt for Gemini
    system_instruction = (
        "You are an AI Email assistant helping write professional sales, partnership, or customer support emails.\n"
        "Generate ONLY the HTML message body contents. Do NOT include Markdown formatting block tags like ```html or ```. "
        "Do NOT include wrapper html, head, or body tags. Start directly with paragraph <p> or list elements.\n"
        "Keep the output clean, premium, and structured.\n"
    )
    
    full_prompt = f"{system_instruction}\n"
    if context:
        full_prompt += f"Conversation History:\n{context}\n\n"
    
    full_prompt += (
        f"Instructions: Generate a reply using this prompt: '{payload.prompt}'\n"
        f"Tone: {payload.tone}\n"
        "Draft email reply:"
    )

    # 3. Call Google Gemini API
    model = resolve_gemini_model(payload.model or "gemini-2.5-flash")
    
    api_url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={gemini_key}"
    api_payload = {
        "contents": [
            {
                "parts": [
                    {"text": full_prompt}
                ]
            }
        ]
    }
    
    try:
        res = await request.app.state.client.post(api_url, json=api_payload, timeout=25.0)
        if res.status_code != 200:
            raise Exception(f"Gemini API returned status code {res.status_code}: {res.text}")
        
        data = res.json()
        # Extract content from response structure
        generated_text = data['candidates'][0]['content']['parts'][0]['text']
        
        # Clean up potential markdown formatting code blocks if LLM ignored instructions
        cleaned = generated_text.strip()
        if cleaned.startswith("```html"):
            cleaned = cleaned[7:]
        if cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()
        
        return {"status": "success", "draft": cleaned}
            
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Gemini generation failed: {str(e)}"
        )

class CopilotReplyIn(BaseModel):
    thread_context: str
    prompt: str
    tone: Optional[str] = "professional"
    model: Optional[str] = "gemini-2.5-flash"

@router.post("/copilot/reply")
async def generate_copilot_reply(
    payload: CopilotReplyIn,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    import os
    from app.config import settings, resolve_gemini_model
    
    gemini_key = settings.GEMINI_API_KEY or os.getenv("GEMINI_API_KEY")
    if not gemini_key:
        raise HTTPException(
            status_code=400, 
            detail="Gemini API Key is not configured. Please add GEMINI_API_KEY to your environment or .env file."
        )

    # Formulate prompt for Gemini
    system_instruction = (
        "You are an AI Email assistant helping write professional sales, partnership, or customer support emails.\n"
        "Generate ONLY the HTML message body contents. Do NOT include Markdown formatting block tags like ```html or ```. "
        "Do NOT include wrapper html, head, or body tags. Start directly with paragraph <p> or list elements.\n"
        "Keep the output clean, premium, and structured.\n"
    )
    
    full_prompt = f"{system_instruction}\n"
    full_prompt += f"Conversation History:\n{payload.thread_context}\n\n"
    full_prompt += (
        f"Instructions: Generate a contextual reply using this prompt: '{payload.prompt}'\n"
        f"Tone: {payload.tone}\n"
        "Draft email reply:"
    )

    # Call Google Gemini API
    model = resolve_gemini_model(payload.model or "gemini-2.5-flash")
    
    api_url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={gemini_key}"
    api_payload = {
        "contents": [
            {
                "parts": [
                    {"text": full_prompt}
                ]
            }
        ]
    }
    
    try:
        res = await request.app.state.client.post(api_url, json=api_payload, timeout=25.0)
        if res.status_code != 200:
            raise Exception(f"Gemini API returned status code {res.status_code}: {res.text}")
        
        data = res.json()
        # Extract content from response structure
        generated_text = data['candidates'][0]['content']['parts'][0]['text']
        
        # Clean up potential markdown formatting code blocks if LLM ignored instructions
        cleaned = generated_text.strip()
        if cleaned.startswith("```html"):
            cleaned = cleaned[7:]
        if cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()
        
        return {"status": "success", "draft": cleaned}
            
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Gemini reply generation failed: {str(e)}"
        )

@router.post("/conversations/{id}/read")
async def mark_conversation_as_read(
    id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    msg_res = await db.execute(
        select(Message).where(Message.conversation_id == id, Message.is_incoming == True)
    )
    messages = msg_res.scalars().all()
    updated = False
    for m in messages:
        if m.is_unread:
            m.is_unread = False
            updated = True
    if updated:
        await db.commit()
    return {"status": "success", "message": "Marked as read"}

@router.post("/conversations/{id}/unread")
async def mark_conversation_as_unread(
    id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Fetch the latest incoming message to mark as unread
    msg_res = await db.execute(
        select(Message)
        .where(Message.conversation_id == id, Message.is_incoming == True)
        .order_by(Message.created_at.desc())
        .limit(1)
    )
    msg = msg_res.scalars().first()
    if msg:
        msg.is_unread = True
        await db.commit()
    return {"status": "success", "message": "Marked as unread"}

@router.delete("/conversations/{id}")
async def delete_conversation(
    id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # 1. Try to find and delete as Conversation
    conv_res = await db.execute(
        select(Conversation).where(Conversation.id == id)
    )
    conv = conv_res.scalars().first()
    if conv:
        await db.delete(conv)
        await db.commit()
        return {"status": "success", "message": "Conversation deleted"}

    # 2. Try to find and delete as Message (Sent folder)
    msg_res = await db.execute(
        select(Message).where(Message.id == id)
    )
    msg = msg_res.scalars().first()
    if msg:
        conversation_id = msg.conversation_id
        await db.delete(msg)
        await db.flush()
        
        # If conversation has no more messages, clean it up
        remaining_res = await db.execute(
            select(Message).where(Message.conversation_id == conversation_id)
        )
        remaining = remaining_res.scalars().all()
        if not remaining:
            conv_to_del_res = await db.execute(
                select(Conversation).where(Conversation.id == conversation_id)
            )
            conv_to_del = conv_to_del_res.scalars().first()
            if conv_to_del:
                await db.delete(conv_to_del)
                
        await db.commit()
        return {"status": "success", "message": "Message deleted"}

    # 3. Try to find and delete as Draft
    draft_res = await db.execute(
        select(Draft).where(Draft.id == id)
    )
    draft = draft_res.scalars().first()
    if draft:
        await db.delete(draft)
        await db.commit()
        return {"status": "success", "message": "Draft deleted"}

    # 4. Try to find and delete as EmailQueue (Scheduled folder)
    queue_res = await db.execute(
        select(EmailQueue).where(EmailQueue.id == id)
    )
    queue_item = queue_res.scalars().first()
    if queue_item:
        await db.delete(queue_item)
        await db.commit()
        return {"status": "success", "message": "Scheduled message deleted"}

    raise HTTPException(status_code=404, detail="Item not found")

