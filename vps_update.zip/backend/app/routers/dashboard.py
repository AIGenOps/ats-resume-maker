from datetime import date, datetime
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func, desc
from sqlalchemy.orm import selectinload
from typing import Dict, Any, List

from app.database import get_db
from app.models import Contact, Campaign, EmailQueue, AuditLog, SMTPAccount, User, ContactReply
from app.auth import get_current_user

router = APIRouter(prefix="/dashboard", tags=["dashboard"])

@router.get("/metrics")
async def get_dashboard_metrics(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Total Contacts
    contacts_count = await db.execute(select(func.count(Contact.id)))
    total_contacts = contacts_count.scalar() or 0
    
    # Active campaigns
    camps_count = await db.execute(select(func.count(Campaign.id)).where(Campaign.status == "running"))
    active_campaigns = camps_count.scalar() or 0
    
    # Email stats
    today_start = datetime.combine(date.today(), datetime.min.time())
    sent_today = await db.execute(
        select(func.count(EmailQueue.id)).where(
            (EmailQueue.status == "sent") &
            (EmailQueue.sent_time >= today_start)
        )
    )
    sent_today_count = sent_today.scalar() or 0
    
    pending_queue = await db.execute(
        select(func.count(EmailQueue.id)).where(
            EmailQueue.status.in_(["pending", "sending", "retrying"])
        )
    )
    pending_count = pending_queue.scalar() or 0
    
    failed_queue = await db.execute(
        select(func.count(EmailQueue.id)).where(
            EmailQueue.status == "failed"
        )
    )
    failed_count = failed_queue.scalar() or 0
    
    # SMTP Health
    smtp_count = await db.execute(select(func.count(SMTPAccount.id)))
    smtp_total = smtp_count.scalar() or 0
    
    # Recent Activities
    audit_res = await db.execute(
        select(AuditLog).order_by(desc(AuditLog.created_at)).limit(10)
    )
    audits = audit_res.scalars().all()
    
    recent_activities = []
    for audit in audits:
        recent_activities.append({
            "id": audit.id,
            "action": audit.action,
            "details": audit.details,
        })

        import datetime as dt
        seven_days_ago = date.today() - dt.timedelta(days=6)
        
        # Query sent volume trend for last 7 days
        daily_trend = []
        for i in range(7):
            day_date = seven_days_ago + dt.timedelta(days=i)
            day_start = datetime.combine(day_date, datetime.min.time())
            day_end = datetime.combine(day_date, datetime.max.time())
            
            day_sent_res = await db.execute(
                select(func.count(EmailQueue.id)).where(
                    (EmailQueue.status == "sent") &
                    (EmailQueue.sent_time >= day_start) &
                    (EmailQueue.sent_time <= day_end)
                )
            )
            day_sent = day_sent_res.scalar() or 0
            
            # Format label e.g., "Mon", "Tue"
            day_label = day_date.strftime("%a")
            daily_trend.append({
                "label": day_label,
                "value": day_sent
            })
            
        # Campaign performance monthly open rate for last 6 months
        monthly_performance = []
        today = date.today()
        for i in range(5, -1, -1):
            month = today.month - i
            year = today.year
            while month <= 0:
                month += 12
                year -= 1
                
            month_start = datetime(year, month, 1)
            if month == 12:
                next_month_start = datetime(year + 1, 1, 1)
            else:
                next_month_start = datetime(year, month + 1, 1)
                
            total_sent_res = await db.execute(
                select(func.count(EmailQueue.id)).where(
                    (EmailQueue.status == "sent") &
                    (EmailQueue.sent_time >= month_start) &
                    (EmailQueue.sent_time < next_month_start)
                )
            )
            total_sent_count = total_sent_res.scalar() or 0
            
            opened_res = await db.execute(
                select(func.count(EmailQueue.id)).where(
                    (EmailQueue.status == "sent") &
                    (EmailQueue.opened == True) &
                    (EmailQueue.sent_time >= month_start) &
                    (EmailQueue.sent_time < next_month_start)
                )
            )
            opened_count = opened_res.scalar() or 0
            
            open_rate = round((opened_count / total_sent_count * 100)) if total_sent_count > 0 else 0
            month_label = month_start.strftime("%b")
            monthly_performance.append({
                "label": month_label,
                "value": open_rate
            })

        # Calculate real reply rate
        replied_count_res = await db.execute(select(func.count(Contact.id)).where(Contact.status == "replied"))
        replied_contacts = replied_count_res.scalar() or 0
        reply_rate = f"{((replied_contacts / total_contacts) * 100):.1f}%" if total_contacts > 0 else "0%"

        # Calculate real open rate
        total_sent_all = await db.execute(select(func.count(EmailQueue.id)).where(EmailQueue.status == "sent"))
        total_sent_all_count = total_sent_all.scalar() or 0
        total_opened_all = await db.execute(select(func.count(EmailQueue.id)).where((EmailQueue.status == "sent") & (EmailQueue.opened == True)))
        total_opened_all_count = total_opened_all.scalar() or 0
        open_rate_all = f"{((total_opened_all_count / total_sent_all_count) * 100):.1f}%" if total_sent_all_count > 0 else "0%"

        return {
            "metrics": {
                "total_contacts": total_contacts,
                "active_campaigns": active_campaigns,
                "emails_sent_today": sent_today_count,
                "emails_queued": pending_count,
                "emails_failed": failed_count,
                "smtp_accounts": smtp_total,
                "smtp_health": "Healthy" if smtp_total > 0 else "No accounts configured",
                "domain_health": "SPF/DKIM Valid",
                "bounce_rate": f"{((failed_count / (sent_today_count + failed_count)) * 100):.1f}%" if (sent_today_count + failed_count) > 0 else "0%",
                "reply_rate": reply_rate,
                "open_rate": open_rate_all
            },
            "recent_activity": recent_activities,
            "daily_trend": daily_trend,
            "monthly_performance": monthly_performance
        }

@router.get("/recent-replies", response_model=List[Dict[str, Any]])
async def get_recent_replies(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(ContactReply)
        .options(selectinload(ContactReply.contact))
        .order_by(desc(ContactReply.received_at))
        .limit(5)
    )
    replies = result.scalars().all()
    
    data = []
    for r in replies:
        data.append({
            "id": r.id,
            "contact_id": r.contact_id,
            "contact_name": r.contact.full_name if r.contact else "Unknown Contact",
            "contact_email": r.contact.email if r.contact else "",
            "subject": r.subject,
            "snippet": r.snippet,
            "received_at": r.received_at.isoformat()
        })
    return data

@router.get("/audit-logs", response_model=List[Dict[str, Any]])
async def get_all_audit_logs(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(AuditLog)
        .options(selectinload(AuditLog.user))
        .order_by(desc(AuditLog.created_at))
        .limit(100)
    )
    audits = result.scalars().all()
    
    logs = []
    for audit in audits:
        logs.append({
            "id": audit.id,
            "action": audit.action,
            "details": audit.details,
            "timestamp": audit.created_at.isoformat(),
            "actor_email": audit.user.email if audit.user else "System",
            "actor_name": audit.user.full_name if audit.user else "System",
            "ip_address": audit.ip_address or "N/A",
            "user_agent": audit.user_agent or "N/A"
        })
    return logs
