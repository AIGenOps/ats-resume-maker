import os
import json
import logging
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from typing import Dict, Any

from app.auth import get_current_user
from app.models import User
from app.config import settings, DISCORD_WEBHOOKS_FILE

logger = logging.getLogger("app.routers.settings")
router = APIRouter(prefix="/settings", tags=["settings"])

class WebhooksUpdateSchema(BaseModel):
    webhooks: Dict[str, Any]

@router.get("/webhooks")
async def get_webhooks(current_user: User = Depends(get_current_user)):
    try:
        if os.path.exists(DISCORD_WEBHOOKS_FILE):
            with open(DISCORD_WEBHOOKS_FILE, "r", encoding="utf-8") as f:
                webhooks_data = json.load(f)
        else:
            webhooks_data = {
                "FAILED_MAILS_WEBHOOK": settings.FAILED_MAILS_WEBHOOK,
                "GENERAL_MAILS_WEBHOOK": settings.GENERAL_MAILS_WEBHOOK,
                "CUSTOM_CATEGORIES": settings.CUSTOM_CATEGORIES
            }
        return webhooks_data
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to read webhooks configuration: {str(e)}"
        )

@router.post("/webhooks")
async def update_webhooks(
    payload: WebhooksUpdateSchema,
    current_user: User = Depends(get_current_user)
):
    try:
        new_webhooks = payload.webhooks
        
        # Save to file
        with open(DISCORD_WEBHOOKS_FILE, "w", encoding="utf-8") as f:
            json.dump(new_webhooks, f, indent=4)
            
        # Update settings object in memory dynamically
        for key, val in new_webhooks.items():
            if hasattr(settings, key):
                setattr(settings, key, val)
                
        return {"success": True, "message": "Webhook configurations saved successfully."}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to save webhooks configuration: {str(e)}"
        )
