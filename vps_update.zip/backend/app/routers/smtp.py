from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from pydantic import BaseModel
from typing import Optional, List
import aiosmtplib

from app.database import get_db
from app.models import SMTPAccount, User, AuditLog
from app.auth import get_current_user

router = APIRouter(prefix="/smtp", tags=["smtp"])

class SMTPCreate(BaseModel):
    name: str
    host: str
    port: int = 587
    username: str
    password_encrypted: str # Password raw (since we simulate database encryption)
    from_email: str
    rate_limit_daily: int = 500
    rate_limit_hourly: int = 50

class SMTPResponse(BaseModel):
    id: str
    name: str
    host: str
    port: int
    username: str
    from_email: str
    rate_limit_daily: int
    rate_limit_hourly: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True

@router.get("/", response_model=List[SMTPResponse])
async def get_smtp_accounts(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = select(SMTPAccount)
    result = await db.execute(query)
    return result.scalars().all()

@router.post("/", response_model=SMTPResponse)
async def create_smtp_account(
    smtp_in: SMTPCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Check duplicate
    dup_res = await db.execute(select(SMTPAccount).where(SMTPAccount.name == smtp_in.name))
    if dup_res.scalars().first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="SMTP configurations name must be unique."
        )
        
    from app.services.crypto import encrypt_password
    new_smtp = SMTPAccount(
        name=smtp_in.name,
        host=smtp_in.host,
        port=smtp_in.port,
        username=smtp_in.username,
        password_encrypted=encrypt_password(smtp_in.password_encrypted),
        from_email=smtp_in.from_email,
        rate_limit_daily=smtp_in.rate_limit_daily,
        rate_limit_hourly=smtp_in.rate_limit_hourly
    )
    db.add(new_smtp)
    
    # Audit log
    audit = AuditLog(
        user_id=current_user.id,
        action="SMTP Configuration Added",
        details=f"SMTP configuration '{smtp_in.name}' added."
    )
    db.add(audit)
    
    await db.commit()
    await db.refresh(new_smtp)
    return new_smtp

@router.post("/{smtp_id}/test")
async def test_smtp_connection(
    smtp_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(SMTPAccount).where(SMTPAccount.id == smtp_id))
    smtp = result.scalars().first()
    if not smtp:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="SMTP account not found"
        )
        
    try:
        import ssl
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

        use_tls = (smtp.port == 465)
        smtp_client = aiosmtplib.SMTP(
            hostname=smtp.host,
            port=smtp.port,
            use_tls=use_tls,
            validate_certs=False,
            tls_context=ssl_context
        )
        await smtp_client.connect()
        if smtp.port == 587:
            try:
                await smtp_client.starttls(validate_certs=False, tls_context=ssl_context)
            except Exception as e:
                if "already using TLS" not in str(e):
                    raise

        if smtp.username and smtp.password_encrypted:
            from app.services.crypto import decrypt_password
            decrypted_pw = decrypt_password(smtp.password_encrypted)
            await smtp_client.login(smtp.username, decrypted_pw)
        await smtp_client.quit()
        return {"success": True, "message": "SMTP Connection test successful!"}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Connection failed: {str(e)}"
        )

@router.delete("/{smtp_id}")
async def delete_smtp_account(
    smtp_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(SMTPAccount).where(SMTPAccount.id == smtp_id))
    smtp = result.scalars().first()
    if not smtp:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="SMTP account not found"
        )
    await db.delete(smtp)
    await db.commit()
    return {"message": "SMTP configuration deleted."}
