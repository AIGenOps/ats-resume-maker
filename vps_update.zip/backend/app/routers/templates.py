from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import desc
from pydantic import BaseModel
from typing import Optional, List

from app.database import get_db
from app.models import Template, User
from app.auth import get_current_user

router = APIRouter(prefix="/templates", tags=["templates"])

class TemplateCreate(BaseModel):
    name: str
    folder: str = "General"
    subject: str
    body_html: str
    body_text: Optional[str] = None
    variables: Optional[List[str]] = []

class TemplateResponse(BaseModel):
    id: str
    name: str
    folder: str
    subject: str
    body_html: str
    body_text: Optional[str]
    variables: Optional[List[str]]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

@router.get("/", response_model=List[TemplateResponse])
async def get_templates(
    folder: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = select(Template)
    if folder:
        query = query.where(Template.folder == folder)
    query = query.order_by(desc(Template.created_at))
    result = await db.execute(query)
    return result.scalars().all()

@router.post("/", response_model=TemplateResponse)
async def create_template(
    template_in: TemplateCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Check duplicate name
    dup_res = await db.execute(select(Template).where(Template.name == template_in.name))
    if dup_res.scalars().first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Template with this name already exists."
        )
        
    new_template = Template(
        name=template_in.name,
        folder=template_in.folder,
        subject=template_in.subject,
        body_html=template_in.body_html,
        body_text=template_in.body_text,
        variables=template_in.variables or []
    )
    db.add(new_template)
    await db.commit()
    await db.refresh(new_template)
    return new_template

@router.get("/{template_id}", response_model=TemplateResponse)
async def get_template(
    template_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Template).where(Template.id == template_id))
    template = result.scalars().first()
    if not template:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Template not found"
        )
    return template

@router.put("/{template_id}", response_model=TemplateResponse)
async def update_template(
    template_id: str,
    template_in: TemplateCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Template).where(Template.id == template_id))
    template = result.scalars().first()
    if not template:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Template not found"
        )
        
    # Check duplicate name if name changed
    if template.name != template_in.name:
        dup_res = await db.execute(select(Template).where(Template.name == template_in.name))
        if dup_res.scalars().first():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Template with this name already exists."
            )
            
    template.name = template_in.name
    template.folder = template_in.folder
    template.subject = template_in.subject
    template.body_html = template_in.body_html
    template.body_text = template_in.body_text
    template.variables = template_in.variables or []
    
    await db.commit()
    await db.refresh(template)
    return template

@router.delete("/{template_id}")
async def delete_template(
    template_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Template).where(Template.id == template_id))
    template = result.scalars().first()
    if not template:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Template not found"
        )
    await db.delete(template)
    await db.commit()
    return {"message": "Template deleted successfully"}
