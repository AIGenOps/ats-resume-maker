from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import or_, desc, func
from pydantic import BaseModel, EmailStr
from typing import Optional, List, Dict, Any
import csv
import io
import json

from app.database import get_db
from app.models import Contact, Tag, ContactNote, contact_tags, User
from app.auth import get_current_user
from sqlalchemy.orm import selectinload

router = APIRouter(prefix="/contacts", tags=["contacts"])

class TagSchema(BaseModel):
    id: str
    name: str
    color: str
    class Config:
        from_attributes = True

class TagCreateSchema(BaseModel):
    name: str
    color: Optional[str] = "#3b82f6"

class NoteCreate(BaseModel):
    content: str

class NoteResponse(BaseModel):
    id: str
    contact_id: str
    author_name: str
    content: str
    created_at: datetime
    class Config:
        from_attributes = True

class ContactCreate(BaseModel):
    full_name: str
    email: EmailStr
    company: Optional[str] = None
    designation: Optional[str] = None
    phone: Optional[str] = None
    website: Optional[str] = None
    linkedin: Optional[str] = None
    status: str = "active"
    source: str = "manual"
    custom_fields: Optional[Dict[str, Any]] = None
    tags: Optional[List[str]] = None # List of tag names

class ContactResponse(BaseModel):
    id: str
    full_name: str
    email: str
    company: Optional[str]
    designation: Optional[str]
    phone: Optional[str]
    website: Optional[str]
    linkedin: Optional[str]
    status: str
    source: Optional[str]
    custom_fields: Optional[Dict[str, Any]]
    created_at: datetime
    updated_at: datetime
    tags: List[TagSchema] = []
    class Config:
        from_attributes = True

class ContactDetailResponse(BaseModel):
    contact: ContactResponse
    notes: List[NoteResponse]

class PaginatedContactsResponse(BaseModel):
    contacts: List[ContactResponse]
    total: int
    page: int
    pages: int

@router.get("/", response_model=PaginatedContactsResponse)
async def get_contacts(
    search: Optional[str] = None,
    tag: Optional[str] = None,
    status_filter: Optional[str] = None,
    page: int = 1,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = select(Contact).options(selectinload(Contact.tags))
    
    # Filtering
    filters = []
    if search:
        search_term = f"%{search}%"
        filters.append(
            or_(
                Contact.full_name.ilike(search_term),
                Contact.email.ilike(search_term),
                Contact.company.ilike(search_term),
                Contact.designation.ilike(search_term)
            )
        )
    if status_filter:
        filters.append(Contact.status == status_filter)
        
    if tag:
        # Join contact_tags and tags to filter
        query = query.join(Contact.tags).where(Tag.name == tag)
        
    if filters:
        query = query.where(*filters)
        
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await db.execute(count_query)
    total = total_result.scalar() or 0
    
    # Pagination & Execution
    query = query.order_by(desc(Contact.created_at)).offset((page - 1) * limit).limit(limit)
    result = await db.execute(query)
    contacts = result.scalars().all()
    
    return {
        "contacts": contacts,
        "total": total,
        "page": page,
        "pages": (total + limit - 1) // limit
    }

@router.post("/", response_model=ContactResponse)
async def create_contact(
    contact_in: ContactCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Check duplicate email
    dup_check = await db.execute(select(Contact).where(Contact.email == contact_in.email))
    if dup_check.scalars().first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Contact with this email already exists."
        )
        
    new_contact = Contact(
        full_name=contact_in.full_name,
        email=contact_in.email,
        company=contact_in.company,
        designation=contact_in.designation,
        phone=contact_in.phone,
        website=contact_in.website,
        linkedin=contact_in.linkedin,
        status=contact_in.status,
        source=contact_in.source,
        custom_fields=contact_in.custom_fields or {}
    )
    
    # Load or create tags
    if contact_in.tags:
        for t_name in contact_in.tags:
            tag_res = await db.execute(select(Tag).where(Tag.name == t_name))
            tag_obj = tag_res.scalars().first()
            if not tag_obj:
                tag_obj = Tag(name=t_name)
                db.add(tag_obj)
            new_contact.tags.append(tag_obj)
            
    db.add(new_contact)
    await db.commit()
    
    # Eagerly load the created contact with tags to prevent serialization errors
    res = await db.execute(
        select(Contact).options(selectinload(Contact.tags)).where(Contact.id == new_contact.id)
    )
    return res.scalars().first()

@router.post("/import")
async def import_contacts_csv(
    file: UploadFile = File(...),
    default_tag: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    contents = await file.read()
    # Use utf-8-sig to automatically strip the UTF-8 Byte Order Mark (BOM) if present
    contents_str = contents.decode('utf-8-sig', errors='ignore')
    lines = [line.strip() for line in contents_str.splitlines() if line.strip()]
    if not lines:
        return {
            "success": True,
            "message": "CSV file is empty.",
            "summary": {
                "added": 0,
                "updated": 0,
                "duplicates_skipped": 0,
                "failed": 0
            },
            "errors": [],
            "tag": None
        }
        
    # Check if the first line is a header or a raw email
    first_line = lines[0].lower()
    has_headers = True
    if "@" in first_line:
        if not any(h in first_line for h in ["email", "name", "full_name"]):
            has_headers = False
            
    rows_to_process = []
    
    if has_headers:
        buffer = io.StringIO(contents_str)
        reader = csv.DictReader(buffer)
        for row in reader:
            # Clean header keys and row values
            cleaned_row = {}
            for k, v in row.items():
                if k is not None:
                    cleaned_row[str(k).strip().lower()] = str(v).strip() if v is not None else ""
            rows_to_process.append(cleaned_row)
    else:
        for line in lines:
            parts = [p.strip() for p in line.split(",")]
            if parts and "@" in parts[0]:
                email_val = parts[0]
                name_val = parts[1] if len(parts) > 1 else ""
                row = {"email": email_val.strip().lower(), "name": name_val}
                rows_to_process.append(row)
                
    processed_emails = {}
    failed_rows = []
    duplicates_skipped = 0
    row_num = 1 if has_headers else 0
    
    for row in rows_to_process:
        row_num += 1
        
        # Locate the email field
        email = ""
        for k in ["email", "e-mail"]:
            if k in row:
                email = str(row[k]).strip().lower()
                break
        if not email:
            # Fallback search for any value containing @
            for k, v in row.items():
                if v and "@" in str(v):
                    email = str(v).strip().lower()
                    break
                    
        if not email:
            failed_rows.append({
                "row": row_num,
                "email": "N/A",
                "reason": "Missing email field"
            })
            continue
            
        if "@" not in email or email.count("@") != 1:
            failed_rows.append({
                "row": row_num,
                "email": email,
                "reason": "Invalid email format (must contain exactly one @ symbol)"
            })
            continue
            
        parts = email.split("@")
        if not parts[0] or not parts[1]:
            failed_rows.append({
                "row": row_num,
                "email": email,
                "reason": "Invalid email format (empty local or domain part)"
            })
            continue
            
        # Extract name/full_name
        full_name = ""
        for k in ["name", "full_name", "fullname", "contact name"]:
            if k in row:
                full_name = str(row[k]).strip()
                break
        if not full_name:
            local_part = email.split("@")[0]
            full_name = local_part.replace(".", " ").replace("-", " ").replace("_", " ").title()
            
        company = row.get("company", "").strip() if row.get("company") else None
        designation = row.get("designation", "").strip() if row.get("designation") else None
        phone = row.get("phone", "").strip() if row.get("phone") else None
        website = row.get("website", "").strip() if row.get("website") else None
        linkedin = row.get("linkedin", "").strip() if row.get("linkedin") else None
        
        tags_raw = row.get("tags", "").strip() if row.get("tags") else ""
        tags_list = [t.strip() for t in tags_raw.split(",") if t.strip()] if tags_raw else []
        
        customs = {}
        for key, val in row.items():
            if key and str(key).strip().lower() not in ["email", "e-mail", "name", "full_name", "fullname", "contact name", "company", "designation", "phone", "website", "linkedin", "tags"]:
                customs[str(key).strip()] = val
                
        # Check if already processed in this CSV (in-file duplicate)
        if email in processed_emails:
            duplicates_skipped += 1
            
        processed_emails[email] = {
            "row_num": row_num,
            "full_name": full_name,
            "company": company,
            "designation": designation,
            "phone": phone,
            "website": website,
            "linkedin": linkedin,
            "tags": tags_list,
            "custom_fields": customs
        }
        
    imported = 0
    updated = 0
    
    # Resolve default tag if provided (lookup by UUID first, then name)
    default_tag_obj = None
    if default_tag:
        default_tag_stripped = default_tag.strip()
        if default_tag_stripped:
            tag_obj = None
            if len(default_tag_stripped) == 36:
                # Try UUID lookup
                t_res = await db.execute(select(Tag).where(Tag.id == default_tag_stripped))
                tag_obj = t_res.scalars().first()
            if not tag_obj:
                # Try Name lookup
                t_res = await db.execute(select(Tag).where(Tag.name == default_tag_stripped))
                tag_obj = t_res.scalars().first()
            if not tag_obj and default_tag_stripped != "1":
                # Create a new tag if name is not a raw ID fallback "1"
                tag_obj = Tag(name=default_tag_stripped)
                db.add(tag_obj)
                await db.flush()
            default_tag_obj = tag_obj
            
    try:
        for email, info in processed_emails.items():
            dup_res = await db.execute(
                select(Contact).options(selectinload(Contact.tags)).where(Contact.email == email)
            )
            contact = dup_res.scalars().first()
            
            if contact:
                # UPSERT: update contact details (last occurrence in file wins)
                contact.full_name = info["full_name"]
                if info["company"] is not None:
                    contact.company = info["company"]
                if info["designation"] is not None:
                    contact.designation = info["designation"]
                if info["phone"] is not None:
                    contact.phone = info["phone"]
                if info["website"] is not None:
                    contact.website = info["website"]
                if info["linkedin"] is not None:
                    contact.linkedin = info["linkedin"]
                    
                existing_customs = contact.custom_fields or {}
                existing_customs.update(info["custom_fields"])
                contact.custom_fields = existing_customs
                
                # COMPLIANCE-CRITICAL: Preserve opt-out status (unsubscribed, bounced, inactive)
                if contact.status in ["unsubscribed", "bounced", "inactive"]:
                    pass
                else:
                    contact.status = "active"
                    
                # Link default tag
                if default_tag_obj and default_tag_obj not in contact.tags:
                    contact.tags.append(default_tag_obj)
                    
                # Link row tags
                for t_name in info["tags"]:
                    t_res = await db.execute(select(Tag).where(Tag.name == t_name))
                    t_obj = t_res.scalars().first()
                    if not t_obj:
                        t_obj = Tag(name=t_name)
                        db.add(t_obj)
                        await db.flush()
                    if t_obj not in contact.tags:
                        contact.tags.append(t_obj)
                updated += 1
            else:
                # New contact creation
                new_contact = Contact(
                    full_name=info["full_name"],
                    email=email,
                    company=info["company"],
                    designation=info["designation"],
                    phone=info["phone"],
                    website=info["website"],
                    linkedin=info["linkedin"],
                    status="active",
                    source="csv",
                    custom_fields=info["custom_fields"]
                )
                if default_tag_obj:
                    new_contact.tags.append(default_tag_obj)
                    
                for t_name in info["tags"]:
                    t_res = await db.execute(select(Tag).where(Tag.name == t_name))
                    t_obj = t_res.scalars().first()
                    if not t_obj:
                        t_obj = Tag(name=t_name)
                        db.add(t_obj)
                        await db.flush()
                    if t_obj not in new_contact.tags:
                        new_contact.tags.append(t_obj)
                db.add(new_contact)
                imported += 1
                
        await db.commit()
    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to commit CSV import transactions: {str(e)}"
        )
        
    return {
        "success": True,
        "message": f"CSV processing complete. Added: {imported}, Updated: {updated}, Duplicates Skipped: {duplicates_skipped}, Failed: {len(failed_rows)}",
        "summary": {
            "added": imported,
            "updated": updated,
            "duplicates_skipped": duplicates_skipped,
            "failed": len(failed_rows)
        },
        "errors": failed_rows,
        "tag": {
            "id": default_tag_obj.id,
            "name": default_tag_obj.name,
            "color": default_tag_obj.color
        } if default_tag_obj else None
    }

@router.get("/export/csv")
async def export_contacts_csv(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Contact))
    contacts = result.scalars().all()
    
    stream = io.StringIO()
    writer = csv.writer(stream)
    writer.writerow(["id", "name", "email", "company", "designation", "phone", "website", "linkedin", "status", "source", "created_at"])
    
    for c in contacts:
        writer.writerow([
            c.id, c.full_name, c.email, c.company or "", c.designation or "",
            c.phone or "", c.website or "", c.linkedin or "", c.status, c.source or "",
            c.created_at.isoformat()
        ])
        
    response = StreamingResponse(iter([stream.getvalue()]), media_type="text/csv")
    response.headers["Content-Disposition"] = "attachment; filename=contacts.csv"
    return response

@router.get("/tags", response_model=List[TagSchema])
async def get_all_tags(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Tag).order_by(Tag.name))
    return result.scalars().all()

@router.get("/{contact_id}", response_model=ContactDetailResponse)
async def get_contact_detail(
    contact_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(Contact).options(selectinload(Contact.tags)).where(Contact.id == contact_id)
    )
    contact = result.scalars().first()
    if not contact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contact not found"
        )
    
    # Load notes
    notes_result = await db.execute(
        select(ContactNote).where(ContactNote.contact_id == contact_id).order_by(desc(ContactNote.created_at))
    )
    notes = notes_result.scalars().all()
    
    return {
        "contact": contact,
        "notes": notes
    }

@router.put("/{contact_id}", response_model=ContactResponse)
async def update_contact(
    contact_id: str,
    contact_in: ContactCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(
        select(Contact).options(selectinload(Contact.tags)).where(Contact.id == contact_id)
    )
    contact = result.scalars().first()
    if not contact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contact not found"
        )
        
    # Check duplicate email if email is being changed
    if contact.email != contact_in.email:
        dup_check = await db.execute(select(Contact).where(Contact.email == contact_in.email))
        if dup_check.scalars().first():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Contact with this email already exists."
            )
            
    contact.full_name = contact_in.full_name
    contact.email = contact_in.email
    contact.company = contact_in.company
    contact.designation = contact_in.designation
    contact.phone = contact_in.phone
    contact.website = contact_in.website
    contact.linkedin = contact_in.linkedin
    contact.status = contact_in.status
    contact.custom_fields = contact_in.custom_fields or {}
    
    # Update tags
    contact.tags.clear()
    if contact_in.tags:
        for t_name in contact_in.tags:
            tag_res = await db.execute(select(Tag).where(Tag.name == t_name))
            tag_obj = tag_res.scalars().first()
            if not tag_obj:
                tag_obj = Tag(name=t_name)
                db.add(tag_obj)
            contact.tags.append(tag_obj)
            
    await db.commit()
    
    # Eagerly load the updated contact with tags to prevent serialization errors
    res = await db.execute(
        select(Contact).options(selectinload(Contact.tags)).where(Contact.id == contact.id)
    )
    return res.scalars().first()

@router.delete("/{contact_id}")
async def delete_contact(
    contact_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Contact).where(Contact.id == contact_id))
    contact = result.scalars().first()
    if not contact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contact not found"
        )
    await db.delete(contact)
    await db.commit()
    return {"message": "Contact deleted successfully"}

@router.post("/{contact_id}/notes", response_model=NoteResponse)
async def add_contact_note(
    contact_id: str,
    note_in: NoteCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Contact).where(Contact.id == contact_id))
    contact = result.scalars().first()
    if not contact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contact not found"
        )
        
    new_note = ContactNote(
        contact_id=contact_id,
        author_name=current_user.full_name,
        content=note_in.content
    )
    db.add(new_note)
    await db.commit()
    await db.refresh(new_note)
    return new_note

@router.post("/tags", response_model=TagSchema)
async def create_tag(
    tag_in: TagCreateSchema,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    tag_name_stripped = tag_in.name.strip()
    if not tag_name_stripped:
        raise HTTPException(status_code=400, detail="Group/Tag name cannot be empty")
    
    result = await db.execute(select(Tag).where(Tag.name == tag_name_stripped))
    existing = result.scalars().first()
    if existing:
        raise HTTPException(status_code=400, detail="Group/Tag already exists")
        
    new_tag = Tag(name=tag_name_stripped, color=tag_in.color or "#3b82f6")
    db.add(new_tag)
    await db.commit()
    await db.refresh(new_tag)
    return new_tag

@router.delete("/tags/{tag_id}")
async def delete_tag(
    tag_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Tag).where(Tag.id == tag_id))
    tag_obj = result.scalars().first()
    if not tag_obj:
        raise HTTPException(status_code=404, detail="Group/Tag not found")
        
    await db.delete(tag_obj)
    await db.commit()
    return {"message": "Group/Tag deleted successfully"}
