import asyncio
from datetime import datetime, timezone, timedelta, time
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks, Response
from fastapi.responses import HTMLResponse
from jose import jwt, JWTError
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import desc, func, delete
from pydantic import BaseModel
from typing import Optional, List, Dict, Any

from app.database import get_db, SessionLocal, get_ist_time
from app.auth import get_current_user
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import aiosmtplib
from app.config import settings
from app.models import Campaign, Template, EmailQueue, Contact, User, AuditLog, SMTPAccount, ContactNote, Conversation, Message, Tag

router = APIRouter(prefix="/campaigns", tags=["campaigns"])

class CampaignCreate(BaseModel):
    name: str
    description: Optional[str] = None
    template_id: str
    sender: str
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    send_delay_seconds: Optional[int] = 1
    batch_size: Optional[int] = 50
    stop_on_reply: Optional[bool] = True
    max_retries: Optional[int] = 3
    track_opens: Optional[bool] = False
    weekdays_only: Optional[bool] = True
    send_window_start: Optional[str] = "09:00"
    send_window_end: Optional[str] = "17:00"
    warmup_enabled: Optional[bool] = False
    warmup_start_limit: Optional[int] = 10
    warmup_increment: Optional[int] = 5
    target_tag_id: Optional[str] = None

class CampaignResponse(BaseModel):
    id: str
    name: str
    description: Optional[str]
    owner_id: str
    status: str
    template_id: str
    sender: str
    start_date: Optional[datetime]
    end_date: Optional[datetime]
    created_at: datetime
    updated_at: datetime
    send_delay_seconds: int
    batch_size: int
    stop_on_reply: bool
    max_retries: int
    track_opens: bool
    weekdays_only: bool
    send_window_start: Optional[str]
    send_window_end: Optional[str]
    warmup_enabled: bool
    warmup_start_limit: int
    warmup_increment: int
    target_tag_id: Optional[str] = None

    class Config:
        from_attributes = True

class CampaignStats(BaseModel):
    sent: int
    pending: int
    failed: int
    total: int
    opened: int = 0

class CampaignDetailResponse(BaseModel):
    campaign: CampaignResponse
    stats: CampaignStats

@router.get("/", response_model=List[CampaignResponse])
async def get_campaigns(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    query = select(Campaign).order_by(desc(Campaign.created_at))
    result = await db.execute(query)
    return result.scalars().all()

@router.post("/", response_model=CampaignResponse)
async def create_campaign(
    camp_in: CampaignCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Check if template exists
    temp_res = await db.execute(select(Template).where(Template.id == camp_in.template_id))
    if not temp_res.scalars().first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Specified template does not exist."
        )
        
    new_campaign = Campaign(
        name=camp_in.name,
        description=camp_in.description,
        owner_id=current_user.id,
        template_id=camp_in.template_id,
        sender=camp_in.sender,
        status="draft",
        start_date=camp_in.start_date,
        end_date=camp_in.end_date,
        send_delay_seconds=camp_in.send_delay_seconds,
        batch_size=camp_in.batch_size,
        stop_on_reply=camp_in.stop_on_reply,
        max_retries=camp_in.max_retries,
        track_opens=camp_in.track_opens,
        weekdays_only=camp_in.weekdays_only,
        send_window_start=camp_in.send_window_start,
        send_window_end=camp_in.send_window_end,
        warmup_enabled=camp_in.warmup_enabled,
        warmup_start_limit=camp_in.warmup_start_limit,
        warmup_increment=camp_in.warmup_increment,
        target_tag_id=camp_in.target_tag_id
    )
    
    # Audit log
    audit = AuditLog(
        user_id=current_user.id,
        action="Campaign Created",
        details=f"Campaign '{camp_in.name}' created."
    )
    db.add(audit)
    
    db.add(new_campaign)
    await db.commit()
    await db.refresh(new_campaign)
    return new_campaign

@router.get("/unsubscribe", response_class=HTMLResponse)
async def unsubscribe_contact(token: str, db: AsyncSession = Depends(get_db)):
    try:
        # Decode the cryptographically signed JWT token
        payload = jwt.decode(token, settings.JWT_SECRET, algorithms=["HS256"])
        if payload.get("type") != "unsubscribe":
            raise JWTError("Invalid token type")
        email = payload.get("sub")
        if not email:
            raise JWTError("Missing email subject")
    except JWTError:
        return HTMLResponse(
            status_code=400,
            content="""
            <html>
                <head>
                    <title>Invalid Request</title>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600&display=swap" rel="stylesheet">
                    <style>
                        body { background: #090d16; color: #ff6b6b; font-family: 'Outfit', sans-serif; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }
                        .card { background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); padding: 2.5rem; border-radius: 20px; text-align: center; max-width: 400px; width: 90%; }
                        h2 { margin: 0 0 10px; font-weight: 600; }
                        p { color: #8a93a6; font-size: 14px; line-height: 1.5; margin: 0; }
                    </style>
                </head>
                <body>
                    <div class="card">
                        <h2>Link Invalid or Expired</h2>
                        <p>This security token is invalid or has expired. Please contact the sender if you need assistance unsubscribing.</p>
                    </div>
                </body>
            </html>
            """
        )

    # Update contact status in the database to unsubscribed
    contact_res = await db.execute(select(Contact).where(Contact.email.ilike(email.strip())))
    contact = contact_res.scalars().first()
    if contact:
        if contact.status != "unsubscribed":
            contact.status = "unsubscribed"
            
            # Log timeline event as ContactNote
            note = ContactNote(
                contact_id=contact.id,
                author_name="System Tracking",
                content="Recipient unsubscribed from email campaign outreach."
            )
            db.add(note)
            await db.commit()

    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Unsubscribed Successfully</title>
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
        <style>
            :root {{
                --bg: #090d16;
                --surface: rgba(255, 255, 255, 0.03);
                --border: rgba(255, 255, 255, 0.08);
                --primary: #ffffff;
                --muted: #8a93a6;
                --accent: #00b5ad;
            }}
            body {{
                margin: 0;
                padding: 0;
                background-color: var(--bg);
                color: var(--primary);
                font-family: 'Outfit', sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                overflow: hidden;
                background-image: 
                    radial-gradient(circle at 10% 20%, rgba(0, 181, 173, 0.05) 0%, transparent 40%),
                    radial-gradient(circle at 90% 80%, rgba(99, 102, 241, 0.05) 0%, transparent 40%);
            }}
            .container {{
                text-align: center;
                padding: 3rem 2rem;
                background: var(--surface);
                backdrop-filter: blur(16px);
                border: 1px solid var(--border);
                border-radius: 24px;
                max-width: 440px;
                width: 90%;
                box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
                animation: fadeIn 0.8s cubic-bezier(0.16, 1, 0.3, 1);
            }}
            .icon-wrapper {{
                width: 72px;
                height: 72px;
                background: rgba(0, 181, 173, 0.1);
                border: 1px solid rgba(0, 181, 173, 0.2);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin: 0 auto 2rem;
                animation: pulse 2s infinite;
            }}
            .icon {{
                color: var(--accent);
                width: 32px;
                height: 32px;
            }}
            h1 {{
                font-size: 1.75rem;
                font-weight: 800;
                margin: 0 0 1rem;
                letter-spacing: -0.02em;
            }}
            p {{
                color: var(--muted);
                font-size: 0.95rem;
                line-height: 1.6;
                margin: 0 0 2rem;
            }}
            .email-badge {{
                background: rgba(255, 255, 255, 0.04);
                border: 1px solid var(--border);
                padding: 0.5rem 1rem;
                border-radius: 99px;
                font-family: monospace;
                font-size: 0.85rem;
                color: var(--primary);
                display: inline-block;
                margin-bottom: 2rem;
            }}
            .footer {{
                font-size: 0.75rem;
                color: var(--muted);
                border-top: 1px solid var(--border);
                padding-top: 1.5rem;
            }}
            @keyframes fadeIn {{
                from {{ opacity: 0; transform: translateY(20px); }}
                to {{ opacity: 1; transform: translateY(0); }}
            }}
            @keyframes pulse {{
                0% {{ transform: scale(1); box-shadow: 0 0 0 0 rgba(0, 181, 173, 0.4); }}
                70% {{ transform: scale(1.05); box-shadow: 0 0 0 10px rgba(0, 181, 173, 0); }}
                100% {{ transform: scale(1); box-shadow: 0 0 0 0 rgba(0, 181, 173, 0); }}
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="icon-wrapper">
                <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
            </div>
            <h1>Unsubscribed</h1>
            <p>You have been successfully unsubscribed from our mailing list. You will no longer receive campaign emails at:</p>
            <div class="email-badge">{email}</div>
            <div class="footer">
                If this was a mistake, please contact the sender to resubscribe.
            </div>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

@router.get("/{campaign_id}", response_model=CampaignDetailResponse)
async def get_campaign_details(
    campaign_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Campaign).where(Campaign.id == campaign_id))
    campaign = result.scalars().first()
    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found"
        )
        
    # Get stats
    sent_q = select(func.count(EmailQueue.id)).where(EmailQueue.campaign_id == campaign_id, EmailQueue.status == "sent")
    pending_q = select(func.count(EmailQueue.id)).where(EmailQueue.campaign_id == campaign_id, EmailQueue.status.in_(["pending", "sending"]))
    failed_q = select(func.count(EmailQueue.id)).where(EmailQueue.campaign_id == campaign_id, EmailQueue.status == "failed")
    opened_q = select(func.count(EmailQueue.id)).where(EmailQueue.campaign_id == campaign_id, EmailQueue.opened == True)
    
    sent_res = await db.execute(sent_q)
    pending_res = await db.execute(pending_q)
    failed_res = await db.execute(failed_q)
    opened_res = await db.execute(opened_q)
    
    sent_val = sent_res.scalar() or 0
    pending_val = pending_res.scalar() or 0
    failed_val = failed_res.scalar() or 0
    opened_val = opened_res.scalar() or 0
    
    return {
        "campaign": campaign,
        "stats": {
            "sent": sent_val,
            "pending": pending_val,
            "failed": failed_val,
            "opened": opened_val,
            "total": sent_val + pending_val + failed_val
        }
    }

# Fallback local campaign queue processing when Redis is offline
async def process_campaign_queue_local(campaign_id: str, author_name: str, owner_id: str):
    import logging
    logger = logging.getLogger("app.campaign_local")
    logger.info(f"Local Background Task: Processing campaign queue for campaign: {campaign_id}")
    
    async with SessionLocal() as db:
        camp_res = await db.execute(select(Campaign).where(Campaign.id == campaign_id))
        campaign = camp_res.scalars().first()
        if not campaign:
            logger.error(f"Campaign {campaign_id} not found in database.")
            return
            
        if campaign.status != "running":
            logger.info(f"Campaign status is {campaign.status}, skipping execution.")
            return

        # Fetch queued items for this campaign
        queue_res = await db.execute(
            select(EmailQueue).where(EmailQueue.campaign_id == campaign_id, EmailQueue.status == "pending")
        )
        queue_items = queue_res.scalars().all()
        
        from app.services.email_provider import SmtpEmailProvider
        provider = SmtpEmailProvider()
        
        host = settings.SMTP_HOST
        port = settings.SMTP_PORT
        username = settings.SMTP_USER
        password = settings.SMTP_PASSWORD
        from_email = settings.SMTP_FROM_EMAIL
        smtp_name = "Default config"

        if campaign.sender:
            smtp_res = await db.execute(select(SMTPAccount).where(SMTPAccount.id == campaign.sender))
            smtp = smtp_res.scalars().first()
            if smtp:
                from app.services.crypto import decrypt_password
                host = smtp.host
                port = smtp.port
                username = smtp.username
                password = decrypt_password(smtp.password_encrypted)
                from_email = smtp.from_email
                smtp_name = smtp.name

        success_count = 0
        failed_count = 0
        last_subject = ""
        
        for item in queue_items:
            # Re-fetch campaign state to check if it has been paused
            db.expire(campaign)
            camp_res = await db.execute(select(Campaign).where(Campaign.id == campaign_id))
            campaign = camp_res.scalars().first()
            if not campaign or campaign.status == "paused":
                logger.info("Campaign paused or deleted, stopping local send loop.")
                break
                
            IST = timezone(timedelta(hours=5, minutes=30))
            now_ist = datetime.now(IST)

            # Check scheduling constraints (weekdays and hour windows)
            if campaign.weekdays_only and now_ist.weekday() >= 5:
                logger.info("Local queue: Weekend detected and weekdays_only is enabled. Halting queue loop.")
                break
                
            if campaign.send_window_start and campaign.send_window_end:
                current_time_str = now_ist.strftime("%H:%M")
                if not (campaign.send_window_start <= current_time_str <= campaign.send_window_end):
                    logger.info(f"Local queue: Time ({current_time_str} IST) falls outside the sending window ({campaign.send_window_start} - {campaign.send_window_end}). Halting queue loop.")
                    break

            # Check warmup constraints
            if campaign.warmup_enabled:
                ist_today_start = datetime.combine(now_ist.date(), time.min).replace(tzinfo=IST)
                today_start = ist_today_start.astimezone(timezone.utc).replace(tzinfo=None)
                sent_today_res = await db.execute(
                    select(func.count(EmailQueue.id)).where(
                        EmailQueue.campaign_id == campaign_id,
                        EmailQueue.status == "sent",
                        EmailQueue.sent_time >= today_start
                    )
                )
                sent_today = sent_today_res.scalar() or 0
                
                days_elapsed = 0
                if campaign.start_date:
                    start_date_ist = campaign.start_date.replace(tzinfo=timezone.utc).astimezone(IST).date()
                    days_elapsed = (now_ist.date() - start_date_ist).days
                    if days_elapsed < 0:
                        days_elapsed = 0
                
                limit_today = campaign.warmup_start_limit + (days_elapsed * campaign.warmup_increment)
                if sent_today >= limit_today:
                    logger.info(f"Local queue: Warmup daily limit reached ({sent_today}/{limit_today}). Halting local loop.")
                    break

            # Check if contact is still active (not unsubscribed)
            contact_res = await db.execute(select(Contact).where(Contact.email.ilike(item.recipient_email)))
            contact = contact_res.scalars().first()
            if contact and contact.status == "unsubscribed":
                logger.info(f"Recipient {item.recipient_email} has unsubscribed. Skipping queue item.")
                item.status = "failed"
                await db.commit()
                continue

            item.status = "sending"
            await db.commit()
            
            # Generate secure unsubscribe token & url
            unsub_token = jwt.encode({"sub": item.recipient_email, "type": "unsubscribe"}, settings.JWT_SECRET, algorithm="HS256")
            unsub_url = f"{settings.BACKEND_URL}/api/v1/campaigns/unsubscribe?token={unsub_token}"
            
            body_html = item.body
            
            # Append Unsubscribe Footer Link
            unsub_link_html = f'<br/><br/><hr style="border:0;border-top:1px solid rgba(255,255,255,0.08);margin:20px 0;"/><p style="font-size:11px;color:#8a93a6;text-align:center;">If you no longer wish to receive these communications, you can <a href="{unsub_url}" style="color:#00b5ad;text-decoration:underline;">unsubscribe here</a>.</p>'
            if "</body>" in body_html:
                body_html = body_html.replace("</body>", f"{unsub_link_html}</body>")
            else:
                body_html += unsub_link_html

            if campaign and campaign.track_opens:
                pixel_url = f"{settings.BACKEND_URL}/api/v1/campaigns/track/{item.id}"
                pixel_img = f'<img src="{pixel_url}" width="1" height="1" style="display:none !important;" alt="" />'
                if "</body>" in body_html:
                    body_html = body_html.replace("</body>", f"{pixel_img}</body>")
                else:
                    body_html += pixel_img

            try:
                await provider.send_email(
                    recipient_email=item.recipient_email,
                    subject=item.subject,
                    body=body_html,
                    sender_email=from_email,
                    host=host,
                    port=port,
                    username=username,
                    password=password,
                    validate_certs=False,
                    sender_name=smtp_name,
                    list_unsubscribe=unsub_url
                )
                
                item.status = "sent"
                item.sent_time = get_ist_time()
                success_count += 1
                last_subject = item.subject
                
                contact_res = await db.execute(select(Contact).where(Contact.email == item.recipient_email))
                contact = contact_res.scalars().first()
                if contact:
                    note = ContactNote(
                        contact_id=contact.id,
                        author_name=author_name,
                        content=f"Campaign email successfully delivered via gateway '{smtp_name}': {item.subject}"
                    )
                    db.add(note)
                await db.commit()
                
            except Exception as e:
                logger.error(f"Local failed to send email to {item.recipient_email}: {str(e)}")
                item.status = "failed"
                item.error_message = str(e)
                failed_count += 1
                
                audit = AuditLog(
                    user_id=owner_id,
                    action="SMTP Local Fallback Failure",
                    details=f"Queue send failed to {item.recipient_email} using gateway '{smtp_name}'. Error: {str(e)}"
                )
                db.add(audit)
                await db.commit()
                
            # Add configured delay between sends with jitter
            import random
            delay = campaign.send_delay_seconds if campaign.send_delay_seconds is not None else 1
            jitter = random.uniform(-0.25 * delay, 0.5 * delay)
            actual_delay = max(0.1, delay + jitter)
            await asyncio.sleep(float(actual_delay))
            
        # Re-fetch and check remaining count
        db.expire(campaign)
        camp_res = await db.execute(select(Campaign).where(Campaign.id == campaign_id))
        campaign = camp_res.scalars().first()
        
        remaining_res = await db.execute(
            select(func.count(EmailQueue.id)).where(
                EmailQueue.campaign_id == campaign_id,
                EmailQueue.status.in_(["pending", "sending"])
            )
        )
        remaining_count = remaining_res.scalar() or 0
        
        if campaign and campaign.status == "running" and remaining_count == 0:
            campaign.status = "completed"
            campaign.end_date = get_ist_time()
            await db.commit()
            
            try:
                from app.services.discord import dispatch_campaign_summary_notification
                await dispatch_campaign_summary_notification(
                    campaign_name=campaign.name,
                    sent_count=success_count,
                    failed_count=failed_count,
                    gateway_name=smtp_name,
                    subject=last_subject or campaign.name
                )
            except Exception as notify_err:
                logger.error(f"Failed to dispatch Discord summary: {str(notify_err)}")
            await db.commit()

# ARQ background task queues handle campaign processing asynchronously.

@router.post("/{campaign_id}/start")
async def start_campaign(
    campaign_id: str,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Campaign).where(Campaign.id == campaign_id))
    campaign = result.scalars().first()
    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found"
        )
        
    if campaign.status in ["running", "completed"]:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Campaign is already in status: {campaign.status}"
        )
        
    # Get active contacts to target (optionally filtered by group/tag)
    if campaign.target_tag_id:
        contact_res = await db.execute(
            select(Contact)
            .join(Contact.tags)
            .where(Contact.status == "active", Tag.id == campaign.target_tag_id)
        )
    else:
        contact_res = await db.execute(select(Contact).where(Contact.status == "active"))
    contacts = contact_res.scalars().all()
    if not contacts:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No active contacts in CRM to target. Please import contacts first."
        )
        
    # Get template body
    temp_res = await db.execute(select(Template).where(Template.id == campaign.template_id))
    template = temp_res.scalars().first()
    if not template:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Campaign template not found."
        )
        
    # Load contacts into queue
    for contact in contacts:
        # Simple variable replacement
        subject_rendered = template.subject.replace("{{name}}", contact.full_name or "").replace("{{company}}", contact.company or "")
        body_rendered = template.body_html.replace("{{name}}", contact.full_name or "").replace("{{company}}", contact.company or "")
        
        # Add to queue
        queue_item = EmailQueue(
            campaign_id=campaign.id,
            recipient_email=contact.email,
            subject=subject_rendered,
            body=body_rendered,
            status="pending"
        )
        db.add(queue_item)
        
    campaign.status = "running"
    
    # Audit log
    audit = AuditLog(
        user_id=current_user.id,
        action="Campaign Started",
        details=f"Campaign '{campaign.name}' started with {len(contacts)} queued emails."
    )
    db.add(audit)
    
    await db.commit()
    
    # Trigger ARQ background worker task to process queue, or fallback to local background tasks if Redis is offline
    try:
        redis_host_port = settings.REDIS_URL.replace("redis://", "").split("/")[0].split(":")
        redis_host = redis_host_port[0]
        redis_port = int(redis_host_port[1]) if len(redis_host_port) > 1 else 6379

        # Fast test connection to avoid long timeouts on create_pool
        import redis
        r = redis.Redis(host=redis_host, port=redis_port, socket_connect_timeout=0.5, socket_timeout=0.5)
        r.ping()

        from arq import create_pool
        from arq.connections import RedisSettings
        
        redis_pool = await create_pool(RedisSettings(host=redis_host, port=redis_port))
        await redis_pool.enqueue_job("process_campaign_queue", campaign.id)
        is_redis = True
    except Exception as e:
        import logging
        logging.getLogger("app.campaign").warning(f"Redis connection failed. Falling back to local BackgroundTasks. Error: {e}")
        background_tasks.add_task(process_campaign_queue_local, campaign.id, current_user.full_name, current_user.id)
        is_redis = False
        
    return {
        "message": f"Campaign started. {len(contacts)} emails queued. (Background: {'Redis/ARQ' if is_redis else 'Local Tasks'})", 
        "status": "running"
    }

@router.post("/{campaign_id}/pause")
async def pause_campaign(
    campaign_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Campaign).where(Campaign.id == campaign_id))
    campaign = result.scalars().first()
    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found"
        )
    if campaign.status != "running":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only running campaigns can be paused."
        )
        
    campaign.status = "paused"
    
    # Update pending queue items for this campaign to cancelled/paused?
    # To keep it simple, we just pause the campaign lifecycle.
    
    # Audit log
    audit = AuditLog(
        user_id=current_user.id,
        action="Campaign Paused",
        details=f"Campaign '{campaign.name}' paused."
    )
    db.add(audit)
    await db.commit()
    return {"message": "Campaign paused successfully.", "status": "paused"}

@router.delete("/{campaign_id}")
async def delete_campaign(
    campaign_id: str,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    result = await db.execute(select(Campaign).where(Campaign.id == campaign_id))
    campaign = result.scalars().first()
    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found"
        )
    # Also delete its queued emails
    await db.execute(delete(EmailQueue).where(EmailQueue.campaign_id == campaign_id))
    await db.delete(campaign)
    await db.commit()
    return {"message": "Campaign and associated queue deleted."}

class DirectSendAttachment(BaseModel):
    filename: str
    content: str  # Base64 encoded file content
    mime_type: str

class DirectSendIn(BaseModel):
    recipient_email: str
    subject: str
    body: str
    smtp_id: Optional[str] = None
    cc: Optional[str] = None
    bcc: Optional[str] = None
    attachments: Optional[List[DirectSendAttachment]] = None
    scheduled_time: Optional[datetime] = None
    sender_name: Optional[str] = None

async def send_single_direct_email(
    queue_item_id: str,
    smtp_id: Optional[str],
    cc: Optional[str],
    bcc: Optional[str],
    attachments: Optional[List[Dict[str, Any]]],
    smtp_name: str,
    from_email: str,
    host: str,
    port: int,
    username: Optional[str],
    password: Optional[str],
    user_id: str,
    user_full_name: str
) -> Optional[str]:
    from app.services.email_provider import SmtpEmailProvider
    email_provider = SmtpEmailProvider()
    
    async with SessionLocal() as db:
        try:
            res = await db.execute(select(EmailQueue).where(EmailQueue.id == queue_item_id))
            queue_item = res.scalars().first()
            if not queue_item:
                return "Queue item not found"
                
            email_addr = queue_item.recipient_email
            
            # Fetch/create contact
            contact_res = await db.execute(select(Contact).where(Contact.email.ilike(email_addr)))
            contact = contact_res.scalars().first()
            if not contact:
                contact = Contact(
                    full_name=email_addr.split("@")[0].capitalize(),
                    email=email_addr,
                    status="active",
                    source="compose"
                )
                db.add(contact)
                await db.flush()
                
            unsub_token = jwt.encode({"sub": email_addr, "type": "unsubscribe"}, settings.JWT_SECRET, algorithm="HS256")
            unsub_url = f"{settings.BACKEND_URL}/api/v1/campaigns/unsubscribe?token={unsub_token}"
            
            await email_provider.send_email(
                recipient_email=email_addr,
                subject=queue_item.subject,
                body=queue_item.body,
                sender_email=from_email,
                host=host,
                port=port,
                username=username,
                password=password,
                validate_certs=False,
                cc=cc,
                bcc=bcc,
                attachments=attachments,
                sender_name=smtp_name,
                list_unsubscribe=unsub_url
            )
            
            queue_item.status = "sent"
            queue_item.sent_time = get_ist_time()
            
            # Record in Conversation and Message
            clean_subj = queue_item.subject
            for prefix in ["Re: ", "re: ", "RE: ", "Fwd: ", "fwd: ", "FWD: ", "Re:", "re:", "RE:", "Fwd:", "fwd:", "FWD:"]:
                clean_subj = clean_subj.replace(prefix, "")
            clean_subj = clean_subj.strip()

            conv_res = await db.execute(
                select(Conversation).where(
                    Conversation.contact_id == contact.id,
                    Conversation.subject.ilike(clean_subj)
                )
            )
            conversation = conv_res.scalars().first()
            if not conversation:
                conversation = Conversation(
                    contact_id=contact.id,
                    subject=clean_subj,
                    status="waiting"
                )
                db.add(conversation)
                await db.flush()
            else:
                conversation.updated_at = get_ist_time()

            msg_obj = Message(
                conversation_id=conversation.id,
                sender=from_email,
                recipient=email_addr,
                subject=queue_item.subject,
                body=queue_item.body,
                is_incoming=False,
                is_unread=False,
                created_at=get_ist_time()
            )
            db.add(msg_obj)

            # Log timeline event
            note = ContactNote(
                contact_id=contact.id,
                author_name=user_full_name,
                content=f"Sent outreach email via gateway '{smtp_name}': {queue_item.subject}"
            )
            db.add(note)

            # Audit log
            audit = AuditLog(
                user_id=user_id,
                action="Email Sent",
                details=f"Email sent directly to {email_addr} using gateway '{smtp_name}'."
            )
            db.add(audit)
            
            await db.commit()
            return None
        except Exception as e:
            try:
                await db.rollback()
                res = await db.execute(select(EmailQueue).where(EmailQueue.id == queue_item_id))
                queue_item = res.scalars().first()
                if queue_item:
                    queue_item.status = "failed"
                    queue_item.error_message = str(e)
                    
                    audit = AuditLog(
                        user_id=user_id,
                        action="SMTP Failure",
                        details=f"Failed to send email to {queue_item.recipient_email} using gateway '{smtp_name}'. Error: {str(e)}"
                    )
                    db.add(audit)
                    await db.commit()
            except Exception as inner_e:
                import logging
                logging.getLogger("app.send_direct").error(f"Error updating failed status for queue item {queue_item_id}: {inner_e}")
            return f"{queue_item_id}: {str(e)}"

async def send_direct_emails_background_task(
    queue_item_ids: List[str],
    smtp_id: Optional[str],
    cc: Optional[str],
    bcc: Optional[str],
    attachments: Optional[List[Dict[str, Any]]],
    smtp_name: str,
    from_email: str,
    host: str,
    port: int,
    username: Optional[str],
    password: Optional[str],
    user_id: str,
    user_full_name: str,
    recipients: List[str],
    subject: str
):
    tasks = [
        send_single_direct_email(
            queue_item_id=qid,
            smtp_id=smtp_id,
            cc=cc,
            bcc=bcc,
            attachments=attachments,
            smtp_name=smtp_name,
            from_email=from_email,
            host=host,
            port=port,
            username=username,
            password=password,
            user_id=user_id,
            user_full_name=user_full_name
        )
        for qid in queue_item_ids
    ]
    results = await asyncio.gather(*tasks)
    
    failures = [r for r in results if r is not None]
    success_count = len(queue_item_ids) - len(failures)
    
    try:
        from app.services.discord import dispatch_direct_send_summary_notification
        await dispatch_direct_send_summary_notification(
            sent_count=success_count,
            failed_count=len(failures),
            gateway_name=smtp_name,
            subject=subject,
            recipients_list=recipients
        )
    except Exception:
        pass

@router.post("/send-direct")
async def send_direct_email(
    payload: DirectSendIn,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    # Determine which SMTP configurations to use
    host = settings.SMTP_HOST
    port = settings.SMTP_PORT
    username = settings.SMTP_USER
    password = settings.SMTP_PASSWORD
    from_email = settings.SMTP_FROM_EMAIL
    smtp_name = "Default config"

    if payload.smtp_id:
        smtp_res = await db.execute(select(SMTPAccount).where(SMTPAccount.id == payload.smtp_id))
        smtp = smtp_res.scalars().first()
        if smtp:
            from app.services.crypto import decrypt_password
            host = smtp.host
            port = smtp.port
            username = smtp.username
            password = decrypt_password(smtp.password_encrypted)
            from_email = smtp.from_email
            smtp_name = smtp.name

    smtp_name = payload.sender_name or smtp_name

    # Split recipient emails by comma
    raw_recipients = (payload.recipient_email or "").split(",")
    recipients = [r.strip() for r in raw_recipients if r.strip()]
    if not recipients:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No valid recipient email addresses provided."
        )

    immediate_queue_ids = []
    
    for email_addr in recipients:
        # Create/find contact in database
        contact_res = await db.execute(select(Contact).where(Contact.email.ilike(email_addr)))
        contact = contact_res.scalars().first()
        if not contact:
            # Create a new contact
            contact = Contact(
                full_name=email_addr.split("@")[0].capitalize(),
                email=email_addr,
                status="active",
                source="compose"
            )
            db.add(contact)
            await db.flush()

        # Generate secure unsubscribe token & url
        unsub_token = jwt.encode({"sub": email_addr, "type": "unsubscribe"}, settings.JWT_SECRET, algorithm="HS256")
        unsub_url = f"{settings.BACKEND_URL}/api/v1/campaigns/unsubscribe?token={unsub_token}"
        
        # Append Unsubscribe Footer Link
        unsub_link_html = f'<br/><br/><hr style="border:0;border-top:1px solid rgba(255,255,255,0.08);margin:20px 0;"/><p style="font-size:11px;color:#8a93a6;text-align:center;">If you no longer wish to receive these communications, you can <a href="{unsub_url}" style="color:#00b5ad;text-decoration:underline;">unsubscribe here</a>.</p>'
        
        body_html = payload.body
        if "</body>" in body_html:
            body_html = body_html.replace("</body>", f"{unsub_link_html}</body>")
        else:
            body_html += unsub_link_html

        is_scheduled = bool(payload.scheduled_time)

        # Insert message log into EmailQueue
        queue_item = EmailQueue(
            campaign_id=None,
            smtp_id=payload.smtp_id,
            recipient_email=email_addr,
            subject=payload.subject,
            body=body_html,
            status="pending" if is_scheduled else "sending",
            scheduled_time=payload.scheduled_time if is_scheduled else None
        )
        db.add(queue_item)
        await db.flush()

        if is_scheduled:
            audit = AuditLog(
                user_id=current_user.id,
                action="Email Scheduled",
                details=f"Email scheduled to {email_addr} for {payload.scheduled_time} using gateway '{smtp_name}'."
            )
            db.add(audit)
        else:
            immediate_queue_ids.append(queue_item.id)

    await db.commit()

    if immediate_queue_ids:
        attachments_dict = None
        if payload.attachments:
            attachments_dict = [
                {"filename": a.filename, "content": a.content, "mime_type": a.mime_type}
                for a in payload.attachments
            ]
            
        background_tasks.add_task(
            send_direct_emails_background_task,
            queue_item_ids=immediate_queue_ids,
            smtp_id=payload.smtp_id,
            cc=payload.cc,
            bcc=payload.bcc,
            attachments=attachments_dict,
            smtp_name=smtp_name,
            from_email=from_email,
            host=host,
            port=port,
            username=username,
            password=password,
            user_id=current_user.id,
            user_full_name=current_user.full_name,
            recipients=recipients,
            subject=payload.subject
        )

    if is_scheduled:
        return {
            "success": True,
            "message": f"Email successfully scheduled for {payload.scheduled_time}."
        }
        
    return {
        "success": True,
        "message": f"Direct dispatch started in background for {len(immediate_queue_ids)} recipients."
    }

@router.get("/track/{email_id}")
async def track_email_open(email_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(EmailQueue).where(EmailQueue.id == email_id))
    item = result.scalars().first()
    if item:
        if not item.opened:
            item.opened = True
            item.opened_at = get_ist_time()
            
            # Log timeline event as ContactNote
            contact_res = await db.execute(select(Contact).where(Contact.email == item.recipient_email))
            contact = contact_res.scalars().first()
            if contact:
                note = ContactNote(
                    contact_id=contact.id,
                    author_name="System Tracking",
                    content=f"Email opened by recipient: '{item.subject}'"
                )
                db.add(note)
            await db.commit()
            
    # Return a transparent 1x1 GIF
    transparent_pixel = b'\x47\x49\x46\x38\x39\x61\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00\x21\xf9\x04\x01\x00\x00\x00\x00\x2c\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02\x4c\x01\x00\x3b'
    return Response(content=transparent_pixel, media_type="image/gif")



