from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from pydantic import BaseModel, EmailStr
from typing import Optional

from app.database import get_db, get_ist_time
from app.models import User, AuditLog
from app.auth import get_password_hash, verify_password, create_access_token, get_current_user

router = APIRouter(prefix="/auth", tags=["auth"])

class UserRegister(BaseModel):
    full_name: str
    username: str
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: str
    full_name: str
    username: str
    email: str
    role: str
    status: str
    mfa_enabled: bool
    created_at: datetime
    last_login: Optional[datetime]

    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

class PasswordChange(BaseModel):
    old_password: str
    new_password: str

@router.get("/setup-status")
async def get_setup_status(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User))
    user_exists = result.scalars().first()
    return {"need_setup": not bool(user_exists)}

@router.post("/setup-initial-admin", response_model=UserResponse)
async def setup_initial_admin(user_in: UserRegister, db: AsyncSession = Depends(get_db)):
    # Check if there are any users in the DB
    result = await db.execute(select(User))
    user_exists = result.scalars().first()
    if user_exists:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="System already initialized with user accounts. Initial setup is disabled."
        )
    
    # Create the initial user as super_admin
    new_user = User(
        full_name=user_in.full_name,
        username=user_in.username,
        email=user_in.email,
        hashed_password=get_password_hash(user_in.password),
        role="super_admin",
        status="active"
    )
    db.add(new_user)
    
    # Add audit log
    audit = AuditLog(
        user_id=None,
        action="Initial Setup Super Admin Created",
        details=f"User {user_in.username} created via setup-initial-admin."
    )
    db.add(audit)
    
    await db.commit()
    await db.refresh(new_user)
    return new_user

@router.post("/login", response_model=Token)
async def login(
    request: Request,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
):
    from app.services.rate_limiter import login_rate_limiter
    login_rate_limiter.check_rate_limit(request)
    # Search by email or username
    result = await db.execute(
        select(User).where(
            (User.email == form_data.username) | (User.username == form_data.username)
        )
    )
    user = result.scalars().first()
    
    if not user or not verify_password(form_data.password, user.hashed_password):
        # Log failure
        audit = AuditLog(
            user_id=None,
            action="Login Failure",
            details=f"Failed login attempt for identifier: {form_data.username}"
        )
        db.add(audit)
        await db.commit()
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email/username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    if user.status != "active":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User account is suspended or disabled."
        )
    
    # Update last login
    user.last_login = get_ist_time()
    
    # Log success
    audit = AuditLog(
        user_id=user.id,
        action="Login Success",
        details=f"User logged in from OAuth2 endpoint."
    )
    db.add(audit)
    
    await db.commit()
    await db.refresh(user)
    
    access_token = create_access_token(subject=user.id)
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "user": user
    }

@router.get("/me", response_model=UserResponse)
async def get_me(current_user: User = Depends(get_current_user)):
    return current_user

@router.post("/change-password")
async def change_password(
    pwd_in: PasswordChange,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    if not verify_password(pwd_in.old_password, current_user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Incorrect current password"
        )
        
    current_user.hashed_password = get_password_hash(pwd_in.new_password)
    
    # Log password change
    audit = AuditLog(
        user_id=current_user.id,
        action="Password Changed",
        details="User successfully changed password."
    )
    db.add(audit)
    
    await db.commit()
    return {"message": "Password updated successfully"}
