import os
import json
from pydantic_settings import BaseSettings
from pydantic import Field

# Path to the separate SMTP credentials file
SMTP_CREDS_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "smtp_creds.json")

# Path to the separate Discord webhooks file
DISCORD_WEBHOOKS_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "discord_webhooks.json")

# Default SMTP values
default_smtp = {
    "SMTP_HOST": "smtp.gmail.com",
    "SMTP_PORT": 587,
    "SMTP_USER": "",
    "SMTP_PASSWORD": "",
    "SMTP_FROM_EMAIL": "teams@thundercipher.in"
}

# Default Discord Webhook values
default_webhooks = {
    "FAILED_MAILS_WEBHOOK": "",
    "GENERAL_MAILS_WEBHOOK": "",
    "CUSTOM_CATEGORIES": [
        {"name": "CTF Proposals", "url": ""},
        {"name": "Sponsor Mails", "url": ""},
        {"name": "Certificate Mails", "url": ""}
    ]
}

# If the SMTP file does not exist, create it
if not os.path.exists(SMTP_CREDS_FILE):
    try:
        with open(SMTP_CREDS_FILE, "w", encoding="utf-8") as f:
            json.dump(default_smtp, f, indent=4)
    except Exception as e:
        print(f"Warning: Could not create default SMTP credentials file: {e}")

# If the Webhooks file does not exist, create it
if not os.path.exists(DISCORD_WEBHOOKS_FILE):
    try:
        with open(DISCORD_WEBHOOKS_FILE, "w", encoding="utf-8") as f:
            json.dump(default_webhooks, f, indent=4)
    except Exception as e:
        print(f"Warning: Could not create default Discord webhooks file: {e}")

# Try to load the files
loaded_smtp = {}
loaded_webhooks = {}

try:
    if os.path.exists(SMTP_CREDS_FILE):
        with open(SMTP_CREDS_FILE, "r", encoding="utf-8") as f:
            loaded_smtp = json.load(f)
except Exception as e:
    print(f"Warning: Could not load SMTP credentials file: {e}")

try:
    if os.path.exists(DISCORD_WEBHOOKS_FILE):
        with open(DISCORD_WEBHOOKS_FILE, "r", encoding="utf-8") as f:
            loaded_webhooks = json.load(f)
except Exception as e:
    print(f"Warning: Could not load Discord webhooks file: {e}")

from typing import Optional

class Settings(BaseSettings):
    PROJECT_NAME: str = "ThunderCipher Mailer"
    API_V1_STR: str = "/api/v1"
    
    # Database
    DATABASE_URL: str = Field(
        default="sqlite+aiosqlite:///./mailai.db",
        description="SQLAlchemy Database URL. Supports PostgreSQL and SQLite."
    )
    
    # Redis for workers and cache
    REDIS_URL: str = Field(
        default="redis://localhost:6379/0",
        description="Redis connection URL for queue broker."
    )
    
    # App URL for pixel tracking
    BACKEND_URL: str = Field(
        default="http://localhost:8000",
        description="Public url of the backend server used for link and pixel tracking."
    )
    
    # Frontend Origin URL
    FRONTEND_URL: str = Field(
        default="http://localhost:5173",
        description="Origin URL of the frontend SPA application."
    )
    
    # Security
    JWT_SECRET: str = Field(
        default="supersecretjwtkeyforoutreachcrm2026",
        description="Key used to sign JWT tokens."
    )
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    
    ENCRYPTION_KEY: str = Field(
        default="mailai_default_aes256_encryption_key_secret_2026",
        description="Key used to encrypt SMTP/IMAP credentials. Override in .env."
    )
    
    # SMTP Defaults (loaded from separate file)
    SMTP_HOST: str = Field(default=loaded_smtp.get("SMTP_HOST", default_smtp["SMTP_HOST"]))
    SMTP_PORT: int = Field(default=int(loaded_smtp.get("SMTP_PORT", default_smtp["SMTP_PORT"])))
    SMTP_USER: str = Field(default=loaded_smtp.get("SMTP_USER", default_smtp["SMTP_USER"]))
    SMTP_PASSWORD: str = Field(default=loaded_smtp.get("SMTP_PASSWORD", default_smtp["SMTP_PASSWORD"]))
    SMTP_FROM_EMAIL: str = Field(default=loaded_smtp.get("SMTP_FROM_EMAIL", default_smtp["SMTP_FROM_EMAIL"]))
    
    # Path to custom CA certificate for SMTP (optional)
    SMTP_CA_CERT_PATH: Optional[str] = Field(default=None)
    
    # Storage settings
    STORAGE_PROVIDER: str = Field(default="local")
    LOCAL_STORAGE_DIR: str = Field(default="./uploads")
    
    # Gemini
    GEMINI_API_KEY: Optional[str] = Field(default=None, description="Google Gemini API Key")
    
    # Discord Webhooks for different event types
    FAILED_MAILS_WEBHOOK: str = Field(default=loaded_webhooks.get("FAILED_MAILS_WEBHOOK", ""))
    GENERAL_MAILS_WEBHOOK: str = Field(default=loaded_webhooks.get("GENERAL_MAILS_WEBHOOK", ""))
    CUSTOM_CATEGORIES: list = Field(default=loaded_webhooks.get("CUSTOM_CATEGORIES", [
        {"name": "CTF Proposals", "url": ""},
        {"name": "Sponsor Mails", "url": ""},
        {"name": "Certificate Mails", "url": ""}
    ]))
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True

settings = Settings()

# Gemini Active/Legacy Model Helper definitions
GEMINI_MODEL_MAPPING = {
    "gemini-1.5-flash": "gemini-2.5-flash",
    "gemini-flash-latest": "gemini-2.5-flash",
    "gemini-1.5-pro": "gemini-2.5-pro",
    "gemini-pro-latest": "gemini-2.5-pro"
}

GEMINI_MODEL_WHITELIST = {
    "gemini-2.0-flash", "gemini-2.5-flash", "gemini-2.5-pro",
    "gemini-3.5-flash", "gemini-3.1-pro-preview", "gemini-3.1-flash-lite"
}

def resolve_gemini_model(model: str) -> str:
    target = model.strip() if model else ""
    mapped = GEMINI_MODEL_MAPPING.get(target, target)
    if mapped not in GEMINI_MODEL_WHITELIST:
        return "gemini-2.5-flash"
    return mapped
